# Sandero Launcher

Launcher leve para central multimídia Android (tela deitada), estilo BYD: fundo escuro, cartões grandes, dock lateral.
Sem bibliotecas externas, sem blur nem animações pesadas (feito para quad-core / 2 GB).

## Como gerar o APK

**Opção A: GitHub (não precisa instalar nada)**
1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta (inclusive `.github`).
2. Aba **Actions** > **Build APK** > **Run workflow**.
3. Ao terminar (~3 min), baixe o artefato **SanderoLauncher-apk** (dentro há o `app-debug.apk`).

**Opção B: Android Studio**
1. Abra a pasta no Android Studio e aguarde o Gradle sincronizar.
2. Menu **Build > Build APK(s)**. O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`.

## Instalando na central
1. Copie o APK para um pen drive e instale pelo gerenciador de arquivos (permita "fontes desconhecidas").
2. Aperte o botão Home da central e escolha **Sandero Launcher** > **Sempre**.

## Como usar
- **Cartões** (Navegação, Música, Telefone, Ajustes): toque para abrir; **segure** para escolher qual app abre.
- **Dock**: até 5 apps. Na gaveta de apps (botão de grade), **segure** um app > "Fixar no dock". Segure um ícone do dock para remover.
- **Música**: os botões anterior/play/próxima funcionam com qualquer player. Para mostrar título e artista, toque no texto da música e ative o acesso a notificações para o Sandero Launcher.
- Se algo não abrir (algumas centrais chinesas têm apps próprios), segure o cartão e escolha o app certo.
