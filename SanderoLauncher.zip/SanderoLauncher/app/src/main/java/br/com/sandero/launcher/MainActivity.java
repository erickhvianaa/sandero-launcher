package br.com.sandero.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Launcher leve para multimídia automotiva (landscape).
 * Sem dependências externas, sem animações pesadas: pensado para quad-core / 2 GB de RAM.
 */
public class MainActivity extends Activity {

    private static final String PREFS = "launcher";
    private static final String KEY_DOCK = "dock";
    private static final String KEY_NAV = "nav_pkg";
    private static final String KEY_MUSIC = "music_pkg";
    private static final String KEY_PHONE = "phone_pkg";
    private static final String KEY_SETTINGS = "settings_pkg";
    private static final int MAX_DOCK = 5;
    private static final long MEDIA_POLL_MS = 2000;
    private static final String DEFAULT_LABEL = "Padrão do sistema";

    static class AppItem {
        String label;
        String pkg;
        ComponentName cn;
    }

    private final List<AppItem> apps = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final LruCache<String, Drawable> iconCache = new LruCache<>(80);

    private SharedPreferences prefs;
    private PackageManager pm;

    private LinearLayout dockApps;
    private View drawer;
    private AppAdapter adapter;
    private TextView navSub, phoneSub, settingsSub, musicTitle, musicArtist;
    private ImageButton btnPlay;

    private boolean mediaAccess = false;
    private boolean visible = false;

    // ------------------------------------------------------------------ ciclo de vida

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        pm = getPackageManager();
        setContentView(R.layout.activity_main);

        dockApps = findViewById(R.id.dockApps);
        drawer = findViewById(R.id.drawer);
        navSub = findViewById(R.id.navSub);
        phoneSub = findViewById(R.id.phoneSub);
        settingsSub = findViewById(R.id.settingsSub);
        musicTitle = findViewById(R.id.musicTitle);
        musicArtist = findViewById(R.id.musicArtist);
        btnPlay = findViewById(R.id.btnPlay);

        // Gaveta de apps
        GridView grid = findViewById(R.id.grid);
        adapter = new AppAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent, view, position, id) -> {
            launch(apps.get(position));
            hideDrawer();
        });
        grid.setOnItemLongClickListener((parent, view, position, id) -> {
            showAppMenu(apps.get(position));
            return true;
        });
        findViewById(R.id.btnApps).setOnClickListener(v -> {
            if (isDrawerOpen()) hideDrawer(); else showDrawer();
        });
        findViewById(R.id.btnClose).setOnClickListener(v -> hideDrawer());

        // Cartões
        View cardNav = findViewById(R.id.cardNav);
        cardNav.setOnClickListener(v -> openPreferred(KEY_NAV, navIntent()));
        cardNav.setOnLongClickListener(v -> {
            showAppPicker(KEY_NAV, "App de navegação");
            return true;
        });

        View cardMusic = findViewById(R.id.cardMusic);
        cardMusic.setOnClickListener(v -> openPreferred(KEY_MUSIC, musicIntent()));
        cardMusic.setOnLongClickListener(v -> {
            showAppPicker(KEY_MUSIC, "App de música");
            return true;
        });
        findViewById(R.id.musicInfo).setOnClickListener(v -> {
            if (!mediaAccess) {
                startSafe(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
            } else {
                openPreferred(KEY_MUSIC, musicIntent());
            }
        });

        View cardPhone = findViewById(R.id.cardPhone);
        cardPhone.setOnClickListener(v -> openPreferred(KEY_PHONE, new Intent(Intent.ACTION_DIAL)));
        cardPhone.setOnLongClickListener(v -> {
            showAppPicker(KEY_PHONE, "App de telefone");
            return true;
        });

        View cardSettings = findViewById(R.id.cardSettings);
        cardSettings.setOnClickListener(v -> openPreferred(KEY_SETTINGS, new Intent(Settings.ACTION_SETTINGS)));
        cardSettings.setOnLongClickListener(v -> {
            showAppPicker(KEY_SETTINGS, "App de ajustes");
            return true;
        });

        // Controles de mídia (funcionam com qualquer player, sem permissão)
        findViewById(R.id.btnPrev).setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS));
        findViewById(R.id.btnNext).setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT));
        btnPlay.setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));

        // Atualiza a lista quando apps são instalados/removidos
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);

        refreshSubtitles();
        loadApps();
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        handler.removeCallbacks(mediaPoll);
        handler.post(mediaPoll);
    }

    @Override
    protected void onPause() {
        super.onPause();
        visible = false;
        handler.removeCallbacks(mediaPoll);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(pkgReceiver);
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Botão HOME pressionado: volta para a tela inicial
        if (isDrawerOpen()) hideDrawer();
    }

    @Override
    public void onBackPressed() {
        // Launcher não deve fechar com "voltar"
        if (isDrawerOpen()) hideDrawer();
    }

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            loadApps();
        }
    };

    // ------------------------------------------------------------------ apps

    private void loadApps() {
        new Thread(() -> {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
            final List<AppItem> out = new ArrayList<>();
            for (ResolveInfo ri : list) {
                if (ri.activityInfo.packageName.equals(getPackageName())) continue;
                AppItem a = new AppItem();
                a.pkg = ri.activityInfo.packageName;
                a.cn = new ComponentName(a.pkg, ri.activityInfo.name);
                a.label = String.valueOf(ri.loadLabel(pm));
                out.add(a);
            }
            Collections.sort(out, (x, y) -> x.label.compareToIgnoreCase(y.label));
            runOnUiThread(() -> {
                apps.clear();
                apps.addAll(out);
                adapter.notifyDataSetChanged();
                ensureDefaultDock();
                refreshDock();
                refreshSubtitles();
            });
        }).start();
    }

    private AppItem findApp(String pkg) {
        for (AppItem a : apps) {
            if (a.pkg.equals(pkg)) return a;
        }
        return null;
    }

    private Drawable getIcon(AppItem a) {
        String key = a.cn.flattenToString();
        Drawable d = iconCache.get(key);
        if (d == null) {
            try {
                d = pm.getActivityIcon(a.cn);
            } catch (PackageManager.NameNotFoundException e) {
                d = pm.getDefaultActivityIcon();
            }
            iconCache.put(key, d);
        }
        return d;
    }

    private void launch(AppItem a) {
        Intent i = new Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(a.cn)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        startSafe(i);
    }

    private boolean launchPkg(String pkg) {
        Intent i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) return false;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void startSafe(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("Não foi possível abrir");
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ cartões

    private Intent navIntent() {
        return Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MAPS);
    }

    private Intent musicIntent() {
        return Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC);
    }

    private void openPreferred(String key, Intent fallback) {
        String pkg = prefs.getString(key, null);
        if (pkg != null && launchPkg(pkg)) return;
        try {
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(fallback);
        } catch (Exception e) {
            toast("Nenhum app encontrado. Segure o cartão para escolher um.");
        }
    }

    private String subtitle(String key) {
        String pkg = prefs.getString(key, null);
        if (pkg == null) return DEFAULT_LABEL;
        AppItem a = findApp(pkg);
        return a != null ? a.label : DEFAULT_LABEL;
    }

    private void refreshSubtitles() {
        navSub.setText(subtitle(KEY_NAV));
        phoneSub.setText(subtitle(KEY_PHONE));
        settingsSub.setText(subtitle(KEY_SETTINGS));
    }

    private void showAppPicker(final String key, String title) {
        final List<AppItem> snapshot = new ArrayList<>(apps);
        CharSequence[] names = new CharSequence[snapshot.size() + 1];
        names[0] = DEFAULT_LABEL;
        for (int i = 0; i < snapshot.size(); i++) names[i + 1] = snapshot.get(i).label;
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(names, (d, which) -> {
                    if (which == 0) {
                        prefs.edit().remove(key).apply();
                    } else {
                        prefs.edit().putString(key, snapshot.get(which - 1).pkg).apply();
                    }
                    refreshSubtitles();
                })
                .show();
    }

    private void showAppMenu(final AppItem a) {
        final boolean pinned = getDock().contains(a.pkg);
        final String[] items = {
                pinned ? "Remover do dock" : "Fixar no dock",
                "Usar como Navegação",
                "Usar como Música",
                "Usar como Telefone",
                "Usar como Ajustes",
                "Informações do app",
                "Desinstalar"
        };
        new AlertDialog.Builder(this)
                .setTitle(a.label)
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0:
                            togglePin(a.pkg);
                            break;
                        case 1:
                            setPref(KEY_NAV, a.pkg);
                            break;
                        case 2:
                            setPref(KEY_MUSIC, a.pkg);
                            break;
                        case 3:
                            setPref(KEY_PHONE, a.pkg);
                            break;
                        case 4:
                            setPref(KEY_SETTINGS, a.pkg);
                            break;
                        case 5:
                            startSafe(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:" + a.pkg)));
                            break;
                        case 6:
                            startSafe(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)));
                            break;
                        default:
                            break;
                    }
                })
                .show();
    }

    private void setPref(String key, String pkg) {
        prefs.edit().putString(key, pkg).apply();
        refreshSubtitles();
    }

    // ------------------------------------------------------------------ dock

    private List<String> getDock() {
        String s = prefs.getString(KEY_DOCK, "");
        List<String> out = new ArrayList<>();
        if (s != null && s.length() > 0) {
            for (String p : s.split(",")) {
                if (p.length() > 0) out.add(p);
            }
        }
        return out;
    }

    private void saveDock(List<String> list) {
        prefs.edit().putString(KEY_DOCK, TextUtils.join(",", list)).apply();
        refreshDock();
    }

    private void togglePin(String pkg) {
        List<String> dock = getDock();
        if (dock.contains(pkg)) {
            dock.remove(pkg);
        } else {
            if (dock.size() >= MAX_DOCK) {
                toast("Dock cheia (máximo " + MAX_DOCK + ")");
                return;
            }
            dock.add(pkg);
        }
        saveDock(dock);
    }

    private void ensureDefaultDock() {
        if (prefs.contains(KEY_DOCK)) return;
        String[] candidates = {
                "com.waze",
                "com.google.android.apps.maps",
                "com.spotify.music",
                "com.google.android.apps.youtube.music",
                "com.google.android.youtube",
                "com.android.chrome"
        };
        List<String> d = new ArrayList<>();
        for (String c : candidates) {
            if (d.size() < MAX_DOCK && findApp(c) != null) d.add(c);
        }
        prefs.edit().putString(KEY_DOCK, TextUtils.join(",", d)).apply();
    }

    private void refreshDock() {
        dockApps.removeAllViews();
        for (String pkg : getDock()) {
            final AppItem a = findApp(pkg);
            if (a == null) continue;
            ImageView iv = new ImageView(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(60), dp(60));
            lp.setMargins(0, dp(5), 0, dp(5));
            iv.setLayoutParams(lp);
            iv.setPadding(dp(6), dp(6), dp(6), dp(6));
            iv.setBackgroundResource(R.drawable.bg_item);
            iv.setImageDrawable(getIcon(a));
            iv.setContentDescription(a.label);
            iv.setOnClickListener(v -> launch(a));
            iv.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this)
                        .setTitle(a.label)
                        .setItems(new String[]{"Remover do dock"}, (d, which) -> togglePin(a.pkg))
                        .show();
                return true;
            });
            dockApps.addView(iv);
        }
    }

    // ------------------------------------------------------------------ gaveta

    private boolean isDrawerOpen() {
        return drawer.getVisibility() == View.VISIBLE;
    }

    private void showDrawer() {
        drawer.animate().cancel();
        drawer.setAlpha(0f);
        drawer.setVisibility(View.VISIBLE);
        drawer.animate().alpha(1f).setDuration(150).start();
    }

    private void hideDrawer() {
        if (!isDrawerOpen()) return;
        drawer.animate().cancel();
        drawer.animate().alpha(0f).setDuration(120)
                .withEndAction(() -> drawer.setVisibility(View.GONE)).start();
    }

    private class AppAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return apps.size();
        }

        @Override
        public Object getItem(int position) {
            return apps.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Holder h;
            if (convertView == null) {
                LinearLayout row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setGravity(Gravity.CENTER_HORIZONTAL);
                row.setPadding(dp(4), dp(10), dp(4), dp(10));
                row.setBackgroundResource(R.drawable.bg_item);

                ImageView iv = new ImageView(MainActivity.this);
                iv.setLayoutParams(new LinearLayout.LayoutParams(dp(56), dp(56)));

                TextView tv = new TextView(MainActivity.this);
                LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                tlp.topMargin = dp(6);
                tv.setLayoutParams(tlp);
                tv.setTextColor(0xFFE6EDF5);
                tv.setTextSize(13);
                tv.setSingleLine(true);
                tv.setEllipsize(TextUtils.TruncateAt.END);
                tv.setGravity(Gravity.CENTER);

                row.addView(iv);
                row.addView(tv);
                h = new Holder();
                h.icon = iv;
                h.label = tv;
                row.setTag(h);
                convertView = row;
            } else {
                h = (Holder) convertView.getTag();
            }
            AppItem a = apps.get(position);
            h.icon.setImageDrawable(getIcon(a));
            h.label.setText(a.label);
            return convertView;
        }
    }

    private static class Holder {
        ImageView icon;
        TextView label;
    }

    // ------------------------------------------------------------------ mídia

    private void mediaKey(int code) {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
    }

    private final Runnable mediaPoll = new Runnable() {
        @Override
        public void run() {
            updateMedia();
            if (visible) handler.postDelayed(this, MEDIA_POLL_MS);
        }
    };

    private void setTextIfChanged(TextView tv, String text) {
        if (!text.contentEquals(tv.getText())) tv.setText(text);
    }

    private void updateMedia() {
        try {
            MediaSessionManager msm = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
            List<MediaController> list = msm.getActiveSessions(new ComponentName(this, MediaListener.class));
            mediaAccess = true;

            MediaController pick = null;
            for (MediaController c : list) {
                PlaybackState s = c.getPlaybackState();
                if (s != null && s.getState() == PlaybackState.STATE_PLAYING) {
                    pick = c;
                    break;
                }
            }
            if (pick == null && !list.isEmpty()) pick = list.get(0);

            if (pick == null) {
                setTextIfChanged(musicTitle, "Nenhuma música tocando");
                setTextIfChanged(musicArtist, "Toque para abrir o player");
                btnPlay.setImageResource(R.drawable.ic_play);
                return;
            }

            MediaMetadata md = pick.getMetadata();
            String title = md != null ? md.getString(MediaMetadata.METADATA_KEY_TITLE) : null;
            String artist = md != null ? md.getString(MediaMetadata.METADATA_KEY_ARTIST) : null;
            if (artist == null && md != null) artist = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
            setTextIfChanged(musicTitle, title != null ? title : "Música");
            setTextIfChanged(musicArtist, artist != null ? artist : "");

            PlaybackState s = pick.getPlaybackState();
            boolean playing = s != null && s.getState() == PlaybackState.STATE_PLAYING;
            btnPlay.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
        } catch (SecurityException e) {
            mediaAccess = false;
            setTextIfChanged(musicTitle, "Música");
            setTextIfChanged(musicArtist, "Toque aqui para mostrar a faixa atual");
        } catch (Exception e) {
            // Alguns aparelhos de multimídia não implementam MediaSessionManager direito; ignora.
        }
    }

    // ------------------------------------------------------------------ util

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
