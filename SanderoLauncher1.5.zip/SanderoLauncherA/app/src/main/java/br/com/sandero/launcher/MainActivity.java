package br.com.sandero.launcher;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.MotionEvent;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import java.util.Calendar;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Sandero Launcher: launcher leve para central multimídia (tela deitada).
 * Estilo vidro (liquid glass), tema vermelho, clima, velocidade por GPS e modo papel de parede.
 * Sem bibliotecas externas e sem arquivos de layout: a interface é montada em código.
 */
public class MainActivity extends Activity {

    // ------------------------------------------------------------------ constantes

    private static final String PREFS = "launcher";
    private static final String KEY_DOCK = "dock";
    private static final String KEY_NAV = "nav_pkg";
    private static final String KEY_MUSIC = "music_pkg";
    private static final String KEY_PHONE = "phone_pkg";
    private static final String KEY_SETTINGS = "settings_pkg";

    private static final String K_ACCENT = "accent";
    private static final String K_BG = "bg";
    private static final String K_STYLE = "style";
    private static final String K_CAR_NAME = "car_name";
    private static final String K_CLOCK24 = "clock24";
    private static final String K_ICON = "icon_size";
    private static final String K_REFLECT = "reflect";
    private static final String K_MODE = "mode";
    private static final String K_TEMP_F = "temp_f";
    private static final String K_MPH = "mph";
    private static final String K_OWNER = "owner";
    private static final String K_SPLASH = "splash";
    private static final String K_SYSBAR = "sysbar";
    private static final String K_ANIM = "anim";
    private static final String K_ASKED_LOC = "asked_loc";
    private static final String K_W_HAS = "w_has";
    private static final String K_W_TEMP = "w_temp";
    private static final String K_W_CODE = "w_code";
    private static final String K_W_MAX = "w_max";
    private static final String K_W_MIN = "w_min";

    private static final String F_CAR = "car.png";
    private static final String F_WALL = "wall.jpg";
    private static final int REQ_CAR = 11;
    private static final int REQ_WALL = 12;
    private static final int REQ_LOC = 21;

    private static final int MAX_DOCK = 5;
    private static final long POLL_MS = 2000;
    private static final long WEATHER_EVERY_MS = 30 * 60 * 1000L;
    private static final String DEFAULT_LABEL = "Padrão do sistema";

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final int WHITE = 0xFFFFFFFF;
    private static final int MUTED = 0xFFB4BCC8;
    private static final int DARK = 0xFF0A0C10;

    private static final String[] ACCENT_NAMES = {"Vermelho", "Azul", "Verde", "Laranja", "Roxo", "Prata"};
    private static final int[] ACCENTS = {0xFFFF3B47, 0xFF2DD4FF, 0xFF34D399, 0xFFFFA62B, 0xFFA78BFA, 0xFFE6EDF5};

    private static final String[] BG_NAMES = {"Grafite", "Preto puro", "Vinho escuro", "Azul noite", "Papel de parede"};
    private static final int[][] BG_COLORS = {
            {0xFF1C1F26, 0xFF101217, 0xFF050607},
            {0xFF000000, 0xFF000000, 0xFF000000},
            {0xFF2E0E14, 0xFF170709, 0xFF070304},
            {0xFF0E1A2B, 0xFF09111C, 0xFF04070C}
    };

    private static final int[] ICON_DP = {44, 56, 72};
    private static final int[] COL_DP = {104, 124, 152};
    private static final float[] LABEL_SP = {12, 13, 15};

    // tipos de ícone
    private static final int I_APPS = 0, I_NAV = 1, I_MUSIC = 2, I_PHONE = 3, I_TUNE = 4,
            I_PLAY = 5, I_PAUSE = 6, I_PREV = 7, I_NEXT = 8, I_CLOSE = 9, I_GEAR = 10,
            I_IMAGE = 11, I_SUN = 12, I_PARTLY = 13, I_CLOUD = 14, I_RAIN = 15, I_STORM = 16,
            I_WIFI = 17, I_BT = 18, I_GPS = 19;

    /** A abertura (logo + saudação) toca só uma vez por inicialização do processo. */
    private static boolean splashShown = false;

    private interface IntCb {
        void run(int i);
    }

    static class AppItem {
        String label;
        String pkg;
        ComponentName cn;
    }

    private static class MusicViews {
        ImageView cover;
        TextView title, artist;
        ImageButton prev, play, next;
        int phPad = 24; // margem do ícone quando não há capa (dp)
    }

    private static class WeatherViews {
        ImageView icon;
        TextView temp, desc, range;
    }

    // ------------------------------------------------------------------ estado

    private final List<AppItem> apps = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final LruCache<String, Drawable> iconCache = new LruCache<>(80);

    private final List<MusicViews> musics = new ArrayList<>();
    private final List<WeatherViews> weathers = new ArrayList<>();
    private final List<TextView> speedNums = new ArrayList<>();

    private SharedPreferences prefs;
    private PackageManager pm;

    private LinearLayout dockApps;
    private View drawer;
    private LinearLayout settingsPanel;
    private LinearLayout settingsRows;
    private AppAdapter adapter;
    private TextView navSub, phoneSub, settingsSub;

    // barra de status própria, saudação e abertura
    private TextView statusGreeting;
    private ImageView stWifi, stBt, stGps;
    private FrameLayout splash;
    private final List<View> enterViews = new ArrayList<>();
    private boolean splashRunning = false;
    private int splashToken = 0;
    private ImageView splashLogo;
    private LinearLayout splashGreet;
    private TextView splashHi, splashName;

    // tema
    private int accent = ACCENTS[0];
    private boolean glass = true;
    private int mode = 0;
    private boolean tempF = false;
    private boolean mph = false;

    // mídia
    private boolean mediaAccess = false;
    private boolean visible = false;
    private String curTitle = "Nenhuma música tocando";
    private String curArtist = "Toque para abrir o player";
    private Bitmap curCover = null;
    private boolean curPlaying = false;
    private String lastCoverKey = "none";

    // clima / GPS
    private LocationManager locManager;
    private boolean hasFix = false;
    private long lastGpsTime = 0;
    private float speedMs = 0f;
    private boolean weatherBusy = false;
    private long lastWeatherFetch = 0;
    private String weatherStatus = "Aguardando GPS e internet";

    // imagens em cache
    private Bitmap wallBmp;
    private String wallKey = "";

    // ------------------------------------------------------------------ ciclo de vida

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        pm = getPackageManager();
        locManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        setContentView(buildUi());

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);

        refreshSubtitles();
        refreshWeather();
        refreshSpeed();
        loadApps();
        applySystemUi();
        updateStatus();
        if (!splashShown && prefs.getBoolean(K_SPLASH, true) && savedInstanceState == null) {
            playSplash();
        } else {
            splashShown = true;
            playEnter();
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applySystemUi();
    }

    /** Esconde a barra de status/navegação do Android (a launcher desenha a própria). */
    private void applySystemUi() {
        try {
            View decor = getWindow().getDecorView();
            if (prefs.getBoolean(K_SYSBAR, true)) {
                getWindow().setStatusBarColor(Color.TRANSPARENT);
                getWindow().setNavigationBarColor(Color.TRANSPARENT);
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            } else {
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        applySystemUi();
        handler.removeCallbacks(poll);
        handler.post(poll);
        if (!hasLocationPermission() && !prefs.getBoolean(K_ASKED_LOC, false)) {
            prefs.edit().putBoolean(K_ASKED_LOC, true).apply();
            if (Build.VERSION.SDK_INT >= 23) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOC);
            }
        }
        startLocation();
    }

    @Override
    protected void onPause() {
        super.onPause();
        visible = false;
        handler.removeCallbacks(poll);
        stopLocation();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(pkgReceiver);
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        closeOverlays();
    }

    @Override
    public void onBackPressed() {
        closeOverlays();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOC) startLocation();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        if (requestCode == REQ_CAR) {
            saveImage(uri, F_CAR, 1000, true);
        } else if (requestCode == REQ_WALL) {
            saveImage(uri, F_WALL, 1280, false);
        }
    }

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            loadApps();
        }
    };

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            updateMedia();
            if (hasFix && System.currentTimeMillis() - lastGpsTime > 6000) {
                hasFix = false;
                refreshSpeed();
            }
            updateStatus();
            if (visible) handler.postDelayed(this, POLL_MS);
        }
    };

    private boolean isOverlayOpen() {
        return drawer.getVisibility() == View.VISIBLE || settingsPanel.getVisibility() == View.VISIBLE;
    }

    private void closeOverlays() {
        if (drawer.getVisibility() == View.VISIBLE) hideDrawer();
        if (settingsPanel.getVisibility() == View.VISIBLE) hideSettings();
    }

    // ------------------------------------------------------------------ tema

    private void loadTheme() {
        int ai = prefs.getInt(K_ACCENT, 0);
        if (ai < 0 || ai >= ACCENTS.length) ai = 0;
        accent = ACCENTS[ai];
        glass = prefs.getInt(K_STYLE, 0) == 0;
        mode = prefs.getInt(K_MODE, 0);
        tempF = prefs.getBoolean(K_TEMP_F, false);
        mph = prefs.getBoolean(K_MPH, false);
        wFromPrefs();
    }

    private int onAccent() {
        double lum = (0.299 * Color.red(accent) + 0.587 * Color.green(accent) + 0.114 * Color.blue(accent)) / 255.0;
        return lum > 0.62 ? DARK : WHITE;
    }

    private int darker(int c) {
        float[] hsv = new float[3];
        Color.colorToHSV(c, hsv);
        hsv[2] *= 0.78f;
        return Color.HSVToColor(hsv);
    }

    private GradientDrawable shape(int fill, int radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }

    private StateListDrawable states(Drawable pressed, Drawable normal) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, pressed);
        s.addState(new int[]{}, normal);
        return s;
    }

    /** Efeito "vidro": base escura translúcida + brilho claro no topo + borda fina. */
    private Drawable glassLayer(int radiusDp, boolean pressed) {
        GradientDrawable tint = new GradientDrawable();
        tint.setColor(0x59000000);
        tint.setCornerRadius(dp(radiusDp));
        GradientDrawable body = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                pressed ? new int[]{0x66FFFFFF, 0x2EFFFFFF} : new int[]{0x3DFFFFFF, 0x0FFFFFFF});
        body.setCornerRadius(dp(radiusDp));
        body.setStroke(dp(1), pressed ? accent : 0x55FFFFFF);
        return new LayerDrawable(new Drawable[]{tint, body});
    }

    private Drawable bgCard(int radiusDp) {
        if (glass) return states(glassLayer(radiusDp, true), glassLayer(radiusDp, false));
        return states(shape(0xFF222831, radiusDp, accent), shape(0xFF14181E, radiusDp, 0xFF272D36));
    }

    private Drawable bgItem() {
        return states(shape(0x33FFFFFF, 18, 0), shape(0x00000000, 18, 0));
    }

    private Drawable bgPlay() {
        GradientDrawable pressed = new GradientDrawable();
        pressed.setShape(GradientDrawable.OVAL);
        pressed.setColor(darker(accent));
        GradientDrawable normal = new GradientDrawable();
        normal.setShape(GradientDrawable.OVAL);
        normal.setColor(accent);
        return states(pressed, normal);
    }

    // ------------------------------------------------------------------ interface

    private View buildUi() {
        loadTheme();
        musics.clear();
        enterViews.clear();
        weathers.clear();
        speedNums.clear();

        final boolean wallMode = mode == 1;
        FrameLayout root = new FrameLayout(this);

        int bgIndex = prefs.getInt(K_BG, 2);
        if (bgIndex < 0 || bgIndex >= BG_NAMES.length) bgIndex = 2;
        Bitmap wall = (wallMode || bgIndex == 4) ? loadWallpaper() : null;
        if (wall != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(wall);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            root.addView(iv, new FrameLayout.LayoutParams(MATCH, MATCH));
            View shade = new View(this);
            shade.setBackgroundColor(wallMode ? 0x26000000 : 0xB3000000);
            root.addView(shade, new FrameLayout.LayoutParams(MATCH, MATCH));
        } else {
            int[] cols = BG_COLORS[bgIndex < 4 ? bgIndex : 2];
            root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, cols));
        }

        // ---------- HOME ----------
        LinearLayout home = new LinearLayout(this);
        home.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(home, new FrameLayout.LayoutParams(MATCH, MATCH));

        // Dock flutuante de vidro
        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.VERTICAL);
        dock.setGravity(Gravity.CENTER_HORIZONTAL);
        dock.setBackground(glassLayer(32, false));
        dock.setPadding(0, dp(8), 0, dp(8));
        LinearLayout.LayoutParams dockLp = new LinearLayout.LayoutParams(dp(84), MATCH);
        dockLp.setMargins(dp(12), dp(12), 0, dp(12));
        home.addView(dock, dockLp);

        dockApps = new LinearLayout(this);
        dockApps.setOrientation(LinearLayout.VERTICAL);
        dockApps.setGravity(Gravity.CENTER);
        dock.addView(dockApps, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        ImageView btnApps = icon(I_APPS, WHITE, 16);
        btnApps.setBackground(bgItem());
        pressable(btnApps);
        btnApps.setOnClickListener(v -> {
            if (drawer.getVisibility() == View.VISIBLE) hideDrawer(); else showDrawer();
        });
        dock.addView(btnApps, new LinearLayout.LayoutParams(dp(60), dp(60)));

        // Conteúdo
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(10), dp(20), dp(16));
        home.addView(content, new LinearLayout.LayoutParams(0, MATCH, 1f));

        // Barra de status própria (transparente): saudação + Wi-Fi / Bluetooth / GPS
        LinearLayout statusBar = new LinearLayout(this);
        statusBar.setGravity(Gravity.CENTER_VERTICAL);
        statusGreeting = text(greetingText(), 13, 0xE6FFFFFF, false);
        statusGreeting.setSingleLine(true);
        statusGreeting.setEllipsize(TextUtils.TruncateAt.END);
        statusGreeting.setLetterSpacing(0.04f);
        statusGreeting.setShadowLayer(dp(4), 0, dp(1), 0x99000000);
        statusBar.addView(statusGreeting, new LinearLayout.LayoutParams(0, WRAP, 1f));
        stGps = icon(I_GPS, 0x55FFFFFF, 0);
        stBt = icon(I_BT, 0x55FFFFFF, 0);
        stWifi = icon(I_WIFI, 0x55FFFFFF, 0);
        ImageView[] sts = {stGps, stBt, stWifi};
        for (ImageView st : sts) {
            LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(dp(18), dp(18));
            stLp.leftMargin = dp(14);
            statusBar.addView(st, stLp);
        }
        content.addView(statusBar, new LinearLayout.LayoutParams(MATCH, dp(26)));

        // Cabeçalho: hora/data | clima | botões
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        content.addView(header, new LinearLayout.LayoutParams(MATCH, WRAP));
        enterViews.add(header);

        LinearLayout times = new LinearLayout(this);
        times.setOrientation(LinearLayout.VERTICAL);
        header.addView(times, new LinearLayout.LayoutParams(0, WRAP, 1f));

        String fmt = prefs.getBoolean(K_CLOCK24, true) ? "HH:mm" : "h:mm a";
        TextClock clock = new TextClock(this);
        clock.setFormat24Hour(fmt);
        clock.setFormat12Hour(fmt);
        clock.setTextSize(52);
        clock.setTextColor(WHITE);
        clock.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        clock.setIncludeFontPadding(false);
        clock.setShadowLayer(dp(6), 0, dp(1), 0x99000000);
        times.addView(clock);

        TextClock date = new TextClock(this);
        date.setFormat24Hour("EEEE, d 'de' MMMM");
        date.setFormat12Hour("EEEE, d 'de' MMMM");
        date.setTextSize(14);
        date.setTextColor(MUTED);
        date.setAllCaps(true);
        date.setLetterSpacing(0.08f);
        date.setShadowLayer(dp(6), 0, dp(1), 0x99000000);
        times.addView(date);

        LinearLayout chip = new LinearLayout(this);
        chip.setGravity(Gravity.CENTER_VERTICAL);
        chip.setBackground(glassLayer(100, false));
        chip.setPadding(dp(14), dp(8), dp(18), dp(8));
        chip.addView(weatherBlock(30, 20, 11, false));
        LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        chipLp.rightMargin = dp(12);
        header.addView(chip, chipLp);

        ImageView btnMode = icon(I_IMAGE, WHITE, 12);
        btnMode.setBackground(states(glassLayer(100, true), glassLayer(100, false)));
        btnMode.setContentDescription("Alternar painel / papel de parede");
        pressable(btnMode);
        btnMode.setOnClickListener(v -> {
            prefs.edit().putInt(K_MODE, mode == 1 ? 0 : 1).apply();
            rebuild(false);
        });
        LinearLayout.LayoutParams bmLp = new LinearLayout.LayoutParams(dp(48), dp(48));
        bmLp.rightMargin = dp(8);
        header.addView(btnMode, bmLp);

        ImageView btnGear = icon(I_GEAR, WHITE, 12);
        btnGear.setBackground(states(glassLayer(100, true), glassLayer(100, false)));
        btnGear.setContentDescription("Ajustes do launcher");
        pressable(btnGear);
        btnGear.setOnClickListener(v -> showSettings());
        header.addView(btnGear, new LinearLayout.LayoutParams(dp(48), dp(48)));

        if (wallMode) {
            content.addView(new View(this), new LinearLayout.LayoutParams(MATCH, 0, 1f));
            content.addView(buildWallpaperBar(), new LinearLayout.LayoutParams(MATCH, WRAP));
        } else {
            LinearLayout.LayoutParams cardsLp = new LinearLayout.LayoutParams(MATCH, 0, 1f);
            cardsLp.topMargin = dp(12);
            content.addView(buildCards(), cardsLp);
        }

        // ---------- GAVETA DE APPS ----------
        LinearLayout drawerView = new LinearLayout(this);
        drawerView.setOrientation(LinearLayout.VERTICAL);
        drawerView.setBackgroundColor(0xEB050608);
        drawerView.setClickable(true);
        drawerView.setVisibility(View.GONE);
        drawer = drawerView;
        root.addView(drawerView, new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout dHeader = new LinearLayout(this);
        dHeader.setGravity(Gravity.CENTER_VERTICAL);
        dHeader.setPadding(dp(32), dp(12), dp(16), 0);
        dHeader.addView(text("Aplicativos", 22, WHITE, true), new LinearLayout.LayoutParams(0, WRAP, 1f));
        ImageView btnClose = icon(I_CLOSE, WHITE, 14);
        btnClose.setBackground(bgItem());
        btnClose.setOnClickListener(v -> hideDrawer());
        dHeader.addView(btnClose, new LinearLayout.LayoutParams(dp(56), dp(56)));
        drawerView.addView(dHeader, new LinearLayout.LayoutParams(MATCH, WRAP));

        int sz = prefs.getInt(K_ICON, 1);
        if (sz < 0 || sz > 2) sz = 1;
        GridView grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(dp(COL_DP[sz]));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setHorizontalSpacing(dp(8));
        grid.setVerticalSpacing(dp(8));
        grid.setPadding(dp(24), dp(24), dp(24), dp(24));
        grid.setClipToPadding(false);
        grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        grid.setVerticalScrollBarEnabled(false);
        adapter = new AppAdapter(sz);
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent, view, position, id) -> {
            launch(apps.get(position));
            hideDrawer();
        });
        grid.setOnItemLongClickListener((parent, view, position, id) -> {
            showAppMenu(apps.get(position));
            return true;
        });
        drawerView.addView(grid, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        // ---------- AJUSTES DO LAUNCHER ----------
        settingsPanel = new LinearLayout(this);
        settingsPanel.setOrientation(LinearLayout.VERTICAL);
        settingsPanel.setBackgroundColor(0xF2050608);
        settingsPanel.setClickable(true);
        settingsPanel.setVisibility(View.GONE);
        root.addView(settingsPanel, new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout sHeader = new LinearLayout(this);
        sHeader.setGravity(Gravity.CENTER_VERTICAL);
        sHeader.setPadding(dp(32), dp(12), dp(16), 0);
        sHeader.addView(text("Ajustes do launcher", 22, WHITE, true), new LinearLayout.LayoutParams(0, WRAP, 1f));
        ImageView sClose = icon(I_CLOSE, WHITE, 14);
        sClose.setBackground(bgItem());
        sClose.setOnClickListener(v -> hideSettings());
        sHeader.addView(sClose, new LinearLayout.LayoutParams(dp(56), dp(56)));
        settingsPanel.addView(sHeader, new LinearLayout.LayoutParams(MATCH, WRAP));

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        settingsRows = new LinearLayout(this);
        settingsRows.setOrientation(LinearLayout.VERTICAL);
        settingsRows.setPadding(dp(32), dp(12), dp(32), dp(24));
        sv.addView(settingsRows, new ScrollView.LayoutParams(MATCH, WRAP));
        settingsPanel.addView(sv, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        // ---------- ABERTURA: logo Renault Sport + saudação ----------
        splash = new FrameLayout(this);
        splash.setBackgroundColor(0xFF000000);
        splash.setClickable(true);
        splash.setVisibility(View.GONE);
        splashLogo = new ImageView(this);
        splashLogo.setAdjustViewBounds(true);
        splashLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        Bitmap logo = loadAsset("logo_rs.png");
        if (logo != null) splashLogo.setImageBitmap(logo);
        splash.addView(splashLogo, new FrameLayout.LayoutParams(dp(560), WRAP, Gravity.CENTER));
        splashGreet = new LinearLayout(this);
        splashGreet.setOrientation(LinearLayout.VERTICAL);
        splashGreet.setGravity(Gravity.CENTER_HORIZONTAL);
        splashHi = text("", 44, WHITE, false);
        splashHi.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        splashName = text("", 24, accent, true);
        splashName.setLetterSpacing(0.12f);
        splashGreet.addView(splashHi);
        LinearLayout.LayoutParams snLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        snLp.topMargin = dp(8);
        splashGreet.addView(splashName, snLp);
        splashGreet.setAlpha(0f);
        splash.addView(splashGreet, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER));
        root.addView(splash, new FrameLayout.LayoutParams(MATCH, MATCH));

        return root;
    }

    /** Painel completo: carro | música | navegação + telefone + ajustes. */
    private View buildCards() {
        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.HORIZONTAL);

        // --- Carro (foto com brilho/reflexo) + velocidade + nome
        FrameLayout carFrame = new FrameLayout(this);
        CarView carView = new CarView(this);
        carView.set(loadCar(), accent, prefs.getBoolean(K_REFLECT, false));
        carFrame.addView(carView, new FrameLayout.LayoutParams(MATCH, MATCH));
        carView.setLongClickable(true);
        carView.setOnLongClickListener(v -> {
            imageMenu("Foto do carro", REQ_CAR, F_CAR);
            return true;
        });

        LinearLayout speedBox = new LinearLayout(this);
        speedBox.setOrientation(LinearLayout.HORIZONTAL);
        speedBox.setGravity(Gravity.BOTTOM);
        speedBox.setBackground(glassLayer(26, false));
        speedBox.setPadding(dp(16), dp(6), dp(16), dp(8));
        TextView num = text("--", 40, WHITE, false);
        num.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        num.setIncludeFontPadding(false);
        speedNums.add(num);
        speedBox.addView(num);
        TextView unit = text(mph ? "mph" : "km/h", 13, MUTED, false);
        LinearLayout.LayoutParams unitLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        unitLp.leftMargin = dp(6);
        unitLp.bottomMargin = dp(5);
        speedBox.addView(unit, unitLp);
        FrameLayout.LayoutParams sbLp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM | Gravity.LEFT);
        sbLp.setMargins(dp(4), 0, 0, dp(4));
        carFrame.addView(speedBox, sbLp);

        TextView car = text(prefs.getString(K_CAR_NAME, "SANDERO RS"), 15, accent, true);
        car.setLetterSpacing(0.3f);
        car.setShadowLayer(dp(6), 0, dp(1), 0xCC000000);
        FrameLayout.LayoutParams cnLp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM | Gravity.RIGHT);
        cnLp.setMargins(0, 0, dp(8), dp(10));
        carFrame.addView(car, cnLp);
        cards.addView(carFrame, new LinearLayout.LayoutParams(0, MATCH, 1.35f));

        // --- Música (a capa preenche o cartão inteiro)
        FrameLayout cardMusic = new FrameLayout(this);
        cardMusic.setBackground(bgCard(28));
        cardMusic.setClickable(true);
        cardMusic.setFocusable(true);
        pressable(cardMusic);

        MusicViews mv = newMusic(0, 22, 15);
        mv.phPad = 90;
        final int cardRad = dp(28);
        mv.cover.setBackground(null);
        mv.cover.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), cardRad);
            }
        });
        applyMusic(mv);
        cardMusic.addView(mv.cover, new FrameLayout.LayoutParams(MATCH, MATCH));

        View shade = new View(this);
        GradientDrawable sg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x66000000, 0x00000000, 0x99000000, 0xEB000000});
        sg.setCornerRadius(cardRad);
        shade.setBackground(sg);
        cardMusic.addView(shade, new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout mCol = new LinearLayout(this);
        mCol.setOrientation(LinearLayout.VERTICAL);
        mCol.setPadding(dp(20), dp(18), dp(20), dp(16));

        LinearLayout mHeader = new LinearLayout(this);
        mHeader.setGravity(Gravity.CENTER_VERTICAL);
        mHeader.addView(icon(I_MUSIC, accent, 0), new LinearLayout.LayoutParams(dp(22), dp(22)));
        TextView mLabel = text("MÚSICA", 12, accent, true);
        mLabel.setLetterSpacing(0.2f);
        mLabel.setShadowLayer(dp(4), 0, dp(1), 0x99000000);
        LinearLayout.LayoutParams mlLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        mlLp.leftMargin = dp(8);
        mHeader.addView(mLabel, mlLp);
        mCol.addView(mHeader, new LinearLayout.LayoutParams(MATCH, WRAP));
        mCol.addView(new View(this), new LinearLayout.LayoutParams(MATCH, 0, 1f));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setClickable(true);
        info.addView(mv.title, new LinearLayout.LayoutParams(MATCH, WRAP));
        LinearLayout.LayoutParams artLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        artLp.topMargin = dp(3);
        info.addView(mv.artist, artLp);
        info.setOnClickListener(v -> onMusicInfoClick());
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        infoLp.bottomMargin = dp(10);
        mCol.addView(info, infoLp);
        mCol.addView(controls(mv, 56, 68), new LinearLayout.LayoutParams(MATCH, WRAP));
        cardMusic.addView(mCol, new FrameLayout.LayoutParams(MATCH, MATCH));

        cardMusic.setOnClickListener(v -> openPreferred(KEY_MUSIC, musicIntent()));
        cardMusic.setOnLongClickListener(v -> {
            showAppPicker(KEY_MUSIC, "App de música");
            return true;
        });
        LinearLayout.LayoutParams cmLp = new LinearLayout.LayoutParams(0, MATCH, 1.2f);
        cmLp.leftMargin = dp(14);
        cards.addView(cardMusic, cmLp);

        // --- Coluna: Navegação, Telefone, Ajustes
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(0, MATCH, 1f);
        colLp.leftMargin = dp(14);
        cards.addView(column, colLp);

        LinearLayout cardNav = card(20);
        cardNav.addView(icon(I_NAV, accent, 0), new LinearLayout.LayoutParams(dp(44), dp(44)));
        cardNav.addView(new View(this), new LinearLayout.LayoutParams(MATCH, 0, 1f));
        cardNav.addView(text("Navegação", 24, WHITE, true));
        navSub = text("", 13, MUTED, false);
        navSub.setSingleLine(true);
        cardNav.addView(navSub);
        cardNav.setOnClickListener(v -> openPreferred(KEY_NAV, navIntent()));
        cardNav.setOnLongClickListener(v -> {
            showAppPicker(KEY_NAV, "App de navegação");
            return true;
        });
        column.addView(cardNav, new LinearLayout.LayoutParams(MATCH, 0, 1.3f));

        LinearLayout cardPhone = smallCard(I_PHONE, "Telefone");
        phoneSub = (TextView) cardPhone.getTag();
        cardPhone.setOnClickListener(v -> openPreferred(KEY_PHONE, new Intent(Intent.ACTION_DIAL)));
        cardPhone.setOnLongClickListener(v -> {
            showAppPicker(KEY_PHONE, "App de telefone");
            return true;
        });
        LinearLayout.LayoutParams cpLp = new LinearLayout.LayoutParams(MATCH, 0, 0.7f);
        cpLp.topMargin = dp(14);
        column.addView(cardPhone, cpLp);

        LinearLayout cardSettings = smallCard(I_TUNE, "Ajustes");
        settingsSub = (TextView) cardSettings.getTag();
        cardSettings.setOnClickListener(v ->
                openPreferred(KEY_SETTINGS, new Intent(Settings.ACTION_SETTINGS)));
        cardSettings.setOnLongClickListener(v -> {
            showAppPicker(KEY_SETTINGS, "App de ajustes");
            return true;
        });
        LinearLayout.LayoutParams csLp = new LinearLayout.LayoutParams(MATCH, 0, 0.7f);
        csLp.topMargin = dp(14);
        column.addView(cardSettings, csLp);

        enterViews.add(carFrame);
        enterViews.add(cardMusic);
        enterViews.add(cardNav);
        enterViews.add(cardPhone);
        enterViews.add(cardSettings);
        return cards;
    }

    /** Modo papel de parede: só uma barra de vidro com música, clima e velocidade. */
    private View buildWallpaperBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(glassLayer(34, false));
        bar.setPadding(dp(18), dp(14), dp(18), dp(14));

        // música
        MusicViews mv = newMusic(88, 18, 13);
        LinearLayout music = new LinearLayout(this);
        music.setGravity(Gravity.CENTER_VERTICAL);
        music.addView(mv.cover, new LinearLayout.LayoutParams(dp(88), dp(88)));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setClickable(true);
        info.setOnClickListener(v -> onMusicInfoClick());
        info.addView(mv.title, new LinearLayout.LayoutParams(MATCH, WRAP));
        LinearLayout.LayoutParams artLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        artLp.topMargin = dp(2);
        info.addView(mv.artist, artLp);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        infoLp.leftMargin = dp(14);
        music.addView(info, infoLp);
        music.addView(controls(mv, 50, 58));
        bar.addView(music, new LinearLayout.LayoutParams(0, WRAP, 1.9f));

        bar.addView(divider());

        // clima
        LinearLayout w = new LinearLayout(this);
        w.setGravity(Gravity.CENTER);
        w.addView(weatherBlock(40, 28, 12, true));
        bar.addView(w, new LinearLayout.LayoutParams(0, WRAP, 1.1f));

        bar.addView(divider());

        // velocidade
        LinearLayout sp = new LinearLayout(this);
        sp.setGravity(Gravity.CENTER);
        TextView num = text("--", 44, WHITE, false);
        num.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        num.setIncludeFontPadding(false);
        speedNums.add(num);
        sp.addView(num);
        TextView unit = text(mph ? "mph" : "km/h", 13, MUTED, false);
        LinearLayout.LayoutParams uLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        uLp.leftMargin = dp(6);
        uLp.topMargin = dp(18);
        sp.addView(unit, uLp);
        bar.addView(sp, new LinearLayout.LayoutParams(0, WRAP, 0.8f));
        enterViews.add(bar);
        return bar;
    }

    private View divider() {
        View d = new View(this);
        d.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(1), dp(56));
        lp.setMargins(dp(12), 0, dp(12), 0);
        d.setLayoutParams(lp);
        return d;
    }

    private LinearLayout card(int padDp) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(bgCard(28));
        c.setClickable(true);
        c.setFocusable(true);
        c.setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp));
        pressable(c);
        return c;
    }

    private LinearLayout smallCard(int iconType, String title) {
        LinearLayout c = new LinearLayout(this);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setBackground(bgCard(28));
        c.setClickable(true);
        c.setFocusable(true);
        c.setPadding(dp(18), dp(10), dp(18), dp(10));
        c.addView(icon(iconType, accent, 0), new LinearLayout.LayoutParams(dp(30), dp(30)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        colLp.leftMargin = dp(14);
        col.addView(text(title, 18, WHITE, true));
        TextView sub = text("", 12, MUTED, false);
        sub.setSingleLine(true);
        col.addView(sub);
        c.addView(col, colLp);
        c.setTag(sub);
        pressable(c);
        return c;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private ImageView icon(int type, int color, int padDp) {
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(new IconDrawable(type, color));
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp));
        return iv;
    }

    private ImageButton button(int type, int color, int padDp) {
        ImageButton ib = new ImageButton(this);
        ib.setImageDrawable(new IconDrawable(type, color));
        ib.setScaleType(ImageView.ScaleType.FIT_CENTER);
        ib.setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp));
        pressable(ib);
        return ib;
    }

    private MusicViews newMusic(int coverDp, float titleSp, float artistSp) {
        MusicViews mv = new MusicViews();
        ImageView cv = new ImageView(this);
        cv.setBackground(shape(0x33FFFFFF, 18, 0));
        cv.setClipToOutline(true);
        final int rad = dp(18);
        cv.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), rad);
            }
        });
        mv.cover = cv;
        mv.title = text(curTitle, titleSp, WHITE, true);
        mv.title.setMaxLines(2);
        mv.title.setEllipsize(TextUtils.TruncateAt.END);
        mv.title.setShadowLayer(dp(4), 0, dp(1), 0x66000000);
        mv.artist = text(curArtist, artistSp, MUTED, false);
        mv.artist.setSingleLine(true);
        mv.artist.setEllipsize(TextUtils.TruncateAt.END);
        musics.add(mv);
        applyMusic(mv);
        return mv;
    }

    private LinearLayout controls(MusicViews mv, int btnDp, int playDp) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        int pad = btnDp / 4;
        mv.prev = button(I_PREV, WHITE, pad);
        mv.prev.setBackground(bgItem());
        mv.prev.setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS));
        row.addView(mv.prev, new LinearLayout.LayoutParams(dp(btnDp), dp(btnDp)));

        mv.play = button(curPlaying ? I_PAUSE : I_PLAY, onAccent(), playDp / 4);
        mv.play.setBackground(bgPlay());
        mv.play.setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(dp(playDp), dp(playDp));
        pl.leftMargin = dp(8);
        pl.rightMargin = dp(8);
        row.addView(mv.play, pl);

        mv.next = button(I_NEXT, WHITE, pad);
        mv.next.setBackground(bgItem());
        mv.next.setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT));
        row.addView(mv.next, new LinearLayout.LayoutParams(dp(btnDp), dp(btnDp)));
        return row;
    }

    private LinearLayout weatherBlock(int iconDp, float tempSp, float descSp, boolean withRange) {
        WeatherViews w = new WeatherViews();
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        w.icon = new ImageView(this);
        w.icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        row.addView(w.icon, new LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(WRAP, WRAP);
        cl.leftMargin = dp(10);
        row.addView(col, cl);
        w.temp = text("--°", tempSp, WHITE, true);
        w.temp.setIncludeFontPadding(false);
        col.addView(w.temp);
        w.desc = text("", descSp, MUTED, false);
        w.desc.setSingleLine(true);
        w.desc.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(w.desc);
        if (withRange) {
            w.range = text("", descSp, MUTED, false);
            w.range.setSingleLine(true);
            col.addView(w.range);
        }
        weathers.add(w);
        applyWeather(w);
        return row;
    }

    private void rebuild(boolean reopenSettings) {
        setContentView(buildUi());
        refreshSubtitles();
        refreshDock();
        refreshSpeed();
        applySystemUi();
        updateStatus();
        if (reopenSettings) showSettingsNoAnim(); else playEnter();
    }

    private void onMusicInfoClick() {
        if (!mediaAccess) {
            startSafe(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
        } else {
            openPreferred(KEY_MUSIC, musicIntent());
        }
    }

    // ------------------------------------------------------------------ foto do carro e papel de parede

    private Bitmap loadWallpaper() {
        java.io.File f = getFileStreamPath(F_WALL);
        String key = f.exists() ? "file" + f.lastModified() : "asset";
        if (wallBmp != null && key.equals(wallKey)) return wallBmp;
        Bitmap b = null;
        try {
            if (f.exists()) b = BitmapFactory.decodeFile(f.getPath());
            if (b == null) {
                InputStream in = getAssets().open("wallpaper.jpg");
                b = BitmapFactory.decodeStream(in);
                in.close();
                key = "asset";
            }
        } catch (Exception ignored) {
        }
        wallBmp = b;
        wallKey = key;
        return b;
    }

    private Bitmap loadCar() {
        try {
            java.io.File f = getFileStreamPath(F_CAR);
            if (f.exists()) {
                Bitmap b = BitmapFactory.decodeFile(f.getPath());
                if (b != null) return b;
            }
            InputStream in = getAssets().open("car_hero.png");
            Bitmap b = BitmapFactory.decodeStream(in);
            in.close();
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    private void pickImage(int req) {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, req);
        } catch (Exception e) {
            toast("Nenhum app de galeria ou arquivos encontrado");
        }
    }

    private void imageMenu(String title, final int req, final String file) {
        choose(title, new String[]{"Escolher da galeria", "Usar a imagem padrão"}, -1, i -> {
            if (i == 0) {
                pickImage(req);
            } else {
                deleteFile(file);
                wallBmp = null;
                rebuild(settingsPanel.getVisibility() == View.VISIBLE);
            }
        });
    }

    private Bitmap decodeUri(Uri u, int maxPx) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = getContentResolver().openInputStream(u);
            if (in == null) return null;
            BitmapFactory.decodeStream(in, null, o);
            in.close();
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= maxPx) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            in = getContentResolver().openInputStream(u);
            if (in == null) return null;
            Bitmap b = BitmapFactory.decodeStream(in, null, o2);
            in.close();
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    private void saveImage(final Uri uri, final String file, final int maxPx, final boolean png) {
        toast("Carregando imagem...");
        new Thread(() -> {
            boolean ok = false;
            Bitmap b = decodeUri(uri, maxPx);
            if (b != null) {
                try {
                    FileOutputStream out = openFileOutput(file, MODE_PRIVATE);
                    b.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, 90, out);
                    out.close();
                    ok = true;
                } catch (Exception ignored) {
                }
            }
            final boolean done = ok;
            runOnUiThread(() -> {
                if (done) {
                    wallBmp = null;
                    rebuild(true);
                } else {
                    toast("Não foi possível usar essa imagem");
                }
            });
        }).start();
    }

    /** Foto do carro com brilho da cor de destaque e reflexo opcional no chão. */
    private static class CarView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private Bitmap car, cache;
        private int accentColor;
        private boolean reflect;

        CarView(Context c) {
            super(c);
        }

        void set(Bitmap b, int accentColor, boolean reflect) {
            this.car = b;
            this.accentColor = accentColor;
            this.reflect = reflect;
            this.cache = null;
            invalidate();
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            cache = null;
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            int base = accentColor & 0x00FFFFFF;
            p.setShader(new RadialGradient(w / 2f, h * 0.55f, Math.max(w, h) * 0.55f,
                    base | 0x4D000000, base, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            if (car == null) return;
            if (cache == null) cache = render(w, h);
            c.drawBitmap(cache, 0, 0, null);
        }

        private Bitmap render(int w, int h) {
            Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(out);
            float maxW = w * 0.98f;
            float maxH = h * (reflect ? 0.66f : 0.94f);
            float s = Math.min(maxW / car.getWidth(), maxH / car.getHeight());
            float cw = car.getWidth() * s, ch = car.getHeight() * s;
            float left = (w - cw) / 2f;
            float top = reflect ? h * 0.04f : (h - ch) / 2f;
            float base = top + ch;
            RectF dst = new RectF(left, top, left + cw, base);
            Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            float r = getResources().getDisplayMetrics().density * 28f;
            Path clip = new Path();
            clip.addRoundRect(dst, r, r, Path.Direction.CW);
            boolean opaque = !car.hasAlpha();

            if (reflect) {
                float refH = Math.min(ch * 0.45f, h - base);
                if (refH > 2) {
                    int sc = c.saveLayer(0, base, w, base + refH, null);
                    c.save();
                    c.clipRect(left, base, left + cw, base + refH);
                    c.scale(1f, -1f, 0f, base);
                    c.drawBitmap(car, null, dst, bp);
                    c.restore();
                    Paint m = new Paint();
                    m.setShader(new LinearGradient(0, base, 0, base + refH, 0x59FFFFFF, 0x00FFFFFF,
                            Shader.TileMode.CLAMP));
                    m.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
                    c.drawRect(0, base, w, base + refH, m);
                    c.restoreToCount(sc);
                }
            }
            if (opaque) {
                c.save();
                c.clipPath(clip);
            }
            c.drawBitmap(car, null, dst, bp);
            if (opaque) c.restore();
            return out;
        }
    }

    // ------------------------------------------------------------------ ícones desenhados em código

    /** Ícones desenhados em grade 24x24, sem arquivos de imagem. */
    private static class IconDrawable extends Drawable {
        private final int type;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        IconDrawable(int type, int color) {
            this.type = type;
            p.setColor(color);
        }

        private void cloud(Canvas c, float dx, float dy) {
            c.drawCircle(8.5f + dx, 15f + dy, 4f, p);
            c.drawCircle(13.5f + dx, 12f + dy, 5f, p);
            c.drawCircle(18f + dx, 15.5f + dy, 3.5f, p);
            c.drawRect(8.5f + dx, 15f + dy, 18f + dx, 19f + dy, p);
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            float s = Math.min(b.width(), b.height()) / 24f;
            if (s <= 0) return;
            c.save();
            c.translate(b.left + (b.width() - 24 * s) / 2f, b.top + (b.height() - 24 * s) / 2f);
            c.scale(s, s);
            p.setStyle(Paint.Style.FILL);
            path.reset();
            switch (type) {
                case I_APPS:
                    for (int r = 0; r < 3; r++) {
                        for (int k = 0; k < 3; k++) {
                            c.drawRect(4 + k * 6, 4 + r * 6, 8 + k * 6, 8 + r * 6, p);
                        }
                    }
                    break;
                case I_NAV:
                    path.moveTo(12, 2);
                    path.lineTo(4.5f, 20.3f);
                    path.lineTo(12, 17f);
                    path.lineTo(19.5f, 20.3f);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case I_MUSIC:
                    c.drawCircle(9, 18, 3.6f, p);
                    c.drawRect(11.6f, 4, 14, 18, p);
                    path.moveTo(14, 4);
                    path.lineTo(20, 6.5f);
                    path.lineTo(20, 10);
                    path.lineTo(14, 7.5f);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case I_PHONE:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.6f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    path.moveTo(6, 6);
                    path.quadTo(6, 18, 18, 18);
                    c.drawPath(path, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(6, 6, 3.2f, p);
                    c.drawCircle(18, 18, 3.2f, p);
                    break;
                case I_TUNE: {
                    float[] ys = {6, 12, 18};
                    float[] ks = {15, 8, 16};
                    for (int i = 0; i < 3; i++) {
                        c.drawRect(3, ys[i] - 1, 21, ys[i] + 1, p);
                        c.drawCircle(ks[i], ys[i], 3, p);
                    }
                    break;
                }
                case I_PLAY:
                    path.moveTo(8, 5);
                    path.lineTo(8, 19);
                    path.lineTo(19, 12);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case I_PAUSE:
                    c.drawRect(6, 5, 10, 19, p);
                    c.drawRect(14, 5, 18, 19, p);
                    break;
                case I_PREV:
                    c.drawRect(6, 6, 8, 18, p);
                    path.moveTo(18, 6);
                    path.lineTo(18, 18);
                    path.lineTo(9.5f, 12);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case I_NEXT:
                    c.drawRect(16, 6, 18, 18, p);
                    path.moveTo(6, 6);
                    path.lineTo(6, 18);
                    path.lineTo(14.5f, 12);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case I_CLOSE:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.4f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    c.drawLine(6, 6, 18, 18, p);
                    c.drawLine(18, 6, 6, 18, p);
                    break;
                case I_GEAR:
                    for (int k = 0; k < 8; k++) {
                        c.save();
                        c.rotate(k * 45f, 12, 12);
                        c.drawRect(10.6f, 1.6f, 13.4f, 6f, p);
                        c.restore();
                    }
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(3f);
                    c.drawCircle(12, 12, 5.6f, p);
                    break;
                case I_IMAGE:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2f);
                    c.drawRoundRect(new RectF(3.5f, 5, 20.5f, 19), 3, 3, p);
                    p.setStyle(Paint.Style.FILL);
                    path.moveTo(5.5f, 17f);
                    path.lineTo(10f, 11.5f);
                    path.lineTo(13f, 15f);
                    path.lineTo(15f, 12.8f);
                    path.lineTo(18.5f, 17f);
                    path.close();
                    c.drawPath(path, p);
                    c.drawCircle(16.2f, 9f, 1.6f, p);
                    break;
                case I_SUN:
                    sun(c, 12, 12, 4.6f, true);
                    break;
                case I_PARTLY:
                    sun(c, 8f, 8f, 3.2f, false);
                    cloud(c, 1.5f, 1.5f);
                    break;
                case I_CLOUD:
                    cloud(c, 0, 0);
                    break;
                case I_RAIN:
                    cloud(c, 0, -3f);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(1.8f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    c.drawLine(9, 18, 8, 21.5f, p);
                    c.drawLine(13.5f, 18, 12.5f, 21.5f, p);
                    c.drawLine(18, 18, 17, 21.5f, p);
                    break;
                case I_STORM:
                    cloud(c, 0, -3f);
                    path.moveTo(13.6f, 15.6f);
                    path.lineTo(10f, 20.8f);
                    path.lineTo(12.6f, 20.8f);
                    path.lineTo(11.4f, 24f);
                    path.lineTo(16.2f, 18.6f);
                    path.lineTo(13.4f, 18.6f);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case I_WIFI:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.2f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    c.drawArc(new RectF(12 - 4, 19 - 4, 12 + 4, 19 + 4), 225, 90, false, p);
                    c.drawArc(new RectF(12 - 8, 19 - 8, 12 + 8, 19 + 8), 225, 90, false, p);
                    c.drawArc(new RectF(12 - 12, 19 - 12, 12 + 12, 19 + 12), 225, 90, false, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(12, 19, 1.7f, p);
                    break;
                case I_BT:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.2f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setStrokeJoin(Paint.Join.ROUND);
                    path.moveTo(7, 7.5f);
                    path.lineTo(17, 16.5f);
                    path.lineTo(12, 21.5f);
                    path.lineTo(12, 2.5f);
                    path.lineTo(17, 7.5f);
                    path.lineTo(7, 16.5f);
                    c.drawPath(path, p);
                    break;
                case I_GPS:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.2f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    c.drawCircle(12, 12, 6f, p);
                    c.drawLine(12, 2, 12, 5.5f, p);
                    c.drawLine(12, 18.5f, 12, 22, p);
                    c.drawLine(2, 12, 5.5f, 12, p);
                    c.drawLine(18.5f, 12, 22, 12, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(12, 12, 2.4f, p);
                    break;
                default:
                    break;
            }
            c.restore();
        }

        private void sun(Canvas c, float cx, float cy, float r, boolean rays) {
            c.drawCircle(cx, cy, r, p);
            if (!rays) return;
            Paint.Style old = p.getStyle();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.9f);
            p.setStrokeCap(Paint.Cap.ROUND);
            for (int k = 0; k < 8; k++) {
                c.save();
                c.rotate(k * 45f, cx, cy);
                c.drawLine(cx, cy - r - 2.4f, cx, cy - r - 4.6f, p);
                c.restore();
            }
            p.setStyle(old);
        }

        @Override
        public void setAlpha(int alpha) {
            p.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(ColorFilter colorFilter) {
            p.setColorFilter(colorFilter);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }

    // ------------------------------------------------------------------ apps

    private void loadApps() {
        new Thread(() -> {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
            final List<AppItem> out = new ArrayList<>();
            for (ResolveInfo ri : list) {
                if (ri.activityInfo.packageName.equals(getPackageName())) continue;
                AppItem a = new AppItem();
                a.pkg = ri.activityInfo.packageName;
                a.cn = new ComponentName(a.pkg, ri.activityInfo.name);
                a.label = String.valueOf(ri.loadLabel(pm));
                out.add(a);
            }
            Collections.sort(out, (x, y) -> x.label.compareToIgnoreCase(y.label));
            runOnUiThread(() -> {
                apps.clear();
                apps.addAll(out);
                adapter.notifyDataSetChanged();
                ensureDefaultDock();
                refreshDock();
                refreshSubtitles();
            });
        }).start();
    }

    private AppItem findApp(String pkg) {
        for (AppItem a : apps) {
            if (a.pkg.equals(pkg)) return a;
        }
        return null;
    }

    private Drawable getIcon(AppItem a) {
        String key = a.cn.flattenToString();
        Drawable d = iconCache.get(key);
        if (d == null) {
            try {
                d = pm.getActivityIcon(a.cn);
            } catch (PackageManager.NameNotFoundException e) {
                d = pm.getDefaultActivityIcon();
            }
            iconCache.put(key, d);
        }
        return d;
    }

    private void launch(AppItem a) {
        Intent i = new Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(a.cn)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        startSafe(i);
    }

    private boolean launchPkg(String pkg) {
        Intent i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) return false;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void startSafe(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("Não foi possível abrir");
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ cartões

    private Intent navIntent() {
        return Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MAPS);
    }

    private Intent musicIntent() {
        return Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC);
    }

    private void openPreferred(String key, Intent fallback) {
        String pkg = prefs.getString(key, null);
        if (pkg != null && launchPkg(pkg)) return;
        try {
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(fallback);
        } catch (Exception e) {
            toast("Nenhum app encontrado. Segure o cartão para escolher um.");
        }
    }

    private String subtitle(String key) {
        String pkg = prefs.getString(key, null);
        if (pkg == null) return DEFAULT_LABEL;
        AppItem a = findApp(pkg);
        return a != null ? a.label : DEFAULT_LABEL;
    }

    private void refreshSubtitles() {
        if (navSub != null) navSub.setText(subtitle(KEY_NAV));
        if (phoneSub != null) phoneSub.setText(subtitle(KEY_PHONE));
        if (settingsSub != null) settingsSub.setText(subtitle(KEY_SETTINGS));
    }

    private void showAppPicker(final String key, String title) {
        final List<AppItem> snapshot = new ArrayList<>(apps);
        CharSequence[] names = new CharSequence[snapshot.size() + 1];
        names[0] = DEFAULT_LABEL;
        for (int i = 0; i < snapshot.size(); i++) names[i + 1] = snapshot.get(i).label;
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(names, (d, which) -> {
                    if (which == 0) {
                        prefs.edit().remove(key).apply();
                    } else {
                        prefs.edit().putString(key, snapshot.get(which - 1).pkg).apply();
                    }
                    refreshSubtitles();
                })
                .show();
    }

    private void showAppMenu(final AppItem a) {
        final boolean pinned = getDock().contains(a.pkg);
        final String[] items = {
                pinned ? "Remover do dock" : "Fixar no dock",
                "Usar como Navegação",
                "Usar como Música",
                "Usar como Telefone",
                "Usar como Ajustes",
                "Informações do app",
                "Desinstalar"
        };
        new AlertDialog.Builder(this)
                .setTitle(a.label)
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0:
                            togglePin(a.pkg);
                            break;
                        case 1:
                            setPref(KEY_NAV, a.pkg);
                            break;
                        case 2:
                            setPref(KEY_MUSIC, a.pkg);
                            break;
                        case 3:
                            setPref(KEY_PHONE, a.pkg);
                            break;
                        case 4:
                            setPref(KEY_SETTINGS, a.pkg);
                            break;
                        case 5:
                            startSafe(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:" + a.pkg)));
                            break;
                        case 6:
                            startSafe(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)));
                            break;
                        default:
                            break;
                    }
                })
                .show();
    }

    private void setPref(String key, String pkg) {
        prefs.edit().putString(key, pkg).apply();
        refreshSubtitles();
    }

    // ------------------------------------------------------------------ dock

    private List<String> getDock() {
        String s = prefs.getString(KEY_DOCK, "");
        List<String> out = new ArrayList<>();
        if (s != null && s.length() > 0) {
            for (String p : s.split(",")) {
                if (p.length() > 0) out.add(p);
            }
        }
        return out;
    }

    private void saveDock(List<String> list) {
        prefs.edit().putString(KEY_DOCK, TextUtils.join(",", list)).apply();
        refreshDock();
    }

    private void togglePin(String pkg) {
        List<String> dock = getDock();
        if (dock.contains(pkg)) {
            dock.remove(pkg);
        } else {
            if (dock.size() >= MAX_DOCK) {
                toast("Dock cheia (máximo " + MAX_DOCK + ")");
                return;
            }
            dock.add(pkg);
        }
        saveDock(dock);
    }

    private void ensureDefaultDock() {
        if (prefs.contains(KEY_DOCK)) return;
        String[] candidates = {
                "com.waze",
                "com.google.android.apps.maps",
                "com.spotify.music",
                "com.google.android.apps.youtube.music",
                "com.google.android.youtube",
                "com.android.chrome"
        };
        List<String> d = new ArrayList<>();
        for (String c : candidates) {
            if (d.size() < MAX_DOCK && findApp(c) != null) d.add(c);
        }
        prefs.edit().putString(KEY_DOCK, TextUtils.join(",", d)).apply();
    }

    private void refreshDock() {
        if (dockApps == null) return;
        dockApps.removeAllViews();
        for (String pkg : getDock()) {
            final AppItem a = findApp(pkg);
            if (a == null) continue;
            ImageView iv = new ImageView(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(58), dp(58));
            lp.setMargins(0, dp(4), 0, dp(4));
            iv.setLayoutParams(lp);
            iv.setPadding(dp(7), dp(7), dp(7), dp(7));
            iv.setBackground(bgItem());
            iv.setImageDrawable(getIcon(a));
            iv.setContentDescription(a.label);
            pressable(iv);
            iv.setOnClickListener(v -> launch(a));
            iv.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this)
                        .setTitle(a.label)
                        .setItems(new String[]{"Remover do dock"}, (d, which) -> togglePin(a.pkg))
                        .show();
                return true;
            });
            dockApps.addView(iv);
        }
    }

    // ------------------------------------------------------------------ gaveta de apps

    private void showDrawer() {
        popIn(drawer);
    }

    private void hideDrawer() {
        popOut(drawer);
    }

    private void popIn(View v) {
        v.animate().cancel();
        v.setAlpha(0f);
        v.setScaleX(0.93f);
        v.setScaleY(0.93f);
        v.setTranslationY(dp(32));
        v.setVisibility(View.VISIBLE);
        v.animate().setStartDelay(0).alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(dur(420)).setInterpolator(new DecelerateInterpolator(2.2f)).start();
    }

    private void popOut(final View v) {
        if (v.getVisibility() != View.VISIBLE) return;
        v.animate().cancel();
        v.animate().setStartDelay(0).alpha(0f).scaleX(0.96f).scaleY(0.96f).translationY(dp(18))
                .setDuration(dur(240)).setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> v.setVisibility(View.GONE)).start();
    }

    private class AppAdapter extends BaseAdapter {
        private final int size;

        AppAdapter(int size) {
            this.size = size;
        }

        @Override
        public int getCount() {
            return apps.size();
        }

        @Override
        public Object getItem(int position) {
            return apps.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Holder h;
            if (convertView == null) {
                LinearLayout row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setGravity(Gravity.CENTER_HORIZONTAL);
                row.setPadding(dp(4), dp(10), dp(4), dp(10));
                row.setBackground(bgItem());
                pressable(row);

                ImageView iv = new ImageView(MainActivity.this);
                row.addView(iv, new LinearLayout.LayoutParams(dp(ICON_DP[size]), dp(ICON_DP[size])));

                TextView tv = text("", LABEL_SP[size], 0xFFE6EDF5, false);
                tv.setSingleLine(true);
                tv.setEllipsize(TextUtils.TruncateAt.END);
                tv.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(MATCH, WRAP);
                tlp.topMargin = dp(6);
                row.addView(tv, tlp);

                h = new Holder();
                h.icon = iv;
                h.label = tv;
                row.setTag(h);
                convertView = row;
            } else {
                h = (Holder) convertView.getTag();
            }
            AppItem a = apps.get(position);
            h.icon.setImageDrawable(getIcon(a));
            h.label.setText(a.label);
            return convertView;
        }
    }

    private static class Holder {
        ImageView icon;
        TextView label;
    }

    // ------------------------------------------------------------------ ajustes do launcher

    private interface RowAction {
        void run();
    }

    private void showSettings() {
        fillSettings();
        popIn(settingsPanel);
    }

    private void showSettingsNoAnim() {
        fillSettings();
        settingsPanel.animate().cancel();
        settingsPanel.setAlpha(1f);
        settingsPanel.setScaleX(1f);
        settingsPanel.setScaleY(1f);
        settingsPanel.setTranslationY(0f);
        settingsPanel.setVisibility(View.VISIBLE);
    }

    private void hideSettings() {
        popOut(settingsPanel);
    }

    private void addRow(String title, String value, final RowAction action) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(bgItem());
        row.setClickable(true);
        row.setPadding(dp(18), dp(14), dp(18), dp(14));
        row.addView(text(title, 18, WHITE, false), new LinearLayout.LayoutParams(0, WRAP, 1f));
        TextView v = text(value, 16, accent, true);
        v.setSingleLine(true);
        row.addView(v);
        row.setOnClickListener(x -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.bottomMargin = dp(4);
        settingsRows.addView(row, lp);
    }

    private void choose(String title, String[] opts, int cur, final IntCb cb) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(opts, cur, (d, which) -> {
                    d.dismiss();
                    cb.run(which);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void putInt(String key, int v) {
        prefs.edit().putInt(key, v).apply();
        rebuild(true);
    }

    private void putBool(String key, boolean v) {
        prefs.edit().putBoolean(key, v).apply();
        rebuild(true);
    }

    private void fillSettings() {
        settingsRows.removeAllViews();
        final int ai = Math.max(0, Math.min(ACCENTS.length - 1, prefs.getInt(K_ACCENT, 0)));
        final int mi = prefs.getInt(K_MODE, 0);
        final int si = prefs.getInt(K_STYLE, 0);
        final int bi = Math.max(0, Math.min(BG_NAMES.length - 1, prefs.getInt(K_BG, 2)));
        final boolean c24 = prefs.getBoolean(K_CLOCK24, true);
        final int zi = Math.max(0, Math.min(2, prefs.getInt(K_ICON, 1)));
        final boolean refl = prefs.getBoolean(K_REFLECT, false);
        final String carName = prefs.getString(K_CAR_NAME, "SANDERO RS");

        addRow("Tela inicial", mi == 1 ? "Papel de parede" : "Painel", () ->
                choose("Tela inicial", new String[]{"Painel", "Papel de parede"}, mi, i -> putInt(K_MODE, i)));
        addRow("Cor de destaque", ACCENT_NAMES[ai], () ->
                choose("Cor de destaque", ACCENT_NAMES, ai, i -> putInt(K_ACCENT, i)));
        addRow("Estilo dos cartões", si == 0 ? "Vidro" : "Sólido", () ->
                choose("Estilo dos cartões", new String[]{"Vidro (translúcido)", "Sólido"}, si, i -> putInt(K_STYLE, i)));
        addRow("Fundo do painel", BG_NAMES[bi], () ->
                choose("Fundo do painel", BG_NAMES, bi, i -> putInt(K_BG, i)));
        addRow("Papel de parede", getFileStreamPath(F_WALL).exists() ? "Personalizado" : "Renault Sport", () ->
                imageMenu("Papel de parede", REQ_WALL, F_WALL));
        addRow("Nome do carro", carName, () -> {
            final EditText et = new EditText(this);
            et.setSingleLine(true);
            et.setText(carName);
            et.setSelection(et.getText().length());
            new AlertDialog.Builder(this)
                    .setTitle("Nome do carro")
                    .setView(et)
                    .setPositiveButton("OK", (d, w) -> {
                        prefs.edit().putString(K_CAR_NAME, et.getText().toString().trim()).apply();
                        rebuild(true);
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });
        addRow("Foto do carro", getFileStreamPath(F_CAR).exists() ? "Personalizada" : "Padrão", () ->
                imageMenu("Foto do carro", REQ_CAR, F_CAR));
        addRow("Reflexo sob o carro", refl ? "Ligado" : "Desligado", () ->
                putBool(K_REFLECT, !refl));
        addRow("Formato da hora", c24 ? "24 horas" : "12 horas", () ->
                putBool(K_CLOCK24, !c24));
        addRow("Temperatura", tempF ? "°F" : "°C", () -> putBool(K_TEMP_F, !tempF));
        addRow("Velocidade", mph ? "mph" : "km/h", () -> putBool(K_MPH, !mph));
        addRow("Tamanho dos ícones (apps)", new String[]{"Pequeno", "Médio", "Grande"}[zi], () ->
                choose("Tamanho dos ícones", new String[]{"Pequeno", "Médio", "Grande"}, zi, i -> putInt(K_ICON, i)));
        final String ownerName = prefs.getString(K_OWNER, "Erick Viana");
        final boolean splashOn = prefs.getBoolean(K_SPLASH, true);
        final boolean animOff = prefs.getInt(K_ANIM, 0) == 1;
        final boolean sysHide = prefs.getBoolean(K_SYSBAR, true);
        addRow("Nome do proprietário", ownerName.length() > 0 ? ownerName : "(vazio)", () -> {
            final EditText et2 = new EditText(this);
            et2.setSingleLine(true);
            et2.setText(ownerName);
            et2.setSelection(et2.getText().length());
            new AlertDialog.Builder(this)
                    .setTitle("Nome do proprietário")
                    .setView(et2)
                    .setPositiveButton("OK", (d, w) -> {
                        prefs.edit().putString(K_OWNER, et2.getText().toString().trim()).apply();
                        rebuild(true);
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });
        addRow("Animação de início", splashOn ? "Ligada" : "Desligada", () -> putBool(K_SPLASH, !splashOn));
        addRow("Rever animação de início", "Tocar", () -> {
            settingsPanel.setVisibility(View.GONE);
            playSplash();
        });
        addRow("Animações do sistema", animOff ? "Desligadas" : "Ligadas", () -> putInt(K_ANIM, animOff ? 0 : 1));
        addRow("Barra do sistema", sysHide ? "Escondida" : "Visível", () -> {
            prefs.edit().putBoolean(K_SYSBAR, !sysHide).apply();
            applySystemUi();
            rebuild(true);
        });
        addRow("Launcher padrão do sistema", "Escolher", () ->
                startSafe(new Intent(Settings.ACTION_HOME_SETTINGS)));
        addRow("Restaurar padrões", "", () ->
                new AlertDialog.Builder(this)
                        .setTitle("Restaurar padrões?")
                        .setMessage("Cores, fundo, fotos e opções voltam ao original. Seus apps do dock são mantidos.")
                        .setPositiveButton("Restaurar", (d, w) -> {
                            prefs.edit().remove(K_ACCENT).remove(K_BG).remove(K_STYLE).remove(K_CAR_NAME)
                                    .remove(K_CLOCK24).remove(K_ICON).remove(K_REFLECT).remove(K_MODE)
                                    .remove(K_TEMP_F).remove(K_MPH).apply();
                            deleteFile(F_CAR);
                            deleteFile(F_WALL);
                            wallBmp = null;
                            rebuild(true);
                        })
                        .setNegativeButton("Cancelar", null)
                        .show());
    }

    // ------------------------------------------------------------------ mídia

    private void mediaKey(int code) {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
    }

    private void applyMusic(MusicViews mv) {
        if (!curTitle.contentEquals(mv.title.getText())) mv.title.setText(curTitle);
        if (!curArtist.contentEquals(mv.artist.getText())) mv.artist.setText(curArtist);
        if (curCover != null) {
            mv.cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
            mv.cover.setPadding(0, 0, 0, 0);
            mv.cover.setImageBitmap(curCover);
        } else {
            mv.cover.setScaleType(ImageView.ScaleType.FIT_CENTER);
            int pd = dp(mv.phPad);
            mv.cover.setPadding(pd, pd, pd, pd);
            mv.cover.setImageDrawable(new IconDrawable(I_MUSIC, accent));
        }
        if (mv.play != null) {
            mv.play.setImageDrawable(new IconDrawable(curPlaying ? I_PAUSE : I_PLAY, onAccent()));
        }
    }

    private void refreshMusicViews() {
        for (MusicViews mv : musics) applyMusic(mv);
    }

    private void setMusic(String title, String artist, boolean playing) {
        boolean textChanged = !title.equals(curTitle) || !artist.equals(curArtist);
        boolean playChanged = playing != curPlaying;
        curTitle = title;
        curArtist = artist;
        curPlaying = playing;
        if (textChanged || playChanged) refreshMusicViews();
    }

    private void setCover(Bitmap bmp, String key) {
        if (key.equals(lastCoverKey)) return;
        lastCoverKey = key;
        curCover = bmp;
        refreshMusicViews();
    }

    private void loadCoverAsync(final String uriStr, final String key) {
        new Thread(() -> {
            Bitmap b = null;
            try {
                Uri u = Uri.parse(uriStr);
                String sch = u.getScheme();
                if ("content".equals(sch) || "file".equals(sch) || "android.resource".equals(sch)) {
                    b = decodeUri(u, 600);
                }
            } catch (Exception ignored) {
            }
            final Bitmap res = b;
            runOnUiThread(() -> {
                if (key.equals(lastCoverKey)) {
                    curCover = res;
                    refreshMusicViews();
                }
            });
        }).start();
    }

    private void updateMedia() {
        try {
            MediaSessionManager msm = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
            List<MediaController> list = msm.getActiveSessions(new ComponentName(this, MediaListener.class));
            mediaAccess = true;

            MediaController pick = null;
            for (MediaController c : list) {
                PlaybackState s = c.getPlaybackState();
                if (s != null && s.getState() == PlaybackState.STATE_PLAYING) {
                    pick = c;
                    break;
                }
            }
            if (pick == null && !list.isEmpty()) pick = list.get(0);

            if (pick == null) {
                setMusic("Nenhuma música tocando", "Toque para abrir o player", false);
                setCover(null, "none");
                return;
            }

            MediaMetadata md = pick.getMetadata();
            String title = md != null ? md.getString(MediaMetadata.METADATA_KEY_TITLE) : null;
            String artist = md != null ? md.getString(MediaMetadata.METADATA_KEY_ARTIST) : null;
            if (artist == null && md != null) artist = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
            PlaybackState s = pick.getPlaybackState();
            boolean playing = s != null && s.getState() == PlaybackState.STATE_PLAYING;
            setMusic(title != null ? title : "Música", artist != null ? artist : "", playing);

            // capa do álbum
            Bitmap art = null;
            String artUri = null;
            if (md != null) {
                art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                if (art == null) art = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                if (art == null) art = md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
                if (art == null) {
                    artUri = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI);
                    if (artUri == null) artUri = md.getString(MediaMetadata.METADATA_KEY_ART_URI);
                    if (artUri == null) artUri = md.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI);
                }
            }
            if (art != null) {
                setCover(art, "b|" + title + "|" + art.getWidth() + "x" + art.getHeight());
            } else if (artUri != null) {
                if (!artUri.equals(lastCoverKey)) {
                    lastCoverKey = artUri;
                    loadCoverAsync(artUri, artUri);
                }
            } else {
                setCover(null, "none");
            }
        } catch (SecurityException e) {
            mediaAccess = false;
            setMusic("Música", "Toque aqui para mostrar a faixa atual", false);
            setCover(null, "none");
        } catch (Exception e) {
            // Algumas centrais não implementam MediaSessionManager direito; ignora.
        }
    }

    // ------------------------------------------------------------------ GPS (velocidade) e clima

    private boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < 23) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private final LocationListener locListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location l) {
            if (LocationManager.GPS_PROVIDER.equals(l.getProvider())) {
                hasFix = true;
                lastGpsTime = System.currentTimeMillis();
                speedMs = l.hasSpeed() ? l.getSpeed() : 0f;
                refreshSpeed();
            }
            maybeFetchWeather(l);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }
    };

    private void startLocation() {
        if (locManager == null || !hasLocationPermission()) return;
        try {
            if (locManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, locListener);
            }
            if (locManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 60000, 100, locListener);
            }
            Location last = locManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null) last = locManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (last != null) maybeFetchWeather(last);
        } catch (SecurityException | IllegalArgumentException e) {
            // sem permissão ou sem provedor: segue sem GPS
        }
    }

    private void stopLocation() {
        try {
            if (locManager != null) locManager.removeUpdates(locListener);
        } catch (SecurityException ignored) {
        }
    }

    private void refreshSpeed() {
        String t = "--";
        if (hasFix) {
            double v = speedMs * (mph ? 2.23694 : 3.6);
            t = String.valueOf(Math.round(v < 2 ? 0 : v));
        }
        for (TextView tv : speedNums) {
            if (!t.contentEquals(tv.getText())) tv.setText(t);
        }
    }

    // clima (Open-Meteo, sem chave)
    private boolean wHas = false;
    private float wTemp, wMax, wMin;
    private int wCode;

    private void wFromPrefs() {
        wHas = prefs.getBoolean(K_W_HAS, false);
        wTemp = prefs.getFloat(K_W_TEMP, 0f);
        wMax = prefs.getFloat(K_W_MAX, 0f);
        wMin = prefs.getFloat(K_W_MIN, 0f);
        wCode = prefs.getInt(K_W_CODE, 0);
    }

    private void maybeFetchWeather(Location l) {
        long now = System.currentTimeMillis();
        if (weatherBusy || (wHas && now - lastWeatherFetch < WEATHER_EVERY_MS)
                || (!wHas && now - lastWeatherFetch < 60000)) return;
        weatherBusy = true;
        lastWeatherFetch = now;
        final double lat = l.getLatitude();
        final double lon = l.getLongitude();
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL u = new URL(String.format(Locale.US,
                        "https://api.open-meteo.com/v1/forecast?latitude=%.3f&longitude=%.3f"
                                + "&current=temperature_2m,weather_code"
                                + "&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1",
                        lat, lon));
                conn = (HttpURLConnection) u.openConnection();
                conn.setConnectTimeout(8000);
                conn.setReadTimeout(8000);
                InputStream in = conn.getInputStream();
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[2048];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                in.close();
                JSONObject j = new JSONObject(bos.toString("UTF-8"));
                JSONObject cur = j.getJSONObject("current");
                JSONObject daily = j.getJSONObject("daily");
                final float t = (float) cur.getDouble("temperature_2m");
                final int code = cur.getInt("weather_code");
                final float mx = (float) daily.getJSONArray("temperature_2m_max").getDouble(0);
                final float mn = (float) daily.getJSONArray("temperature_2m_min").getDouble(0);
                prefs.edit().putBoolean(K_W_HAS, true).putFloat(K_W_TEMP, t).putInt(K_W_CODE, code)
                        .putFloat(K_W_MAX, mx).putFloat(K_W_MIN, mn).apply();
                runOnUiThread(() -> {
                    wHas = true;
                    wTemp = t;
                    wCode = code;
                    wMax = mx;
                    wMin = mn;
                    refreshWeather();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    weatherStatus = wHas ? "" : "Sem internet no momento";
                    refreshWeather();
                });
            } finally {
                if (conn != null) conn.disconnect();
                weatherBusy = false;
            }
        }).start();
    }

    private String fmtTemp(float c) {
        float v = tempF ? c * 9f / 5f + 32f : c;
        return Math.round(v) + "°";
    }

    private String weatherDesc(int code) {
        if (code == 0) return "Céu limpo";
        if (code == 1) return "Predomínio de sol";
        if (code == 2) return "Parcialmente nublado";
        if (code == 3) return "Nublado";
        if (code == 45 || code == 48) return "Neblina";
        if (code >= 51 && code <= 57) return "Garoa";
        if (code >= 61 && code <= 65) return "Chuva";
        if (code == 66 || code == 67) return "Chuva gelada";
        if (code >= 71 && code <= 77) return "Neve";
        if (code >= 80 && code <= 82) return "Pancadas de chuva";
        if (code == 85 || code == 86) return "Neve";
        if (code >= 95) return "Tempestade";
        return "Tempo instável";
    }

    private int weatherIcon(int code) {
        if (code <= 1) return I_SUN;
        if (code == 2) return I_PARTLY;
        if (code == 3 || code == 45 || code == 48 || (code >= 71 && code <= 77) || code == 85 || code == 86) {
            return I_CLOUD;
        }
        if (code >= 95) return I_STORM;
        return I_RAIN;
    }

    private void applyWeather(WeatherViews w) {
        if (wHas) {
            w.icon.setImageDrawable(new IconDrawable(weatherIcon(wCode), accent));
            w.temp.setText(fmtTemp(wTemp));
            w.desc.setText(weatherDesc(wCode));
            if (w.range != null) w.range.setText("Máx " + fmtTemp(wMax) + "  Mín " + fmtTemp(wMin));
        } else {
            w.icon.setImageDrawable(new IconDrawable(I_CLOUD, MUTED));
            w.temp.setText("--°");
            w.desc.setText(weatherStatus);
            if (w.range != null) w.range.setText("");
        }
    }

    private void refreshWeather() {
        for (WeatherViews w : weathers) applyWeather(w);
    }

    // ------------------------------------------------------------------ saudação, status e animações

    private String greetingText() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String g = (h >= 5 && h < 12) ? "Bom dia" : (h >= 12 && h < 18) ? "Boa tarde" : "Boa noite";
        String name = prefs.getString(K_OWNER, "Erick Viana");
        return name != null && name.length() > 0 ? g + ", " + name : g;
    }

    private void setStatusIcon(ImageView iv, int type, boolean on) {
        if (iv == null) return;
        Object t = iv.getTag();
        if (t instanceof Boolean && ((Boolean) t) == on) return;
        iv.setTag(on);
        iv.setImageDrawable(new IconDrawable(type, on ? WHITE : 0x55FFFFFF));
    }

    private void updateStatus() {
        if (statusGreeting == null) return;
        String g = greetingText();
        if (!g.contentEquals(statusGreeting.getText())) statusGreeting.setText(g);
        boolean net = false;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getActiveNetworkInfo();
            net = ni != null && ni.isConnected();
        } catch (Exception ignored) {
        }
        boolean bt = false;
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            bt = ad != null && ad.isEnabled();
        } catch (Exception ignored) {
        }
        setStatusIcon(stWifi, I_WIFI, net);
        setStatusIcon(stBt, I_BT, bt);
        setStatusIcon(stGps, I_GPS, hasFix);
    }

    private int dur(int ms) {
        return prefs.getInt(K_ANIM, 0) == 0 ? ms : 0;
    }

    /** Efeito iOS: o item "afunda" ao tocar e volta com um leve ricochete. */
    private void pressable(View v) {
        v.setOnTouchListener((view, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                view.animate().cancel();
                view.animate().setStartDelay(0).scaleX(0.95f).scaleY(0.95f).setDuration(dur(110))
                        .setInterpolator(new DecelerateInterpolator()).start();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                view.animate().cancel();
                view.animate().setStartDelay(0).scaleX(1f).scaleY(1f).setDuration(dur(340))
                        .setInterpolator(new OvershootInterpolator(2.4f)).start();
            }
            return false;
        });
    }

    private Bitmap loadAsset(String name) {
        try {
            InputStream in = getAssets().open(name);
            Bitmap b = BitmapFactory.decodeStream(in);
            in.close();
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    /** Entrada em cascata dos cartões (sobe suavemente, um depois do outro). */
    private void playEnter() {
        if (splashRunning) return;
        int i = 0;
        for (View v : enterViews) {
            v.animate().cancel();
            v.setAlpha(0f);
            v.setTranslationY(dp(26));
            v.setScaleX(0.96f);
            v.setScaleY(0.96f);
            v.animate().setStartDelay(dur(i * 70)).alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                    .setDuration(dur(560)).setInterpolator(new DecelerateInterpolator(2.2f)).start();
            i++;
        }
    }

    /** Abertura: logo Renault Sport, depois "Bom dia / Boa tarde / Boa noite" com o nome. */
    private void playSplash() {
        if (splash == null) return;
        splashShown = true;
        splashRunning = true;
        final int tok = ++splashToken;
        String full = greetingText();
        int comma = full.indexOf(',');
        splashHi.setText(comma > 0 ? full.substring(0, comma) : full);
        splashName.setText(comma > 0 ? full.substring(comma + 1).trim().toUpperCase() : "");
        splashName.setVisibility(comma > 0 ? View.VISIBLE : View.GONE);

        splash.animate().cancel();
        splash.setAlpha(1f);
        splash.setScaleX(1f);
        splash.setScaleY(1f);
        splash.setVisibility(View.VISIBLE);
        for (View v : enterViews) {
            v.animate().cancel();
            v.setAlpha(0f);
        }
        splashLogo.animate().cancel();
        splashLogo.setAlpha(0f);
        splashLogo.setScaleX(0.9f);
        splashLogo.setScaleY(0.9f);
        splashGreet.animate().cancel();
        splashGreet.setAlpha(0f);
        splashGreet.setTranslationY(dp(24));
        splash.setOnClickListener(v -> endSplash(tok));

        splashLogo.animate().setStartDelay(0).alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(dur(1000)).setInterpolator(new DecelerateInterpolator(1.8f)).start();
        handler.postDelayed(() -> {
            if (tok != splashToken || !splashRunning) return;
            splashLogo.animate().setStartDelay(0).alpha(0f).scaleX(1.06f).scaleY(1.06f)
                    .setDuration(dur(450)).start();
            splashGreet.animate().setStartDelay(dur(280)).alpha(1f).translationY(0f)
                    .setDuration(dur(750)).setInterpolator(new DecelerateInterpolator(1.8f)).start();
            handler.postDelayed(() -> endSplash(tok), 2500);
        }, 2100);
    }

    private void endSplash(int tok) {
        if (tok != splashToken || !splashRunning) return;
        splashRunning = false;
        splash.animate().cancel();
        splash.animate().setStartDelay(0).alpha(0f).scaleX(1.05f).scaleY(1.05f)
                .setDuration(dur(600)).setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    splash.setVisibility(View.GONE);
                    splash.setScaleX(1f);
                    splash.setScaleY(1f);
                }).start();
        playEnter();
    }

    // ------------------------------------------------------------------ util

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
