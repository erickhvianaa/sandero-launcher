package br.com.sandero.launcher;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.ScaleGestureDetector;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.animation.ValueAnimator;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Process;
import android.provider.ContactsContract;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import java.io.File;
import android.content.ContentUris;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.view.HapticFeedbackConstants;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import java.util.Calendar;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Sandero Launcher: launcher leve para central multimídia (tela deitada).
 * Estilo vidro (liquid glass), tema vermelho, clima, velocidade por GPS e modo papel de parede.
 * Sem bibliotecas externas e sem arquivos de layout: a interface é montada em código.
 */
public class MainActivity extends Activity {

    // ------------------------------------------------------------------ constantes

    private static final String PREFS = "launcher";
    private static final String KEY_DOCK = "dock";
    private static final String KEY_NAV = "nav_pkg";
    private static final String KEY_MUSIC = "music_pkg";
    private static final String KEY_PHONE = "phone_pkg";
    private static final String KEY_SETTINGS = "settings_pkg";

    private static final String K_ACCENT = "accent";
    private static final String K_BG = "bg";
    private static final String K_STYLE = "style";
    private static final String K_CAR_NAME = "car_name";
    private static final String K_CLOCK24 = "clock24";
    private static final String K_ICON = "icon_size";
    private static final String K_REFLECT = "reflect";
    private static final String K_MODE = "mode";
    private static final String K_TEMP_F = "temp_f";
    private static final String K_MPH = "mph";
    private static final String K_OWNER = "owner";
    private static final String K_SPLASH = "splash";
    private static final String K_SYSBAR = "sysbar";
    private static final String K_ANIM = "anim";
    private static final String K_ASKED_LOC = "asked_loc";
    private static final String K_ASKED_STO = "asked_sto";
    private static final String K_SPORT_BTN = "sport_btn";
    private static final String K_STANDBY = "standby_idx";
    private static final String K_WAKE_REASON = "wake_reason";
    private static final String K_W_HAS = "w_has";
    private static final String K_W_TEMP = "w_temp";
    private static final String K_W_CODE = "w_code";
    private static final String K_W_MAX = "w_max";
    private static final String K_W_MIN = "w_min";

    private static final String F_CAR = "car.png";
    private static final String F_WALL = "wall.jpg";
    private static final String F_PANELBG = "panelbg.jpg";
    private static final String K_DEEP = "deep_black";
    private static final String K_DEEP_MODE = "deep_mode";
    private boolean nightAuto = false, builtDeep = false;
    private android.hardware.SensorManager sensorMgr;
    private android.hardware.SensorEventListener lightListener;
    private static final String K_THEME = "theme";
    private static final int REQ_PANELBG = 16;
    private static final String K_MYCAR = "mycar_on";
    private static final String K_OBD = "obd_on";
    private static final String K_OBD_ADDR = "obd_addr";
    private static final String K_OBD_NAME = "obd_name";
    private static final String K_SA_ON = "sa_on";
    private static final String K_SA_LIM = "sa_lim";
    private static final String K_SA_SND = "sa_snd";
    private static final String K_SA_REP = "sa_rep";
    private static final String K_W_CITY = "w_city";
    private static final String K_BEAMS = "beams_on";
    private static final String K_BEAM_COL = "beam_col";
    private static final String K_BEAM_CUSTOM = "beam_custom";
    private static final String K_BEAM_INT = "beam_int";
    private static final String[] BEAM_NAMES = {"Seguir cor de destaque", "Vermelho", "Azul", "Verde", "Laranja", "Roxo", "Branco", "Personalizada..."};
    private static final int[] BEAM_COLS = {0, 0xFFFF2A36, 0xFF2D9CFF, 0xFF2DDC8A, 0xFFFF9A2B, 0xFFA66BFF, 0xFFE8EEF5, 0};
    private static final String[] BEAM_INT_NAMES = {"Suave", "Média", "Forte"};
    private static final String[] SA_NAMES = {"Gongo suave", "Carrilhão duplo", "Cristal", "Harpa ascendente", "Bip clássico", "Alerta forte", "Aviso de cinto (curto)"};
    private static final String[] SA_FILES = {"alert_gongo.wav", "alert_chime.wav", "alert_cristal.wav", "alert_harpa.wav", "alert_bip.wav", "alert_forte.wav", "alert_cinto.mp3"};
    private static final String[] SA_REP_NAMES = {"Só uma vez", "A cada 10 segundos", "A cada 30 segundos"};
    private static final int REQ_CAR = 11;
    private static final int REQ_WALL = 12;
    private static final int REQ_SOUND = 13;
    private static final int REQ_CPICON = 14;
    private static final int REQ_AVATAR = 15;
    private static final String F_AVATAR = "avatar.png";
    private static final String K_CAR_SC = "car_sc";
    private static final String K_CAR_DX = "car_dx";
    private static final String K_CAR_DY = "car_dy";
    private static final String F_CPICON = "cpicon.png";
    private static final String K_CPICON = "cp_icon";
    private static final String K_WALLPRE = "wall_preset";
    private static final String K_BLACK = "black_idx";
    private static final String K_FRONT = "front_on";
    private static final int[] BLACK_MS = {0, 1000, 2000, 3000};
    private static final String[] BLACK_NAMES = {"Nenhuma", "1 segundo", "2 segundos", "3 segundos"};
    private static final String[] WALL_NAMES = {"Renault Sport", "Vermelho", "Azul", "Vermelho e azul",
            "Ondas", "Bokeh", "Faixas de luz"};
    private static final String[] WALL_FILES = {"wallpaper.jpg", "wall_red.jpg", "wall_blue.jpg", "wall_duo.jpg",
            "wall_waves.jpg", "wall_bokeh.jpg", "wall_trails.jpg"};
    private static final String[] CP_ICON_NAMES = {"Ícone do app instalado", "Ícone genérico", "Imagem da galeria"};
    private static final String F_SOUND = "welcome_custom.mp3";
    private static final String K_SOUND = "welcome_sound";
    private static final String K_SKIP_SPLASH = "skip_splash";
    private static final String K_ASKED_PHONE = "asked_phone";
    private static final String KEY_CARPLAY = "carplay_pkg";
    private static final int REQ_LOC = 21;

    private static final int MAX_DOCK = 5;
    private static final long POLL_MS = 2000;
    private static final long WEATHER_EVERY_MS = 30 * 60 * 1000L;
    private static final String DEFAULT_LABEL = "Padrão do sistema";

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final int WHITE = 0xFFFFFFFF;
    private static final int MUTED = 0xFFB4BCC8;
    private static final int DARK = 0xFF0A0C10;

    private static final String[] ACCENT_NAMES = {"Vermelho", "Azul", "Verde", "Laranja", "Roxo", "Prata"};
    private static final int[] ACCENTS = {0xFFFF3B47, 0xFF2DD4FF, 0xFF34D399, 0xFFFFA62B, 0xFFA78BFA, 0xFFE6EDF5};

    private static final String[] BG_NAMES = {"Grafite", "Preto puro", "Vinho escuro", "Azul noite", "Papel de parede", "Imagem da galeria"};
    private static final int[][] BG_DEEP = {
            {0xFF0D0F13, 0xFF060709, 0xFF000000},
            {0xFF000000, 0xFF000000, 0xFF000000},
            {0xFF1C070C, 0xFF0C0305, 0xFF000000},
            {0xFF07101C, 0xFF04090F, 0xFF000000}
    };
    private static final int[][] BG_COLORS = {
            {0xFF1C1F26, 0xFF101217, 0xFF050607},
            {0xFF000000, 0xFF000000, 0xFF000000},
            {0xFF2E0E14, 0xFF170709, 0xFF070304},
            {0xFF0E1A2B, 0xFF09111C, 0xFF04070C}
    };

    private static final int[] ICON_DP = {44, 56, 72};
    private static final int[] COL_DP = {104, 124, 152};
    private static final float[] LABEL_SP = {12, 13, 15};

    // tipos de ícone
    private static final int I_APPS = 0, I_NAV = 1, I_MUSIC = 2, I_PHONE = 3, I_TUNE = 4,
            I_PLAY = 5, I_PAUSE = 6, I_PREV = 7, I_NEXT = 8, I_CLOSE = 9, I_GEAR = 10,
            I_IMAGE = 11, I_SUN = 12, I_PARTLY = 13, I_CLOUD = 14, I_RAIN = 15, I_STORM = 16,
            I_WIFI = 17, I_BT = 18, I_GPS = 19, I_RESTART = 20, I_CARPLAY = 21, I_FUEL = 22, I_TEMP = 23, I_SPEED = 24, I_RPM = 25, I_COIN = 26;

    /** A abertura (logo + saudação) toca só uma vez por inicialização do processo. */
    private static boolean splashShown = false;

    /** Modo esporte (brincadeira): fica ligado até desligar ou reiniciar. */
    private static boolean sportOn = false;
    private static int settingsTab = -1;

    // detecção de "saiu do standby" (ligou o carro)
    private static final long[] STANDBY_MS = {60000L, 180000L, 600000L, 1800000L};
    private static final String[] STANDBY_NAMES = {"1 minuto", "3 minutos", "10 minutos", "30 minutos"};
    private static final String[] ACC_ACTIONS = {
            "android.intent.action.ACC_ON", "autochips.intent.action.ACC_ON",
            "com.android.action.ACC_ON", "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON", "com.microntek.bootcheck",
            "com.syu.acc.on", "action.acc.on", "com.zjinnova.ACC_ON",
            "android.intent.action.ACTION_BOOT_IPO", "android.intent.action.ACTION_POWER_ON"};
    private static long lastSeenReal = 0, lastSleepBase = 0, lastSplashReal = 0, screenOffReal = 0, pendingReal = 0;
    private static boolean pendingSplash = false;

    // transmissões antigas de players de música (funcionam sem permissão de notificação)
    private static final String[] MUSIC_ACTIONS = {
            "com.android.music.metachanged", "com.android.music.playstatechanged",
            "com.android.music.playbackcomplete", "com.android.music.queuechanged",
            "com.android.mediacenter.metachanged", "com.android.mediacenter.playstatechanged",
            "com.miui.player.metachanged", "com.miui.player.playstatechanged",
            "com.htc.music.metachanged", "com.sec.android.app.music.metachanged",
            "com.sec.android.app.music.playstatechanged", "com.sonyericsson.music.metachanged",
            "com.amazon.mp3.metachanged", "com.rdio.android.metachanged", "com.real.IMP.metachanged",
            "fm.last.android.metachanged", "com.spotify.music.metadatachanged",
            "com.spotify.music.playbackstatechanged", "com.maxmpz.audioplayer.TRACK_CHANGED"};

    private static final String[] TAB_NAMES = {"Aparência", "Tela inicial", "Veículo", "Iluminação", "Conexões", "Música e apps", "Abertura", "Sistema"};
    private static final int[] TAB_ICONS = {I_IMAGE, I_APPS, I_FUEL, I_SUN, I_BT, I_MUSIC, I_PLAY, I_GEAR};
    private static final String[] TAB_SUBS = {"Cores, fundo, feixes e tema", "Estilo da tela, carro e unidades", "Meu Carro, alertas e gastos",
            "Fitas de LED do carro", "OBD e Bluetooth", "Player e apps dos cartões", "Boas-vindas e animações", "Sistema e restaurar"};

    private int catOf(String label) {
        switch (label) {
            case "Cores e estilo": case "Fundo": case "Ícones e carro": return 0;
            case "Tela inicial": case "Carro": case "Unidades": return 1;
            case "Cartão Meu Carro": case "Alertas do carro": case "Combustível e gastos": case "Alerta de velocidade": return 2;
            case "Luzes do carro (LED)": return 3;
            case "Conexão OBD (ELM327)": return 4;
            case "Música": case "Apps dos cartões": return 5;
            case "Boas-vindas": case "Som de boas-vindas": case "Ao ligar o carro (standby)": case "Animações": return 6;
            default: return 7;
        }
    }

    private interface IntCb {
        void run(int i);
    }

    static class AppItem {
        String label;
        String pkg;
        ComponentName cn;
    }

    private static class MusicViews {
        ImageView cover;
        TextView title, artist;
        ImageButton prev, play, next;
        int phPad = 24; // margem do ícone quando não há capa (dp)
    }

    private static class WeatherViews {
        ImageView icon;
        TextView temp, desc, range;
    }

    // ------------------------------------------------------------------ estado

    private final List<AppItem> apps = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final LruCache<String, Drawable> iconCache = new LruCache<>(80);

    private final List<MusicViews> musics = new ArrayList<>();
    private final List<WeatherViews> weathers = new ArrayList<>();
    private final List<TextView> speedNums = new ArrayList<>();

    private SharedPreferences prefs;
    private PackageManager pm;

    private LinearLayout dockApps;
    private View drawer;
    private LinearLayout settingsPanel;
    private LinearLayout settingsRows;
    private AppAdapter adapter;
    private TextView navSub, phoneSub, settingsSub;

    // barra de status própria, saudação e abertura
    private TextView statusGreeting;
    private ImageView stWifi, stBt, stGps;
    private FrameLayout splash;
    private final List<View> enterViews = new ArrayList<>();
    private boolean splashRunning = false;
    private int splashToken = 0;
    private ImageView splashLogo;
    private LinearLayout splashGreet;
    private TextView splashHi, splashName;

    // tema
    private int accent = ACCENTS[0];
    private boolean glass = true;
    private int mode = 0;
    private boolean deep = true, sportTheme = false;
    private FrameLayout greetToast;
    private FrameLayout toastAvatar;
    private TextView toastName, toastHi;
    private RingView ringRef;
    private String wCity = "";
    private volatile int obdState = 0; // 0 desligado, 1 conectando, 2 conectado, 3 falha
    private volatile int obdTemp = -999, obdFuel = -1;
    private volatile boolean obdRun = false;
    private volatile int obdSpeed = -1, obdRpm = -1;
    private volatile float obdLph = -1f;
    private double tripL = 0, tripKm = 0;
    private TextView[] carDetail;
    private LinearLayout carPanel;
    private TextView carPanelTitle;
    private View panelFuelFill, panelFuelRest;
    private static final String K_TEMP_WARN = "temp_warn";
    private static final String K_FUEL_UNIT = "fuel_unit";
    private static final String K_LOWFUEL_ON = "lowfuel_on";
    private static final String K_LOWFUEL_PCT = "lowfuel_pct";
    private static final String K_COLD_ON = "cold_on";
    private static final String K_COLD_END = "cold_end";
    private static final String K_SPORT_DET = "sport_det";
    private static final String K_SPORT_RPM = "sport_rpm";
    private static final String K_PRICE = "fuel_price";
    private static final String K_TOT_L = "tot_l";
    private static final String K_TOT_KM = "tot_km";
    private boolean lowFuelShown = false, coldActive = false, coldDone = false, sportDet = false;
    private long sportSince = 0, sportOffSince = 0;
    private LinearLayout coldCard;
    private TextView coldTemp, coldSub, topPill;
    private ImageView coldIcon;
    private int pillToken = 0;
    private double totL = 0, totKm = 0;
    private static final String K_HOME_CONS = "home_cons";
    private int carPage = 0;
    private FrameLayout carPagesHost;
    private final List<View> carPageViews = new ArrayList<>();
    private final List<View> carDots = new ArrayList<>();
    private final List<View> page0Cards = new ArrayList<>();
    private CarView panelCar;
    private TextView carConsTv;
    private static final String K_TANK = "tank_l";
    private static final String K_DISP = "disp_dl";
    private static final String K_FUELT = "fuel_type";
    private volatile String obdErr = "";
    private int obdGen = 0;
    private Thread obdThread;
    private android.bluetooth.BluetoothSocket obdSock;
    private TextView carFuelTv, carTempTv, carStatusTv, carCheck;
    private View fuelFill, fuelRest;
    private boolean saOver = false;
    private long saLast = 0;
    private MediaPlayer alertPlayer;
    private boolean tempF = false;
    private boolean mph = false;

    // mídia
    private boolean mediaAccess = false;
    private boolean visible = false;
    private String curTitle = "Nenhuma música tocando";
    private String curArtist = "Toque para abrir o player";
    private Bitmap curCover = null;
    private boolean curPlaying = false;
    private String lastCoverKey = "none";
    private String mediaError = "";
    private String legacyTitle = null, legacyArtist = "", legacyAlbum = null, legacyKey = "";
    private long legacyId = -1, legacyReal = 0;
    private boolean legacyPlaying = false;
    private volatile String lookupKey = "";
    private volatile Bitmap lookupCover = null;
    private volatile boolean lookupDone = false;
    private long lookupAt = 0;
    private int lookupTries = 0;
    private int coverRetries = 0;
    private long coverFailAt = 0;
    private String coverUriKey = "";

    // som de boas-vindas
    private MediaPlayer soundPlayer;
    private ImageView cpIcon;
    private View sportDot;
    private TextView sportTxt;
    private FrameLayout homeAvatar, splashAvatar;
    private SpeedLines splashLines;
    private CarView carViewRef;
    private LinearLayout carEditBar;
    private String lastPhoneSub = null;
    private Bitmap avatarBmp;
    private long avatarStamp = -1;

    // chamada
    private LinearLayout callBanner;
    private TextView callText;
    private ValueAnimator callBlink;
    private int telState = TelephonyManager.CALL_STATE_IDLE;
    private String callNumber = null;
    private String nameCacheNum = null, nameCacheVal = null;
    private boolean phoneListening = false;

    // painel de ajustes
    private LinearLayout settingsSide;
    private ScrollView settingsScroll;

    // clima / GPS
    private LocationManager locManager;
    private boolean hasFix = false;
    private long lastGpsTime = 0;
    private float speedMs = 0f;
    private boolean weatherBusy = false;
    private long lastWeatherFetch = 0;
    private String weatherStatus = "Aguardando GPS e internet";

    // imagens em cache
    private Bitmap wallBmp;
    private String wallKey = "";

    // ------------------------------------------------------------------ ciclo de vida

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.BLACK));
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        pm = getPackageManager();
        locManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        setContentView(buildUi());

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);

        IntentFilter wf = new IntentFilter();
        wf.addAction(Intent.ACTION_SCREEN_ON);
        wf.addAction(Intent.ACTION_SCREEN_OFF);
        wf.addAction(Intent.ACTION_USER_PRESENT);
        for (String a : ACC_ACTIONS) wf.addAction(a);
        registerReceiver(wakeReceiver, wf);
        IntentFilter mf = new IntentFilter();
        for (String a : MUSIC_ACTIONS) mf.addAction(a);
        registerReceiver(musicReceiver, mf);
        IntentFilter bf = new IntentFilter();
        bf.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        bf.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        bf.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(btReceiver, bf);
        markSeen();

        refreshSubtitles();
        refreshWeather();
        refreshSpeed();
        loadApps();
        applySystemUi();
        updateStatus();
        boolean skipSplash = prefs.getBoolean(K_SKIP_SPLASH, false);
        if (skipSplash) prefs.edit().remove(K_SKIP_SPLASH).apply();
        if (!splashShown && prefs.getBoolean(K_SPLASH, true) && savedInstanceState == null && !skipSplash) {
            playSplash();
        } else {
            splashShown = true;
            playEnter();
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applySystemUi();
    }

    /** Esconde a barra de status/navegação do Android (a launcher desenha a própria). */
    private void applySystemUi() {
        try {
            View decor = getWindow().getDecorView();
            if (prefs.getBoolean(K_SYSBAR, true)) {
                getWindow().setStatusBarColor(Color.TRANSPARENT);
                getWindow().setNavigationBarColor(Color.TRANSPARENT);
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            } else {
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        applySystemUi();
        checkStandbyGap(false);
        markSeen();
        if (pendingSplash) {
            pendingSplash = false;
            if (SystemClock.elapsedRealtime() - pendingReal < 600000L && !splashRunning) {
                closeOverlays();
                playSplash();
            }
        }
        handler.removeCallbacks(poll);
        handler.post(poll);
        if (Build.VERSION.SDK_INT >= 23) {
            List<String> need = new ArrayList<>();
            if (!hasLocationPermission() && !prefs.getBoolean(K_ASKED_LOC, false)) {
                prefs.edit().putBoolean(K_ASKED_LOC, true).apply();
                need.add(Manifest.permission.ACCESS_FINE_LOCATION);
            }
            if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_LOC);
        }
        startLocation();
        registerPhone();
        startObd();
        startNightWatch();
    }

    @Override
    protected void onPause() {
        super.onPause();
        visible = false;
        markSeen();
        handler.removeCallbacks(poll);
        stopObd();
        stopNightWatch();
        if (!prefs.getBoolean(K_SA_ON, false)) stopLocation();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(pkgReceiver);
        } catch (Exception ignored) {
        }
        try {
            unregisterReceiver(wakeReceiver);
        } catch (Exception ignored) {
        }
        try {
            unregisterReceiver(musicReceiver);
        } catch (Exception ignored) {
        }
        try {
            unregisterReceiver(btReceiver);
        } catch (Exception ignored) {
        }
        stopWelcomeSound();
        stopObd();
        ledCloseAll();
        if (alertPlayer != null) {
            try {
                alertPlayer.release();
            } catch (Exception ignored) {
            }
            alertPlayer = null;
        }
        if (callBlink != null) callBlink.cancel();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        closeOverlays();
    }

    @Override
    public void onBackPressed() {
        closeOverlays();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOC) {
            startLocation();
            registerPhone();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        if (requestCode == REQ_CAR) {
            saveImage(uri, F_CAR, 1000, true);
        } else if (requestCode == REQ_WALL) {
            saveImage(uri, F_WALL, 1280, false);
        } else if (requestCode == REQ_PANELBG) {
            prefs.edit().putInt(K_BG, 5).apply();
            saveImage(uri, F_PANELBG, 1280, false);
        } else if (requestCode == REQ_SOUND) {
            saveSound(uri);
        } else if (requestCode == REQ_AVATAR) {
            avatarBmp = null;
            saveImage(uri, F_AVATAR, 400, true);
        } else if (requestCode == REQ_CPICON) {
            prefs.edit().putInt(K_CPICON, 2).apply();
            saveImage(uri, F_CPICON, 256, true);
        }
    }

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            loadApps();
        }
    };

    // ------------------------------------------------------------------ standby (ligar o carro)

    private long standbyMin() {
        return STANDBY_MS[Math.max(0, Math.min(STANDBY_MS.length - 1, prefs.getInt(K_STANDBY, 1)))];
    }

    private void markSeen() {
        lastSeenReal = SystemClock.elapsedRealtime();
        lastSleepBase = lastSeenReal - SystemClock.uptimeMillis();
    }

    /**
     * Quando o sistema dorme (standby), o relógio "uptime" para mas o "elapsedRealtime" continua.
     * A diferença entre os dois é o tempo dormindo: se cresceu bastante desde a última vez que
     * o launcher esteve vivo, o carro acabou de ser ligado.
     */
    private void checkStandbyGap(boolean fromPoll) {
        long now = SystemClock.elapsedRealtime();
        if (lastSeenReal == 0) return;
        long sleepNow = now - SystemClock.uptimeMillis();
        long slept = sleepNow - lastSleepBase;
        long min = standbyMin();
        if (slept >= min) {
            triggerWake("Saiu do standby (" + Math.max(1, slept / 60000) + " min dormindo)");
        } else if (fromPoll && now - lastSeenReal >= min) {
            triggerWake("Sistema pausado por " + Math.max(1, (now - lastSeenReal) / 60000) + " min");
        }
    }

    private void triggerWake(String reason) {
        long now = SystemClock.elapsedRealtime();
        markSeen();
        if (lastSplashReal != 0 && now - lastSplashReal < 20000L) return;
        String when = new java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.getDefault())
                .format(new java.util.Date());
        prefs.edit().putString(K_WAKE_REASON, reason + " · " + when).apply();
        if (!prefs.getBoolean(K_SPLASH, true)) return;
        if (visible && !splashRunning) {
            closeOverlays();
            playSplash();
        } else {
            pendingSplash = true;
            pendingReal = now;
            if (prefs.getBoolean(K_FRONT, true)) {
                bringToFront();
                handler.postDelayed(this::bringIfHidden, 1500);
                handler.postDelayed(this::bringIfHidden, 3500);
                handler.postDelayed(this::bringIfHidden, 6000);
            }
        }
    }

    private void bringIfHidden() {
        if (!visible && pendingSplash) bringToFront();
    }

    /** Ao sair do standby, puxa a launcher para a frente (antes/por cima do app que o sistema abrir). */
    private void bringToFront() {
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.setAction(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    private final BroadcastReceiver wakeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String a = intent.getAction();
            if (a == null) return;
            long now = SystemClock.elapsedRealtime();
            if (Intent.ACTION_SCREEN_OFF.equals(a)) {
                screenOffReal = now;
            } else if (Intent.ACTION_SCREEN_ON.equals(a) || Intent.ACTION_USER_PRESENT.equals(a)) {
                if (screenOffReal != 0 && now - screenOffReal >= standbyMin()) {
                    long mins = Math.max(1, (now - screenOffReal) / 60000);
                    screenOffReal = 0;
                    triggerWake("Tela ligou após " + mins + " min");
                }
            } else {
                triggerWake("Sinal do carro (" + a.substring(a.lastIndexOf('.') + 1) + ")");
            }
        }
    };

    // ------------------------------------------------------------------ música (transmissões antigas)

    private final BroadcastReceiver musicReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                String a = intent.getAction();
                Bundle x = intent.getExtras();
                if (a == null || x == null) return;
                String track = extraStr(x, "track", "title", "trackName", "song");
                String artist = extraStr(x, "artist", "artistName");
                String album = extraStr(x, "album", "albumName");
                long id = extraLong(x, "id", "audioId", "songId");
                if (track != null) {
                    legacyTitle = track;
                    legacyArtist = artist != null ? artist : "";
                    legacyAlbum = album;
                    legacyId = id;
                    legacyKey = "L|" + id + "|" + track + "|" + legacyArtist;
                }
                Object pl = x.get("playing");
                if (pl instanceof Boolean) legacyPlaying = (Boolean) pl;
                else if (a.endsWith("metachanged") || a.endsWith("metadatachanged")) legacyPlaying = true;
                legacyReal = SystemClock.elapsedRealtime();
                updateMedia();
            } catch (Exception ignored) {
            }
        }
    };

    private static String extraStr(Bundle x, String... keys) {
        for (String k : keys) {
            Object o = x.get(k);
            if (o instanceof CharSequence && ((CharSequence) o).length() > 0) return o.toString();
        }
        return null;
    }

    private static long extraLong(Bundle x, String... keys) {
        for (String k : keys) {
            Object o = x.get(k);
            if (o instanceof Number) return ((Number) o).longValue();
            if (o instanceof String) {
                try {
                    return Long.parseLong((String) o);
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return -1;
    }

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            checkStandbyGap(true);
            markSeen();
            updateMedia();
            updateCall();
            if (hasFix && System.currentTimeMillis() - lastGpsTime > 6000) {
                hasFix = false;
                refreshSpeed();
            }
            updateStatus();
            if (visible) handler.postDelayed(this, POLL_MS);
        }
    };

    private boolean isOverlayOpen() {
        return drawer.getVisibility() == View.VISIBLE || settingsPanel.getVisibility() == View.VISIBLE;
    }

    private void closeOverlays() {
        if (drawer.getVisibility() == View.VISIBLE) hideDrawer();
        if (settingsPanel.getVisibility() == View.VISIBLE) hideSettings();
        if (carPanel != null && carPanel.getVisibility() == View.VISIBLE) popOut(carPanel);
    }

    // ------------------------------------------------------------------ tema

    private boolean deepNow() {
        int m = prefs.getInt(K_DEEP_MODE, 0);
        return m == 1 || (m == 2 && nightAuto);
    }

    private final Runnable nightRebuild = new Runnable() {
        @Override
        public void run() {
            if (prefs.getInt(K_DEEP_MODE, 0) == 2 && deepNow() != builtDeep && !splashRunning
                    && settingsPanel.getVisibility() != View.VISIBLE) rebuild(false);
        }
    };

    private final Runnable hourCheck = new Runnable() {
        @Override
        public void run() {
            int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            boolean n = h >= 18 || h < 5;
            if (n != nightAuto) {
                nightAuto = n;
                handler.removeCallbacks(nightRebuild);
                handler.postDelayed(nightRebuild, 2000);
            }
            handler.postDelayed(this, 300000);
        }
    };

    /** Preto profundo automático: sensor de luz (se existir) ou horário noturno. */
    private void startNightWatch() {
        stopNightWatch();
        if (prefs.getInt(K_DEEP_MODE, 0) != 2) return;
        try {
            sensorMgr = (android.hardware.SensorManager) getSystemService(Context.SENSOR_SERVICE);
            android.hardware.Sensor ls = sensorMgr == null ? null : sensorMgr.getDefaultSensor(android.hardware.Sensor.TYPE_LIGHT);
            if (ls != null) {
                lightListener = new android.hardware.SensorEventListener() {
                    @Override
                    public void onSensorChanged(android.hardware.SensorEvent ev) {
                        float lux = ev.values[0];
                        boolean n = nightAuto ? lux < 40f : lux < 12f;
                        if (n != nightAuto) {
                            nightAuto = n;
                            handler.removeCallbacks(nightRebuild);
                            handler.postDelayed(nightRebuild, 6000);
                        }
                    }

                    @Override
                    public void onAccuracyChanged(android.hardware.Sensor sensor, int accuracy) {
                    }
                };
                sensorMgr.registerListener(lightListener, ls, android.hardware.SensorManager.SENSOR_DELAY_NORMAL);
                return;
            }
        } catch (Throwable ignored) {
        }
        handler.post(hourCheck);
    }

    private void stopNightWatch() {
        handler.removeCallbacks(hourCheck);
        try {
            if (sensorMgr != null && lightListener != null) sensorMgr.unregisterListener(lightListener);
        } catch (Throwable ignored) {
        }
        lightListener = null;
    }

    private void loadTheme() {
        int ai = prefs.getInt(K_ACCENT, 0);
        if (ai < 0 || ai >= ACCENTS.length) ai = 0;
        accent = ACCENTS[ai];
        glass = prefs.getInt(K_STYLE, 0) == 0;
        deep = deepNow();
        builtDeep = deep;
        sportTheme = prefs.getInt(K_THEME, 0) == 1;
        if (sportTheme) {
            accent = 0xFFE5242B;
            deep = true;
        }
        mode = prefs.getInt(K_MODE, 0);
        tempF = prefs.getBoolean(K_TEMP_F, false);
        mph = prefs.getBoolean(K_MPH, false);
        wFromPrefs();
    }

    private int onAccent() {
        double lum = (0.299 * Color.red(accent) + 0.587 * Color.green(accent) + 0.114 * Color.blue(accent)) / 255.0;
        return lum > 0.62 ? DARK : WHITE;
    }

    private int darker(int c) {
        float[] hsv = new float[3];
        Color.colorToHSV(c, hsv);
        hsv[2] *= 0.78f;
        return Color.HSVToColor(hsv);
    }

    private GradientDrawable shape(int fill, int radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }

    private StateListDrawable states(Drawable pressed, Drawable normal) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, pressed);
        s.addState(new int[]{}, normal);
        return s;
    }

    /** Efeito "vidro": base escura translúcida + brilho claro no topo + borda fina. */
    private Drawable glassLayer(int radiusDp, boolean pressed) {
        GradientDrawable tint = new GradientDrawable();
        tint.setColor(sportTheme ? 0xD9000000 : (deep ? 0x99000000 : 0x59000000));
        tint.setCornerRadius(dp(radiusDp));
        GradientDrawable body = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                pressed ? new int[]{0x66FFFFFF, 0x2EFFFFFF}
                        : (deep ? new int[]{0x26FFFFFF, 0x08FFFFFF} : new int[]{0x3DFFFFFF, 0x0FFFFFFF}));
        body.setCornerRadius(dp(radiusDp));
        body.setStroke(dp(1), pressed ? accent : (sportTheme ? 0x66E5242B : 0x55FFFFFF));
        return new LayerDrawable(new Drawable[]{tint, body});
    }

    private Drawable bgCard(int radiusDp) {
        if (glass) return states(glassLayer(radiusDp, true), glassLayer(radiusDp, false));
        if (deep) return states(shape(0xFF14171C, radiusDp, accent), shape(0xFF07080A, radiusDp, sportTheme ? 0x66E5242B : 0xFF20242B));
        return states(shape(0xFF222831, radiusDp, accent), shape(0xFF14181E, radiusDp, 0xFF272D36));
    }

    private Drawable bgItem() {
        return states(shape(0x33FFFFFF, 18, 0), shape(0x00000000, 18, 0));
    }

    /** Botão play em "vidro líquido": base translúcida na cor de destaque, brilho no topo e borda clara. */
    private Drawable playGlass(boolean pressed) {
        int a = accent & 0x00FFFFFF;
        GradientDrawable body = new GradientDrawable();
        body.setShape(GradientDrawable.OVAL);
        body.setColor(pressed ? ((0xCC << 24) | a) : 0x40000000);
        body.setStroke(Math.max(2, dp(2)), pressed ? 0xFFFFFFFF : ((0xE6 << 24) | a));
        GradientDrawable halo = new GradientDrawable();
        halo.setShape(GradientDrawable.OVAL);
        halo.setColor(0x14FFFFFF);
        LayerDrawable ld = new LayerDrawable(new Drawable[]{halo, body});
        int in = dp(3);
        ld.setLayerInset(1, in, in, in, in);
        return ld;
    }

    private Drawable bgPlay() {
        return states(playGlass(true), playGlass(false));
    }

    // ------------------------------------------------------------------ interface

    private View buildUi() {
        loadTheme();
        musics.clear();
        enterViews.clear();
        weathers.clear();
        speedNums.clear();
        ringRef = null;

        final boolean wallMode = mode == 1;
        FrameLayout root = new FrameLayout(this);

        int bgIndex = prefs.getInt(K_BG, 2);
        if (bgIndex < 0 || bgIndex >= BG_NAMES.length) bgIndex = 2;
        Bitmap wall = null;
        boolean customBg = false;
        if (bgIndex == 5) {
            try {
                java.io.File pf = getFileStreamPath(F_PANELBG);
                if (pf.exists()) wall = BitmapFactory.decodeFile(pf.getPath());
            } catch (Throwable ignored) {
            }
            if (wall != null) customBg = true; else bgIndex = 2;
        }
        if (wall == null && (wallMode || bgIndex == 4)) wall = loadWallpaper();
        if (wall != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(wall);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            root.addView(iv, new FrameLayout.LayoutParams(MATCH, MATCH));
            View shade = new View(this);
            shade.setBackgroundColor(wallMode ? 0x26000000 : (customBg ? (deep ? 0x8C000000 : 0x59000000) : 0xB3000000));
            root.addView(shade, new FrameLayout.LayoutParams(MATCH, MATCH));
        } else {
            int[] cols = (deep ? BG_DEEP : BG_COLORS)[bgIndex < 4 ? bgIndex : 2];
            root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, cols));
        }

        if (prefs.getBoolean(K_BEAMS, true)) {
            int bi0 = prefs.getInt(K_BEAM_COL, 0);
            int bc = bi0 == 0 ? accent : (bi0 == 7 ? prefs.getInt(K_BEAM_CUSTOM, 0xFFFF2A36) : BEAM_COLS[Math.max(1, Math.min(6, bi0))]);
            BeamsView bv = new BeamsView(this, bc, 0.55f + 0.3f * prefs.getInt(K_BEAM_INT, 1), prefs.getInt(K_ANIM, 0) == 0);
            root.addView(bv, new FrameLayout.LayoutParams(MATCH, MATCH));
        }
        if (sportTheme) {
            int red = 0x00E5242B;
            GradientDrawable gl = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0x66E5242B, red});
            GradientDrawable gr = new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, new int[]{0x66E5242B, red});
            GradientDrawable gb = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{0x4DE5242B, red});
            View vl = new View(this); vl.setBackground(gl);
            View vr = new View(this); vr.setBackground(gr);
            View vb = new View(this); vb.setBackground(gb);
            root.addView(vl, new FrameLayout.LayoutParams(dp(110), MATCH, Gravity.LEFT));
            root.addView(vr, new FrameLayout.LayoutParams(dp(110), MATCH, Gravity.RIGHT));
            root.addView(vb, new FrameLayout.LayoutParams(MATCH, dp(90), Gravity.BOTTOM));
        }

        // ---------- HOME ----------
        LinearLayout home = new LinearLayout(this);
        home.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(home, new FrameLayout.LayoutParams(MATCH, MATCH));

        // Dock flutuante de vidro
        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.VERTICAL);
        dock.setGravity(Gravity.CENTER_HORIZONTAL);
        dock.setBackground(glassLayer(32, false));
        dock.setPadding(0, dp(8), 0, dp(8));
        LinearLayout.LayoutParams dockLp = new LinearLayout.LayoutParams(dp(84), MATCH);
        dockLp.setMargins(dp(12), dp(12), 0, dp(12));
        home.addView(dock, dockLp);

        dockApps = new LinearLayout(this);
        dockApps.setOrientation(LinearLayout.VERTICAL);
        dockApps.setGravity(Gravity.CENTER);
        dock.addView(dockApps, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        ImageView btnApps = icon(I_APPS, WHITE, 16);
        btnApps.setBackground(bgItem());
        pressable(btnApps);
        btnApps.setOnClickListener(v -> {
            if (drawer.getVisibility() == View.VISIBLE) hideDrawer(); else showDrawer();
        });
        dock.addView(btnApps, new LinearLayout.LayoutParams(dp(60), dp(60)));

        // Conteúdo
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(10), dp(20), dp(16));
        home.addView(content, new LinearLayout.LayoutParams(0, MATCH, 1f));

        // Barra de status própria (transparente): saudação + Wi-Fi / Bluetooth / GPS
        LinearLayout statusBar = new LinearLayout(this);
        statusBar.setGravity(Gravity.CENTER_VERTICAL);
        statusGreeting = text(greetingText(), 13, 0xE6FFFFFF, false);
        statusGreeting.setSingleLine(true);
        statusGreeting.setEllipsize(TextUtils.TruncateAt.END);
        statusGreeting.setLetterSpacing(0.04f);
        statusGreeting.setShadowLayer(dp(4), 0, dp(1), 0x99000000);
        homeAvatar = makeAvatar(24);
        homeAvatar.setClickable(true);
        homeAvatar.setOnClickListener(v -> avatarMenu());
        LinearLayout.LayoutParams haLp = new LinearLayout.LayoutParams(dp(24), dp(24));
        haLp.rightMargin = dp(9);
        statusBar.addView(homeAvatar, haLp);
        statusBar.addView(statusGreeting, new LinearLayout.LayoutParams(0, WRAP, 1f));
        stGps = icon(I_GPS, 0x55FFFFFF, 0);
        stBt = icon(I_BT, 0x55FFFFFF, 0);
        stWifi = icon(I_WIFI, 0x55FFFFFF, 0);
        ImageView[] sts = {stGps, stBt, stWifi};
        for (ImageView st : sts) {
            LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(dp(18), dp(18));
            stLp.leftMargin = dp(14);
            statusBar.addView(st, stLp);
        }
        content.addView(statusBar, new LinearLayout.LayoutParams(MATCH, dp(32)));

        // Cabeçalho: hora/data | clima | botões
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        content.addView(header, new LinearLayout.LayoutParams(MATCH, WRAP));
        enterViews.add(header);

        LinearLayout times = new LinearLayout(this);
        times.setOrientation(LinearLayout.VERTICAL);
        header.addView(times, new LinearLayout.LayoutParams(0, WRAP, 1f));

        String fmt = prefs.getBoolean(K_CLOCK24, true) ? "HH:mm" : "h:mm a";
        TextClock clock = new TextClock(this);
        clock.setFormat24Hour(fmt);
        clock.setFormat12Hour(fmt);
        clock.setTextSize(52);
        clock.setTextColor(WHITE);
        clock.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        clock.setIncludeFontPadding(false);
        clock.setShadowLayer(dp(6), 0, dp(1), 0x99000000);
        times.addView(clock);

        TextClock date = new TextClock(this);
        date.setFormat24Hour("EEEE, d 'de' MMMM");
        date.setFormat12Hour("EEEE, d 'de' MMMM");
        date.setTextSize(14);
        date.setTextColor(MUTED);
        date.setAllCaps(true);
        date.setLetterSpacing(0.08f);
        date.setShadowLayer(dp(6), 0, dp(1), 0x99000000);
        times.addView(date);
        if (sportTheme) {
            Bitmap wm = loadAsset("logo_rs.png");
            if (wm != null) {
                ImageView wmv = new ImageView(this);
                wmv.setImageBitmap(wm);
                wmv.setAdjustViewBounds(true);
                wmv.setScaleType(ImageView.ScaleType.FIT_START);
                LinearLayout.LayoutParams wmLp = new LinearLayout.LayoutParams(dp(150), WRAP);
                wmLp.topMargin = dp(6);
                times.addView(wmv, wmLp);
            }
        }

        LinearLayout chip = new LinearLayout(this);
        chip.setGravity(Gravity.CENTER_VERTICAL);
        chip.setBackground(glassLayer(100, false));
        chip.setPadding(dp(14), dp(8), dp(18), dp(8));
        if (!wallMode) chip.addView(weatherBlock(30, 20, 11, false));
        LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        chipLp.rightMargin = dp(12);
        if (!wallMode) header.addView(chip, chipLp);

        LinearLayout cpPill = new LinearLayout(this);
        cpPill.setGravity(Gravity.CENTER_VERTICAL);
        cpPill.setBackground(states(glassLayer(100, true), glassLayer(100, false)));
        cpPill.setPadding(dp(14), dp(8), dp(18), dp(8));
        cpPill.setClickable(true);
        pressable(cpPill);
        cpIcon = new ImageView(this);
        cpIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        final int cpRad = dp(7);
        cpIcon.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), cpRad);
            }
        });
        cpIcon.setClipToOutline(true);
        cpPill.addView(cpIcon, new LinearLayout.LayoutParams(dp(28), dp(28)));
        refreshCarplayIcon();
        TextView cpTxt = text("CarPlay", 15, WHITE, true);
        cpTxt.setShadowLayer(dp(4), 0, dp(1), 0x66000000);
        LinearLayout.LayoutParams cpTl = new LinearLayout.LayoutParams(WRAP, WRAP);
        cpTl.leftMargin = dp(8);
        cpPill.addView(cpTxt, cpTl);
        cpPill.setOnClickListener(v -> openCarplay());
        cpPill.setOnLongClickListener(v -> {
            showAppPicker(KEY_CARPLAY, "App do CarPlay");
            return true;
        });
        LinearLayout.LayoutParams cpLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        cpLp.rightMargin = dp(12);
        header.addView(cpPill, cpLp);

        ImageView btnMode = icon(I_IMAGE, WHITE, 12);
        btnMode.setBackground(states(glassLayer(100, true), glassLayer(100, false)));
        btnMode.setContentDescription("Alternar painel / papel de parede");
        pressable(btnMode);
        btnMode.setOnClickListener(v -> {
            prefs.edit().putInt(K_MODE, mode == 1 ? 0 : 1).apply();
            rebuild(false);
        });
        LinearLayout.LayoutParams bmLp = new LinearLayout.LayoutParams(dp(48), dp(48));
        bmLp.rightMargin = dp(8);
        header.addView(btnMode, bmLp);

        ImageView btnGear = icon(I_GEAR, WHITE, 12);
        btnGear.setBackground(states(glassLayer(100, true), glassLayer(100, false)));
        btnGear.setContentDescription("Ajustes do launcher");
        pressable(btnGear);
        btnGear.setOnClickListener(v -> {
            settingsTab = -1;
            showSettings();
        });
        header.addView(btnGear, new LinearLayout.LayoutParams(dp(48), dp(48)));

        if (wallMode) {
            content.addView(new View(this), new LinearLayout.LayoutParams(MATCH, 0, 1f));
            content.addView(buildWallpaperBar(), new LinearLayout.LayoutParams(MATCH, WRAP));
        } else {
            LinearLayout.LayoutParams cardsLp = new LinearLayout.LayoutParams(MATCH, 0, 1f);
            cardsLp.topMargin = dp(12);
            content.addView(buildCards(), cardsLp);
            if (sportTheme) {
                LinearLayout.LayoutParams nbLp = new LinearLayout.LayoutParams(MATCH, dp(64));
                nbLp.topMargin = dp(12);
                content.addView(buildSportNav(), nbLp);
            }
        }

        // ---------- GAVETA DE APPS ----------
        LinearLayout drawerView = new LinearLayout(this);
        drawerView.setOrientation(LinearLayout.VERTICAL);
        drawerView.setBackgroundColor(0xEB050608);
        drawerView.setClickable(true);
        drawerView.setVisibility(View.GONE);
        drawer = drawerView;
        root.addView(drawerView, new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout dHeader = new LinearLayout(this);
        dHeader.setGravity(Gravity.CENTER_VERTICAL);
        dHeader.setPadding(dp(32), dp(12), dp(16), 0);
        dHeader.addView(text("Aplicativos", 22, WHITE, true), new LinearLayout.LayoutParams(0, WRAP, 1f));
        ImageView btnClose = icon(I_CLOSE, WHITE, 14);
        btnClose.setBackground(bgItem());
        btnClose.setOnClickListener(v -> hideDrawer());
        dHeader.addView(btnClose, new LinearLayout.LayoutParams(dp(56), dp(56)));
        drawerView.addView(dHeader, new LinearLayout.LayoutParams(MATCH, WRAP));

        int sz = prefs.getInt(K_ICON, 1);
        if (sz < 0 || sz > 2) sz = 1;
        GridView grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(dp(COL_DP[sz]));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setHorizontalSpacing(dp(8));
        grid.setVerticalSpacing(dp(8));
        grid.setPadding(dp(24), dp(24), dp(24), dp(24));
        grid.setClipToPadding(false);
        grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        grid.setVerticalScrollBarEnabled(false);
        adapter = new AppAdapter(sz);
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent, view, position, id) -> {
            launch(apps.get(position));
            hideDrawer();
        });
        grid.setOnItemLongClickListener((parent, view, position, id) -> {
            showAppMenu(apps.get(position));
            return true;
        });
        drawerView.addView(grid, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        // ---------- AJUSTES DO LAUNCHER (janela de vidro com categorias) ----------
        settingsPanel = new LinearLayout(this);
        settingsPanel.setOrientation(LinearLayout.VERTICAL);
        settingsPanel.setGravity(Gravity.CENTER);
        settingsPanel.setBackgroundColor(0xFF000000);
        settingsPanel.setClickable(true);
        settingsPanel.setOnClickListener(v -> hideSettings());
        settingsPanel.setVisibility(View.GONE);
        root.addView(settingsPanel, new FrameLayout.LayoutParams(MATCH, MATCH));
        carPanel = buildCarPanel();
        carPanel.setVisibility(View.GONE);
        root.addView(carPanel, new FrameLayout.LayoutParams(MATCH, MATCH));

        coldCard = new LinearLayout(this);
        coldCard.setGravity(Gravity.CENTER_VERTICAL);
        coldCard.setBackground(glassLayer(22, false));
        coldCard.setPadding(dp(16), dp(8), dp(22), dp(8));
        coldIcon = icon(I_TEMP, 0xFF4DA3FF, 0);
        coldCard.addView(coldIcon, new LinearLayout.LayoutParams(dp(30), dp(30)));
        LinearLayout ccol = new LinearLayout(this);
        ccol.setOrientation(LinearLayout.VERTICAL);
        TextView cl = text("AVISO · COLD START", 12, 0xFF4DA3FF, true);
        cl.setLetterSpacing(0.14f);
        ccol.addView(cl);
        coldSub = text("Aquecendo o motor...", 13, MUTED, false);
        coldSub.setSingleLine(true);
        ccol.addView(coldSub);
        LinearLayout.LayoutParams ccl = new LinearLayout.LayoutParams(0, WRAP, 1f);
        ccl.leftMargin = dp(14);
        coldCard.addView(ccol, ccl);
        coldTemp = text("--", 30, 0xFF4DA3FF, false);
        coldTemp.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        coldTemp.setIncludeFontPadding(false);
        coldCard.addView(coldTemp);
        coldCard.setVisibility(View.GONE);
        coldCard.setClickable(true);
        coldCard.setOnClickListener(v -> {
            popOut(coldCard);
            coldActive = false;
            coldDone = true;
        });
        LinearLayout.LayoutParams cclp = new LinearLayout.LayoutParams(MATCH, WRAP);
        cclp.topMargin = dp(10);
        content.addView(coldCard, Math.min(2, content.getChildCount()), cclp);
        topPill = text("", 16, WHITE, true);
        topPill.setLetterSpacing(0.12f);
        topPill.setPadding(dp(24), dp(10), dp(24), dp(10));
        topPill.setVisibility(View.GONE);
        FrameLayout.LayoutParams tplp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        tplp.topMargin = dp(8);
        root.addView(topPill, tplp);

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable sbg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF14181F, 0xFF07090C});
        sbg.setCornerRadius(0f);
        sbg.setStroke(dp(1), 0x33FFFFFF);
        sheet.setBackground(sbg);
        sheet.setClickable(true);
        LinearLayout.LayoutParams sheetLp = new LinearLayout.LayoutParams(
                MATCH, MATCH);
        sheetLp.setMargins(0, 0, 0, 0);
        settingsPanel.addView(sheet, sheetLp);

        LinearLayout sHeader = new LinearLayout(this);
        sHeader.setGravity(Gravity.CENTER_VERTICAL);
        sHeader.setPadding(dp(26), dp(18), dp(16), dp(8));
        LinearLayout hTxt = new LinearLayout(this);
        hTxt.setOrientation(LinearLayout.VERTICAL);
        hTxt.addView(text("Ajustes", 24, WHITE, true));
        hTxt.addView(text("Sandero Launcher", 12, MUTED, false));
        sHeader.addView(hTxt, new LinearLayout.LayoutParams(0, WRAP, 1f));
        ImageView sRestart = icon(I_RESTART, WHITE, 13);
        sRestart.setBackground(shape(0x26FFFFFF, 100, 0));
        sRestart.setContentDescription("Reiniciar launcher");
        pressable(sRestart);
        sRestart.setOnClickListener(v -> confirmRestart());
        LinearLayout.LayoutParams srLp = new LinearLayout.LayoutParams(dp(48), dp(48));
        srLp.rightMargin = dp(10);
        sHeader.addView(sRestart, srLp);
        ImageView sClose = icon(I_CLOSE, WHITE, 13);
        sClose.setBackground(shape(0x26FFFFFF, 100, 0));
        pressable(sClose);
        sClose.setOnClickListener(v -> hideSettings());
        sHeader.addView(sClose, new LinearLayout.LayoutParams(dp(48), dp(48)));
        sheet.addView(sHeader, new LinearLayout.LayoutParams(MATCH, WRAP));

        LinearLayout sBody = new LinearLayout(this);
        settingsSide = new LinearLayout(this);
        settingsSide.setOrientation(LinearLayout.VERTICAL);
        settingsSide.setPadding(dp(16), dp(8), dp(8), dp(16));
        sBody.addView(settingsSide, new LinearLayout.LayoutParams(dp(214), MATCH));
        settingsScroll = new ScrollView(this);
        settingsScroll.setVerticalScrollBarEnabled(false);
        settingsRows = new LinearLayout(this);
        settingsRows.setOrientation(LinearLayout.VERTICAL);
        settingsRows.setPadding(dp(8), dp(2), dp(22), dp(24));
        settingsScroll.addView(settingsRows, new ScrollView.LayoutParams(MATCH, WRAP));
        sBody.addView(settingsScroll, new LinearLayout.LayoutParams(0, MATCH, 1f));
        sheet.addView(sBody, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        // ---------- ABERTURA: logo Renault Sport + saudação ----------
        splash = new FrameLayout(this);
        splash.setBackgroundColor(0xFF000000);
        splash.setClickable(true);
        splash.setVisibility(View.GONE);
        splashLines = new SpeedLines(this);
        splash.addView(splashLines, new FrameLayout.LayoutParams(MATCH, MATCH));
        splashLogo = new ImageView(this);
        splashLogo.setAdjustViewBounds(true);
        splashLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        Bitmap logo = loadAsset("logo_rs.png");
        if (logo != null) splashLogo.setImageBitmap(logo);
        splash.addView(splashLogo, new FrameLayout.LayoutParams(dp(560), WRAP, Gravity.CENTER));
        splashGreet = new LinearLayout(this);
        splashGreet.setOrientation(LinearLayout.VERTICAL);
        splashGreet.setGravity(Gravity.CENTER_HORIZONTAL);
        splashAvatar = makeAvatar(112);
        LinearLayout.LayoutParams saLp = new LinearLayout.LayoutParams(dp(112), dp(112));
        saLp.bottomMargin = dp(18);
        splashGreet.addView(splashAvatar, saLp);
        splashHi = text("", 46, WHITE, false);
        splashHi.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        splashHi.setGravity(Gravity.CENTER);
        splashHi.setSingleLine(false);
        splashHi.setMaxLines(2);
        splashHi.setIncludeFontPadding(false);
        splashName = text("", 26, accent, true);
        splashName.setLetterSpacing(0.12f);
        splashName.setGravity(Gravity.CENTER);
        splashName.setSingleLine(false);
        splashName.setMaxLines(2);
        splashGreet.addView(splashHi, new LinearLayout.LayoutParams(MATCH, WRAP));
        LinearLayout.LayoutParams snLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        snLp.topMargin = dp(10);
        splashGreet.addView(splashName, snLp);
        splashAvatar.setAlpha(0f);
        splashHi.setAlpha(0f);
        splashName.setAlpha(0f);
        splash.addView(splashGreet, new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER));
        callBanner = new LinearLayout(this);
        callBanner.setGravity(Gravity.CENTER_VERTICAL);
        callBanner.setBackground(shape(0xFF1DB954, 100, 0x66FFFFFF));
        callBanner.setPadding(dp(14), dp(6), dp(18), dp(6));
        callBanner.addView(icon(I_PHONE, WHITE, 0), new LinearLayout.LayoutParams(dp(20), dp(20)));
        callText = text("Em chamada", 15, WHITE, true);
        callText.setSingleLine(true);
        callText.setEllipsize(TextUtils.TruncateAt.END);
        callText.setMaxWidth(dp(420));
        LinearLayout.LayoutParams ctLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        ctLp.leftMargin = dp(8);
        callBanner.addView(callText, ctLp);
        callBanner.setVisibility(View.GONE);
        callBanner.setClickable(true);
        callBanner.setOnClickListener(v -> openPreferred(KEY_PHONE, new Intent(Intent.ACTION_DIAL)));
        FrameLayout.LayoutParams cbLp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        cbLp.topMargin = dp(8);
        root.addView(callBanner, cbLp);

        root.addView(splash, new FrameLayout.LayoutParams(MATCH, MATCH));

        greetToast = new FrameLayout(this);
        LinearLayout gtRow = new LinearLayout(this);
        gtRow.setGravity(Gravity.CENTER_VERTICAL);
        gtRow.setPadding(dp(10), dp(10), dp(22), dp(10));
        GradientDrawable gtBg = new GradientDrawable();
        gtBg.setColor(0xF2101216);
        gtBg.setCornerRadius(dp(30));
        gtBg.setStroke(dp(1), (accent & 0x00FFFFFF) | 0x99000000);
        gtRow.setBackground(gtBg);
        toastAvatar = makeAvatar(44);
        gtRow.addView(toastAvatar, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout gtTxt = new LinearLayout(this);
        gtTxt.setOrientation(LinearLayout.VERTICAL);
        toastHi = text("Olá,", 13, MUTED, false);
        toastName = text("", 18, WHITE, true);
        gtTxt.addView(toastHi);
        gtTxt.addView(toastName);
        LinearLayout.LayoutParams gtLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        gtLp.leftMargin = dp(12);
        gtRow.addView(gtTxt, gtLp);
        greetToast.addView(gtRow, new FrameLayout.LayoutParams(WRAP, WRAP));
        greetToast.setVisibility(View.INVISIBLE);
        greetToast.setAlpha(0f);
        FrameLayout.LayoutParams gtFl = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.LEFT);
        gtFl.setMargins(dp(108), dp(12), 0, 0);
        root.addView(greetToast, gtFl);

        return root;
    }

    /** Painel completo: carro | música | navegação + telefone + ajustes. */
    private View buildCards() {
        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.HORIZONTAL);

        // --- Carro (foto com brilho/reflexo) + velocidade + nome
        FrameLayout carFrame = new FrameLayout(this);
        CarView carView = new CarView(this);
        if (!getFileStreamPath(F_CAR).exists()) {
            Bitmap sc = loadAsset("car_scene.jpg");
            if (sc != null) carView.setScene(sc, accent);
            else carView.set(loadCar(), accent, prefs.getBoolean(K_REFLECT, false));
        } else {
            carView.set(loadCar(), accent, prefs.getBoolean(K_REFLECT, false));
        }
        final boolean myCarOn = prefs.getBoolean(K_MYCAR, true);
        carView.setSportNow(sportOn ? 1f : 0f);
        carFrame.addView(carView, new FrameLayout.LayoutParams(MATCH, MATCH));
        final View sportFlash = new View(this);
        GradientDrawable fg = new GradientDrawable();
        fg.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        fg.setGradientRadius(dp(300));
        fg.setColors(new int[]{(accent & 0x00FFFFFF) | 0xAA000000, accent & 0x00FFFFFF});
        sportFlash.setBackground(fg);
        sportFlash.setAlpha(0f);
        carFrame.addView(sportFlash, new FrameLayout.LayoutParams(MATCH, MATCH));
        carView.setTransform(prefs.getFloat(K_CAR_SC, 1f), prefs.getFloat(K_CAR_DX, 0f), prefs.getFloat(K_CAR_DY, 0f));
        carViewRef = carView;
        final LinearLayout editBar = new LinearLayout(this);
        editBar.setGravity(Gravity.CENTER_VERTICAL);
        editBar.setBackground(glassLayer(100, false));
        editBar.setPadding(dp(16), dp(8), dp(8), dp(8));
        editBar.addView(text("Arraste para mover · Pinça para ampliar", 12, WHITE, false));
        TextView edReset = text("Redefinir", 12, MUTED, true);
        edReset.setPadding(dp(14), dp(8), dp(14), dp(8));
        edReset.setOnClickListener(v -> {
            carView.setTransform(1f, 0f, 0f);
            prefs.edit().remove(K_CAR_SC).remove(K_CAR_DX).remove(K_CAR_DY).apply();
        });
        editBar.addView(edReset);
        TextView edDone = text("Concluído", 12, onAccent(), true);
        edDone.setPadding(dp(16), dp(8), dp(16), dp(8));
        edDone.setBackground(shape(accent, 100, 0));
        edDone.setOnClickListener(v -> stopCarEdit());
        editBar.addView(edDone);
        editBar.setVisibility(View.GONE);
        carEditBar = editBar;
        FrameLayout.LayoutParams ebLp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        ebLp.topMargin = dp(8);
        carFrame.addView(editBar, ebLp);
        carView.setLongClickable(true);
        carView.setOnLongClickListener(v -> {
            choose("Carro", new String[]{"Mover e redimensionar", "Trocar a foto", "Usar a foto padrão",
                    "Redefinir posição e tamanho"}, -1, i -> {
                if (i == 0) startCarEdit();
                else if (i == 1) pickImage(REQ_CAR);
                else if (i == 2) {
                    deleteFile(F_CAR);
                    rebuild(false);
                } else {
                    prefs.edit().remove(K_CAR_SC).remove(K_CAR_DX).remove(K_CAR_DY).apply();
                    carView.setTransform(1f, 0f, 0f);
                }
            });
            return true;
        });

        LinearLayout speedBox = new LinearLayout(this);
        speedBox.setOrientation(LinearLayout.HORIZONTAL);
        speedBox.setGravity(Gravity.BOTTOM);
        speedBox.setBackground(glassLayer(26, false));
        speedBox.setPadding(dp(16), dp(6), dp(16), dp(8));
        TextView num = text("--", 40, WHITE, false);
        num.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        num.setIncludeFontPadding(false);
        speedNums.add(num);
        speedBox.addView(num);
        TextView unit = text(mph ? "mph" : "km/h", 13, MUTED, false);
        LinearLayout.LayoutParams unitLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        unitLp.leftMargin = dp(6);
        unitLp.bottomMargin = dp(5);
        speedBox.addView(unit, unitLp);
        if (myCarOn) {
            speedNums.remove(num);
        } else if (sportTheme) {
            speedNums.remove(num);
            FrameLayout ringBox = new FrameLayout(this);
            ringRef = new RingView(this, accent);
            ringBox.addView(ringRef, new FrameLayout.LayoutParams(MATCH, MATCH));
            LinearLayout rc = new LinearLayout(this);
            rc.setOrientation(LinearLayout.VERTICAL);
            rc.setGravity(Gravity.CENTER);
            TextView rn = text("--", 30, WHITE, true);
            rn.setIncludeFontPadding(false);
            speedNums.add(rn);
            rc.addView(rn);
            rc.addView(text(mph ? "mph" : "km/h", 11, MUTED, false));
            ringBox.addView(rc, new FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER));
            FrameLayout.LayoutParams rbLp = new FrameLayout.LayoutParams(dp(118), dp(118), Gravity.BOTTOM | Gravity.LEFT);
            rbLp.setMargins(dp(4), 0, 0, dp(4));
            carFrame.addView(ringBox, rbLp);
        } else {
            FrameLayout.LayoutParams sbLp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM | Gravity.LEFT);
            sbLp.setMargins(dp(4), 0, 0, dp(4));
            carFrame.addView(speedBox, sbLp);
        }

        final String carNameStr = prefs.getString(K_CAR_NAME, "SANDERO RS");
        final TextView car = text(carNameStr + (sportOn ? "  •  SPORT" : ""), 15, accent, true);
        car.setLetterSpacing(0.3f);
        car.setShadowLayer(dp(6), 0, dp(1), 0xCC000000);
        FrameLayout.LayoutParams cnLp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM | Gravity.RIGHT);
        cnLp.setMargins(0, 0, dp(8), dp(10));
        carFrame.addView(car, cnLp);

        // Botão "Modo esporte" (efeito visual, só para curtir)
        if (prefs.getBoolean(K_SPORT_BTN, true)) {
            final LinearLayout sportBtn = new LinearLayout(this);
            sportBtn.setGravity(Gravity.CENTER_VERTICAL);
            sportBtn.setClickable(true);
            sportBtn.setPadding(dp(14), dp(9), dp(16), dp(9));
            sportDot = new View(this);
            LinearLayout.LayoutParams sdLp = new LinearLayout.LayoutParams(dp(10), dp(10));
            sdLp.rightMargin = dp(9);
            sportBtn.addView(sportDot, sdLp);
            sportTxt = text("MODO SPORT", 12, WHITE, true);
            sportTxt.setLetterSpacing(0.14f);
            sportBtn.addView(sportTxt);
            styleSportBtn(sportBtn);
            pressable(sportBtn);
            sportBtn.setOnClickListener(v -> {
                sportOn = !sportOn;
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                styleSportBtn(sportBtn);
                car.setText(carNameStr + (sportOn ? "  •  SPORT" : ""));
                carView.animateSport(sportOn ? 1f : 0f, dur(700));
                sportFlash.animate().cancel();
                sportFlash.setAlpha(0f);
                sportFlash.animate().setStartDelay(0).alpha(sportOn ? 0.95f : 0.5f).setDuration(dur(240))
                        .withEndAction(() -> sportFlash.animate().alpha(0f).setDuration(dur(1000)).start())
                        .start();
            });
            FrameLayout.LayoutParams spLp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.LEFT);
            spLp.setMargins(dp(6), dp(6), 0, 0);
            carFrame.addView(sportBtn, spLp);
        }
        cards.addView(carFrame, new LinearLayout.LayoutParams(0, MATCH, 1.35f));

        // --- Música (a capa preenche o cartão inteiro)
        FrameLayout cardMusic = new FrameLayout(this);
        cardMusic.setBackground(bgCard(28));
        cardMusic.setClickable(true);
        cardMusic.setFocusable(true);
        swipeable(cardMusic);

        MusicViews mv = newMusic(0, 22, 15);
        mv.phPad = 90;
        final int cardRad = dp(28);
        mv.cover.setBackground(null);
        mv.cover.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), cardRad);
            }
        });
        applyMusic(mv);
        cardMusic.addView(mv.cover, new FrameLayout.LayoutParams(MATCH, MATCH));

        View shade = new View(this);
        GradientDrawable sg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x66000000, 0x00000000, 0x99000000, 0xEB000000});
        sg.setCornerRadius(cardRad);
        shade.setBackground(sg);
        cardMusic.addView(shade, new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout mCol = new LinearLayout(this);
        mCol.setOrientation(LinearLayout.VERTICAL);
        mCol.setPadding(dp(20), dp(18), dp(20), dp(16));

        LinearLayout mHeader = new LinearLayout(this);
        mHeader.setGravity(Gravity.CENTER_VERTICAL);
        mHeader.addView(icon(I_MUSIC, accent, 0), new LinearLayout.LayoutParams(dp(22), dp(22)));
        TextView mLabel = text("MÚSICA", 12, accent, true);
        mLabel.setLetterSpacing(0.2f);
        mLabel.setShadowLayer(dp(4), 0, dp(1), 0x99000000);
        LinearLayout.LayoutParams mlLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        mlLp.leftMargin = dp(8);
        mHeader.addView(mLabel, mlLp);
        mCol.addView(mHeader, new LinearLayout.LayoutParams(MATCH, WRAP));
        mCol.addView(new View(this), new LinearLayout.LayoutParams(MATCH, 0, 1f));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setClickable(true);
        info.addView(mv.title, new LinearLayout.LayoutParams(MATCH, WRAP));
        LinearLayout.LayoutParams artLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        artLp.topMargin = dp(3);
        info.addView(mv.artist, artLp);
        info.setOnClickListener(v -> onMusicInfoClick());
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        infoLp.bottomMargin = dp(10);
        mCol.addView(info, infoLp);
        mCol.addView(controls(mv, 56, 68), new LinearLayout.LayoutParams(MATCH, WRAP));
        cardMusic.addView(mCol, new FrameLayout.LayoutParams(MATCH, MATCH));

        cardMusic.setOnClickListener(v -> openPreferred(KEY_MUSIC, musicIntent()));
        cardMusic.setOnLongClickListener(v -> {
            showAppPicker(KEY_MUSIC, "App de música");
            return true;
        });
        LinearLayout.LayoutParams cmLp = new LinearLayout.LayoutParams(0, MATCH, 1.2f);
        cmLp.leftMargin = dp(14);
        cards.addView(cardMusic, cmLp);

        // --- Coluna: Navegação, Telefone, Ajustes
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(0, MATCH, 1f);
        colLp.leftMargin = dp(14);
        cards.addView(column, colLp);

        final float navW = myCarOn ? 0.55f : 1.3f;
        LinearLayout cardNav = card(20);
        navSub = text("", 13, MUTED, false);
        navSub.setSingleLine(true);
        if (myCarOn) {
            cardNav.setOrientation(LinearLayout.HORIZONTAL);
            cardNav.setGravity(Gravity.CENTER_VERTICAL);
            cardNav.setPadding(dp(18), dp(6), dp(14), dp(6));
            cardNav.addView(icon(I_NAV, accent, 0), new LinearLayout.LayoutParams(dp(32), dp(32)));
            TextView nt = text("Navegação", 20, WHITE, true);
            nt.setSingleLine(true);
            LinearLayout.LayoutParams ntLp = new LinearLayout.LayoutParams(WRAP, WRAP);
            ntLp.leftMargin = dp(14);
            cardNav.addView(nt, ntLp);
        } else {
            cardNav.addView(icon(I_NAV, accent, 0), new LinearLayout.LayoutParams(dp(44), dp(44)));
            cardNav.addView(new View(this), new LinearLayout.LayoutParams(MATCH, 0, 1f));
            cardNav.addView(text("Navegação", 24, WHITE, true));
            cardNav.addView(navSub);
        }
        cardNav.setOnClickListener(v -> openPreferred(KEY_NAV, navIntent()));
        cardNav.setOnLongClickListener(v -> {
            showAppPicker(KEY_NAV, "App de navegação");
            return true;
        });
        column.addView(cardNav, new LinearLayout.LayoutParams(MATCH, 0, navW));

        View cardPhone, cardSettings;
        if (myCarOn) {
            View mc = buildMyCar();
            LinearLayout.LayoutParams mcLp = new LinearLayout.LayoutParams(MATCH, 0, 1.75f);
            mcLp.topMargin = dp(12);
            column.addView(mc, mcLp);
            enterViews.add(mc);
            LinearLayout row = new LinearLayout(this);
            LinearLayout tPhone = miniTile(I_PHONE, "Telefone");
            tPhone.setOnClickListener(v -> openPreferred(KEY_PHONE, new Intent(Intent.ACTION_DIAL)));
            tPhone.setOnLongClickListener(v -> {
                showAppPicker(KEY_PHONE, "App de telefone");
                return true;
            });
            LinearLayout tSet = miniTile(I_TUNE, "Ajustes");
            tSet.setOnClickListener(v -> openPreferred(KEY_SETTINGS, new Intent(Settings.ACTION_SETTINGS)));
            tSet.setOnLongClickListener(v -> {
                showAppPicker(KEY_SETTINGS, "App de ajustes");
                return true;
            });
            phoneSub = text("", 12, MUTED, false);
            settingsSub = text("", 12, MUTED, false);
            row.addView(tPhone, new LinearLayout.LayoutParams(0, MATCH, 1f));
            LinearLayout.LayoutParams tsLp = new LinearLayout.LayoutParams(0, MATCH, 1f);
            tsLp.leftMargin = dp(10);
            row.addView(tSet, tsLp);
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(MATCH, 0, 0.6f);
            rowLp.topMargin = dp(12);
            column.addView(row, rowLp);
            cardPhone = tPhone;
            cardSettings = tSet;
        } else {
        LinearLayout cp0 = smallCard(I_PHONE, "Telefone");
        phoneSub = (TextView) cp0.getTag();
        cp0.setOnClickListener(v -> openPreferred(KEY_PHONE, new Intent(Intent.ACTION_DIAL)));
        cp0.setOnLongClickListener(v -> {
            showAppPicker(KEY_PHONE, "App de telefone");
            return true;
        });
        LinearLayout.LayoutParams cpLp = new LinearLayout.LayoutParams(MATCH, 0, 0.7f);
        cpLp.topMargin = dp(14);
        column.addView(cp0, cpLp);
        cardPhone = cp0;

        LinearLayout cs0 = smallCard(I_TUNE, "Ajustes");
        settingsSub = (TextView) cs0.getTag();
        cs0.setOnClickListener(v ->
                openPreferred(KEY_SETTINGS, new Intent(Settings.ACTION_SETTINGS)));
        cs0.setOnLongClickListener(v -> {
            showAppPicker(KEY_SETTINGS, "App de ajustes");
            return true;
        });
        LinearLayout.LayoutParams csLp = new LinearLayout.LayoutParams(MATCH, 0, 0.7f);
        csLp.topMargin = dp(14);
        column.addView(cs0, csLp);
        cardSettings = cs0;

        }

        enterViews.add(carFrame);
        enterViews.add(cardMusic);
        enterViews.add(cardNav);
        enterViews.add(cardPhone);
        enterViews.add(cardSettings);
        return cards;
    }

    /** Anel de velocidade (tema Sport). */
    private static class RingView extends View {
        private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.RectF rf = new android.graphics.RectF();
        private final int normal;
        private float val = 0f;
        private boolean drawText = false;
        private String num = "--", unit = "km/h";
        private int rpm = -1;
        private boolean alertOn = false;
        private final Paint xp = new Paint(Paint.ANTI_ALIAS_FLAG);

        void setDrawText(boolean on) {
            drawText = on;
        }

        void setSpeedText(String n, String u) {
            if (n.equals(num) && u.equals(unit)) return;
            num = n;
            unit = u;
            invalidate();
        }

        void setRpm(int r) {
            if (r == rpm) return;
            rpm = r;
            invalidate();
        }

        RingView(Context c, int color) {
            super(c);
            normal = color;
            float d = c.getResources().getDisplayMetrics().density;
            tp.setStyle(Paint.Style.STROKE);
            tp.setStrokeWidth(7 * d);
            tp.setStrokeCap(Paint.Cap.ROUND);
            tp.setColor(0x33FFFFFF);
            pp.setStyle(Paint.Style.STROKE);
            pp.setStrokeWidth(7 * d);
            pp.setStrokeCap(Paint.Cap.ROUND);
            pp.setColor(color);
        }

        void setValue(float v) {
            val = Math.max(0f, Math.min(1f, v));
            invalidate();
        }

        void setAlert(boolean on) {
            alertOn = on;
            pp.setColor(on ? 0xFFFF4D4D : normal);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas cv) {
            float d = getResources().getDisplayMetrics().density;
            float side = Math.min(getWidth(), getHeight()) - 10 * d;
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            rf.set(cx - side / 2f, cy - side / 2f, cx + side / 2f, cy + side / 2f);
            cv.drawArc(rf, 135, 270, false, tp);
            if (val > 0.005f) cv.drawArc(rf, 135, 270 * val, false, pp);
            if (!drawText) return;
            // anel interno fino: rotação do motor
            float in2 = 15 * d;
            android.graphics.RectF r2 = new android.graphics.RectF(rf.left + in2, rf.top + in2, rf.right - in2, rf.bottom - in2);
            Paint rp = new Paint(Paint.ANTI_ALIAS_FLAG);
            rp.setStyle(Paint.Style.STROKE);
            rp.setStrokeWidth(3 * d);
            rp.setStrokeCap(Paint.Cap.ROUND);
            rp.setColor(0x22FFFFFF);
            cv.drawArc(r2, 135, 270, false, rp);
            if (rpm > 0) {
                rp.setColor(0xCCFFFFFF);
                cv.drawArc(r2, 135, 270 * Math.min(1f, rpm / 7000f), false, rp);
            }
            xp.setTextAlign(Paint.Align.CENTER);
            xp.setColor(alertOn ? 0xFFFF4D4D : 0xFFFFFFFF);
            xp.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
            xp.setTextSize(side * 0.32f);
            float base = cy - (xp.ascent() + xp.descent()) / 2f - side * 0.02f;
            cv.drawText(num, cx, base, xp);
            xp.setTypeface(Typeface.DEFAULT);
            xp.setColor(0xFFB4BCC8);
            xp.setTextSize(side * 0.095f);
            cv.drawText(unit, cx, base + side * 0.13f, xp);
            if (rpm >= 0) {
                xp.setColor(0xFFFFFFFF);
                xp.setTextSize(side * 0.10f);
                cv.drawText(rpm + " rpm", cx, cy + side * 0.46f, xp);
            }
        }
    }

    /** Feixes de luz diagonais (mesmo padrão da foto do carro) com brilho suave e pulsação lenta. */
    private static class BeamsView extends View {
        private final int color;
        private final float strength;
        private final boolean animate;
        private final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float phase = 0f;
        private ValueAnimator va;

        BeamsView(Context c, int color, float strength, boolean animate) {
            super(c);
            this.color = color;
            this.strength = strength;
            this.animate = animate;
            setClickable(false);
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (animate) {
                va = ValueAnimator.ofFloat(0f, (float) (2 * Math.PI));
                va.setDuration(9000);
                va.setRepeatCount(ValueAnimator.INFINITE);
                va.setInterpolator(new android.view.animation.LinearInterpolator());
                va.addUpdateListener(a -> {
                    phase = (Float) a.getAnimatedValue();
                    invalidate();
                });
                va.start();
            }
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (va != null) va.cancel();
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            int rgb = color & 0x00FFFFFF;
            float pulse = 0.85f + 0.15f * (float) Math.sin(phase);
            pt.setShader(new RadialGradient(w * 0.86f, h * 0.05f, Math.max(w, h) * 0.75f,
                    ((int) (0x66 * strength * pulse) << 24) | rgb, rgb, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, pt);
            pt.setShader(new RadialGradient(w * 0.1f, h * 1.0f, Math.max(w, h) * 0.5f,
                    ((int) (0x38 * strength * pulse) << 24) | rgb, rgb, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, pt);
            float len = (float) Math.hypot(w, h);
            float[] off = {-0.16f, -0.07f, 0.03f, 0.13f};
            float[] th = {0.085f, 0.022f, 0.10f, 0.03f};
            float[] al = {0.85f, 0.6f, 1f, 0.55f};
            c.save();
            c.translate(w * 0.82f + (float) Math.sin(phase) * w * 0.012f, h * 0.35f);
            c.rotate(-56f);
            for (int k = 0; k < off.length; k++) {
                float top = off[k] * w, bh = th[k] * w;
                int a = (int) (0xB0 * strength * al[k] * pulse);
                pt.setShader(new LinearGradient(-len, 0, len, 0,
                        new int[]{rgb, (a << 24) | rgb, (a << 24) | rgb, rgb},
                        new float[]{0.2f, 0.5f, 0.62f, 0.9f}, Shader.TileMode.CLAMP));
                c.drawRect(-len, top, len, top + bh, pt);
            }
            c.restore();
            pt.setShader(null);
        }
    }

    private void chooseBeamColor() {
        final int cur = prefs.getInt(K_BEAM_COL, 0);
        choose("Cor dos feixes", BEAM_NAMES, cur, i -> {
            if (i == 7) {
                final EditText et = new EditText(this);
                et.setSingleLine(true);
                et.setHint("#RRGGBB");
                new AlertDialog.Builder(this)
                        .setTitle("Cor personalizada (hexadecimal)")
                        .setView(et)
                        .setPositiveButton("OK", (d, w) -> {
                            try {
                                String t = et.getText().toString().trim();
                                if (!t.startsWith("#")) t = "#" + t;
                                int col = Color.parseColor(t) | 0xFF000000;
                                prefs.edit().putInt(K_BEAM_CUSTOM, col).putInt(K_BEAM_COL, 7).apply();
                                rebuild(true);
                            } catch (Exception e) {
                                toast("Cor inválida. Exemplo: #FF2A36");
                            }
                        })
                        .setNegativeButton("Cancelar", null)
                        .show();
            } else {
                putInt(K_BEAM_COL, i);
            }
        });
    }

    // busca de novos dispositivos Bluetooth (para o adaptador OBD)
    private BroadcastReceiver scanReceiver;
    private AlertDialog scanDialog;

    private void scanObdDevices() {
        final BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null || !ad.isEnabled()) {
            toast("Ative o Bluetooth primeiro");
            return;
        }
        final List<BluetoothDevice> found = new ArrayList<>();
        final List<String> labels = new ArrayList<>();
        final android.widget.ArrayAdapter<String> adp = new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels);
        for (BluetoothDevice d : ad.getBondedDevices()) {
            found.add(d);
            labels.add((d.getName() != null ? d.getName() : "?") + "  (pareado)");
        }
        ListView lv = new ListView(this);
        lv.setAdapter(adp);
        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("Buscando dispositivos...")
                .setView(lv)
                .setNegativeButton("Fechar", null)
                .create();
        scanDialog = dlg;
        scanReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String a = intent.getAction();
                if (BluetoothDevice.ACTION_FOUND.equals(a)) {
                    BluetoothDevice d = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    if (d == null) return;
                    for (BluetoothDevice x : found) if (x.getAddress().equals(d.getAddress())) return;
                    found.add(d);
                    labels.add((d.getName() != null ? d.getName() : d.getAddress()) + "  (novo)");
                    adp.notifyDataSetChanged();
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(a)) {
                    dlg.setTitle("Escolha o adaptador OBD");
                }
            }
        };
        IntentFilter f = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(scanReceiver, f);
        dlg.setOnDismissListener(d -> {
            try {
                ad.cancelDiscovery();
            } catch (Exception ignored) {
            }
            try {
                if (scanReceiver != null) unregisterReceiver(scanReceiver);
            } catch (Exception ignored) {
            }
            scanReceiver = null;
        });
        lv.setOnItemClickListener((p, v, pos, id) -> {
            BluetoothDevice d = found.get(pos);
            try {
                ad.cancelDiscovery();
            } catch (Exception ignored) {
            }
            if (d.getBondState() == BluetoothDevice.BOND_NONE) {
                try {
                    d.createBond();
                } catch (Exception ignored) {
                }
                toast("Confirme o pareamento (senha 1234 ou 0000) e depois toque em Conectar");
            }
            prefs.edit().putBoolean(K_OBD, true).putString(K_OBD_ADDR, d.getAddress())
                    .putString(K_OBD_NAME, d.getName() != null ? d.getName() : d.getAddress()).apply();
            dlg.dismiss();
            stopObd();
            startObd();
            rebuild(true);
        });
        dlg.show();
        try {
            ad.startDiscovery();
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ luzes LED (Bluetooth BLE)

    private static class LedDev {
        android.bluetooth.BluetoothGatt gatt;
        android.bluetooth.BluetoothGattCharacteristic ch;
        volatile boolean ready, connecting;
        byte[] pending;
        int retry;
        boolean auto;
    }

    private final LedDev[] leds = {new LedDev(), new LedDev()};
    private final int[] ledColor = {0xFFFF0000, 0xFFFF0000};
    private final int[] ledBright = {100, 100};
    private static final String[] LED_ADDR = {"led1_addr", "led2_addr"};
    private static final String[] LED_NAME = {"led1_name", "led2_name"};
    private static final String[] LED_PROTO = {"led1_proto", "led2_proto"};
    private static final String[] LED_PROTO_NAMES = {"Automático (testa os formatos)", "ELK-BLEDOM (7E 07)", "ELK-BLEDDM (7E 00)", "Triones / LotusLamp"};
    private static final int[] LED_SWATCH = {0xFFFF0000, 0xFF00FF00, 0xFF0000FF, 0xFF00FFFF, 0xFFFFFF00,
            0xFFFFFFFF, 0xFFFF0080, 0xFFFF7A00, 0xFF9B30FF};

    private byte[][] ledColorFrames(int slot) {
        int c = ledColor[slot];
        float k = ledBright[slot] / 100f;
        byte r = (byte) Math.round(Color.red(c) * k), g = (byte) Math.round(Color.green(c) * k), b = (byte) Math.round(Color.blue(c) * k);
        byte[] fa = {0x7E, 0x07, 0x05, 0x03, r, g, b, 0x10, (byte) 0xEF};
        byte[] fb = {0x7E, 0x00, 0x05, 0x03, r, g, b, 0x00, (byte) 0xEF};
        byte[] ft = {0x56, r, g, b, 0x00, (byte) 0xF0, (byte) 0xAA};
        switch (prefs.getInt(LED_PROTO[slot], 0)) {
            case 1: return new byte[][]{fa};
            case 2: return new byte[][]{fb};
            case 3: return new byte[][]{ft};
            default: return new byte[][]{fa, fb, ft};
        }
    }

    private byte[][] ledPowerFrames(int slot, boolean on) {
        byte[] fa = on ? new byte[]{0x7E, 0x04, 0x04, (byte) 0xF0, 0x00, 0x01, (byte) 0xFF, 0x00, (byte) 0xEF}
                : new byte[]{0x7E, 0x04, 0x04, 0x00, 0x00, 0x00, (byte) 0xFF, 0x00, (byte) 0xEF};
        byte[] fb = on ? new byte[]{0x7E, 0x00, 0x04, (byte) 0xF0, 0x00, 0x01, (byte) 0xFF, 0x00, (byte) 0xEF}
                : new byte[]{0x7E, 0x00, 0x04, 0x00, 0x00, 0x00, (byte) 0xFF, 0x00, (byte) 0xEF};
        byte[] ft = on ? new byte[]{(byte) 0xCC, 0x23, 0x33} : new byte[]{(byte) 0xCC, 0x24, 0x33};
        switch (prefs.getInt(LED_PROTO[slot], 0)) {
            case 1: return new byte[][]{fa};
            case 2: return new byte[][]{fb};
            case 3: return new byte[][]{ft};
            default: return new byte[][]{fa, fb, ft};
        }
    }

    private void ledSendAll(final int slot, byte[][] frames) {
        for (int i = 0; i < frames.length; i++) {
            final byte[] f = frames[i];
            handler.postDelayed(() -> ledSend(slot, f), i * 150L);
        }
    }

    private void ledWrite(LedDev d, byte[] data) {
        try {
            int pr = d.ch.getProperties();
            d.ch.setWriteType((pr & android.bluetooth.BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                    ? android.bluetooth.BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                    : android.bluetooth.BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            d.ch.setValue(data);
            d.gatt.writeCharacteristic(d.ch);
        } catch (Exception ignored) {
        }
    }

    private void ledSend(final int slot, byte[] data) {
        final String addr = prefs.getString(LED_ADDR[slot], null);
        if (addr == null) {
            toast("Escolha o dispositivo primeiro");
            return;
        }
        final LedDev d = leds[slot];
        if (d.ready && d.ch != null && d.gatt != null) {
            ledWrite(d, data);
            return;
        }
        d.pending = data;
        if (d.connecting) return;
        d.connecting = true;
        try {
            if (d.gatt != null) d.gatt.close();
        } catch (Exception ignored) {
        }
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            BluetoothDevice dev = ad.getRemoteDevice(addr);
            android.bluetooth.BluetoothGattCallback cb = new android.bluetooth.BluetoothGattCallback() {
                @Override
                public void onConnectionStateChange(android.bluetooth.BluetoothGatt g, int status, int newState) {
                    if (newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED) {
                        runOnUiThread(() -> toast("Luz conectada"));
                        final android.bluetooth.BluetoothGatt gg = g;
                        handler.postDelayed(() -> {
                            try {
                                gg.discoverServices();
                            } catch (Exception ignored) {
                            }
                        }, 250);
                    } else {
                        final int stt = status;
                        runOnUiThread(() -> toast("Luz desconectada (código " + stt + "). Feche o app da fita no celular."));
                        if (!d.ready) d.auto = !d.auto;
                        d.ready = false;
                        d.connecting = false;
                        try {
                            g.close();
                        } catch (Exception ignored) {
                        }
                        if (d.gatt == g) d.gatt = null;
                        if (d.pending != null && d.retry < 2) {
                            d.retry++;
                            final byte[] pd = d.pending;
                            handler.postDelayed(() -> ledSend(slot, pd), 900);
                        }
                    }
                }

                @Override
                public void onServicesDiscovered(android.bluetooth.BluetoothGatt g, int status) {
                    android.bluetooth.BluetoothGattCharacteristic best = null, fb = null;
                    for (android.bluetooth.BluetoothGattService sv : g.getServices()) {
                        for (android.bluetooth.BluetoothGattCharacteristic c : sv.getCharacteristics()) {
                            int pr = c.getProperties();
                            if ((pr & (android.bluetooth.BluetoothGattCharacteristic.PROPERTY_WRITE
                                    | android.bluetooth.BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) == 0) continue;
                            String u = c.getUuid().toString().toLowerCase(Locale.US);
                            if (best == null && (u.contains("fff3") || u.contains("ffd9") || u.contains("ffe1"))) best = c;
                            if (fb == null) fb = c;
                        }
                    }
                    d.ch = best != null ? best : fb;
                    final String cu = d.ch != null ? d.ch.getUuid().toString().substring(4, 8) : "nenhum";
                    runOnUiThread(() -> toast("Canal de controle: " + cu));
                    d.connecting = false;
                    d.ready = d.ch != null;
                    if (d.ready) {
                        d.retry = 0;
                        byte[] pnd = d.pending;
                        d.pending = null;
                        if (pnd != null) ledWrite(d, pnd);
                    } else {
                        runOnUiThread(() -> toast("Não encontrei o controle de cor nesse dispositivo"));
                    }
                }
            };
            if (Build.VERSION.SDK_INT >= 23) {
                d.gatt = dev.connectGatt(this, d.auto, cb, BluetoothDevice.TRANSPORT_LE);
            } else {
                d.gatt = dev.connectGatt(this, false, cb);
            }
        } catch (Exception e) {
            d.connecting = false;
            toast("Não foi possível conectar à luz");
        }
    }

    private void ledCloseAll() {
        for (LedDev d : leds) {
            try {
                if (d.gatt != null) d.gatt.close();
            } catch (Exception ignored) {
            }
            d.gatt = null;
            d.ready = false;
            d.connecting = false;
        }
    }

    private void scanLedDevices(final int slot, final Runnable done) {
        final BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null || !ad.isEnabled()) {
            toast("Ative o Bluetooth primeiro");
            return;
        }
        final List<BluetoothDevice> found = new ArrayList<>();
        final List<String> labels = new ArrayList<>();
        final android.widget.ArrayAdapter<String> adp = new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels);
        ListView lv = new ListView(this);
        lv.setAdapter(adp);
        final BluetoothAdapter.LeScanCallback cb = (dev, rssi, rec) -> runOnUiThread(() -> {
            for (BluetoothDevice x : found) if (x.getAddress().equals(dev.getAddress())) return;
            found.add(dev);
            labels.add((dev.getName() != null ? dev.getName() : "(sem nome)") + "  " + dev.getAddress());
            adp.notifyDataSetChanged();
        });
        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("Buscando luzes (deixe a fita ligada)...")
                .setView(lv)
                .setNegativeButton("Fechar", null)
                .create();
        dlg.setOnDismissListener(d -> {
            try {
                ad.stopLeScan(cb);
            } catch (Exception ignored) {
            }
        });
        lv.setOnItemClickListener((p, v, pos, id) -> {
            BluetoothDevice d = found.get(pos);
            try {
                ad.stopLeScan(cb);
            } catch (Exception ignored) {
            }
            prefs.edit().putString(LED_ADDR[slot], d.getAddress())
                    .putString(LED_NAME[slot], d.getName() != null ? d.getName() : d.getAddress()).apply();
            ledCloseAll();
            dlg.dismiss();
            if (done != null) done.run();
        });
        dlg.show();
        try {
            ad.startLeScan(cb);
        } catch (Exception e) {
            toast("Não foi possível buscar dispositivos");
        }
    }

    private void showLedDialog() {
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(22), dp(8), dp(22), dp(8));
        sv.addView(col, new ScrollView.LayoutParams(MATCH, WRAP));
        addLedSection(col, 0, "Fita do painel");
        addLedSection(col, 1, "Zona pé");
        new AlertDialog.Builder(this).setTitle("Luzes do carro").setView(sv)
                .setPositiveButton("Fechar", null).show();
    }

    private void addLedSection(final LinearLayout col, final int slot, String title) {
        TextView t = text(title, 18, WHITE, true);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(WRAP, WRAP);
        tl.topMargin = dp(14);
        col.addView(t, tl);
        final TextView devTv = text("", 13, MUTED, false);
        devTv.setText(prefs.getString(LED_NAME[slot], "Nenhum dispositivo escolhido"));
        col.addView(devTv);

        LinearLayout row = new LinearLayout(this);
        android.widget.Button bPick = new android.widget.Button(this);
        bPick.setText("Escolher");
        bPick.setOnClickListener(v -> scanLedDevices(slot, () -> devTv.setText(prefs.getString(LED_NAME[slot], ""))));
        android.widget.Button bOn = new android.widget.Button(this);
        bOn.setText("Ligar");
        bOn.setOnClickListener(v -> {
            ledSendAll(slot, ledPowerFrames(slot, true));
            handler.postDelayed(() -> ledSendAll(slot, ledColorFrames(slot)), 800);
        });
        android.widget.Button bOff = new android.widget.Button(this);
        bOff.setText("Desligar");
        bOff.setOnClickListener(v -> ledSendAll(slot, ledPowerFrames(slot, false)));
        row.addView(bPick, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(bOn, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(bOff, new LinearLayout.LayoutParams(0, WRAP, 1f));
        col.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));

        LinearLayout sw = new LinearLayout(this);
        sw.setGravity(Gravity.CENTER_VERTICAL);
        int[] cols = new int[LED_SWATCH.length + 1];
        System.arraycopy(LED_SWATCH, 0, cols, 0, LED_SWATCH.length);
        cols[LED_SWATCH.length] = accent;
        for (final int cc : cols) {
            View dot = new View(this);
            GradientDrawable gd = new GradientDrawable();
            gd.setShape(GradientDrawable.OVAL);
            gd.setColor(cc);
            gd.setStroke(dp(1), 0x88FFFFFF);
            dot.setBackground(gd);
            dot.setOnClickListener(v -> {
                ledColor[slot] = cc;
                ledSendAll(slot, ledColorFrames(slot));
            });
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(34), dp(34));
            dl.rightMargin = dp(8);
            sw.addView(dot, dl);
        }
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.addView(sw);
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(MATCH, WRAP);
        hl.topMargin = dp(8);
        col.addView(hs, hl);

        android.widget.SeekBar sb = new android.widget.SeekBar(this);
        sb.setMax(100);
        sb.setProgress(ledBright[slot]);
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar b, int p, boolean user) {
                if (user) ledBright[slot] = Math.max(1, p);
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar b) {
            }

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar b) {
                ledSendAll(slot, ledColorFrames(slot));
            }
        });
        TextView bl = text("Brilho", 12, MUTED, false);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(WRAP, WRAP);
        blp.topMargin = dp(8);
        col.addView(bl, blp);
        col.addView(sb, new LinearLayout.LayoutParams(MATCH, WRAP));

        final android.widget.Button bProto = new android.widget.Button(this);
        bProto.setAllCaps(false);
        bProto.setText("Protocolo: " + LED_PROTO_NAMES[prefs.getInt(LED_PROTO[slot], 0)]);
        bProto.setOnClickListener(v -> {
            int nx = (prefs.getInt(LED_PROTO[slot], 0) + 1) % 4;
            prefs.edit().putInt(LED_PROTO[slot], nx).apply();
            bProto.setText("Protocolo: " + LED_PROTO_NAMES[nx]);
        });
        col.addView(bProto, new LinearLayout.LayoutParams(MATCH, WRAP));
    }

    private void buildSettingsHome() {
        for (int r = 0; r < TAB_NAMES.length; r += 2) {
            LinearLayout row = new LinearLayout(this);
            for (int c = 0; c < 2; c++) {
                final int t = r + c;
                LinearLayout tile = new LinearLayout(this);
                tile.setOrientation(LinearLayout.VERTICAL);
                tile.setGravity(Gravity.CENTER_VERTICAL);
                tile.setBackground(states(shape(0x33FFFFFF, 24, accent), shape(0x14FFFFFF, 24, 0x1FFFFFFF)));
                tile.setPadding(dp(20), dp(16), dp(16), dp(16));
                tile.setClickable(true);
                tile.addView(icon(TAB_ICONS[t], accent, 0), new LinearLayout.LayoutParams(dp(34), dp(34)));
                TextView tt = text(TAB_NAMES[t], 19, WHITE, true);
                LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(WRAP, WRAP);
                tl.topMargin = dp(10);
                tile.addView(tt, tl);
                tile.addView(text(TAB_SUBS[t], 12, MUTED, false));
                tile.setOnClickListener(v -> {
                    settingsTab = t;
                    fillSettings();
                    settingsScroll.scrollTo(0, 0);
                });
                tile.setMinimumHeight(dp(130));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
                if (c == 1) lp.leftMargin = dp(12);
                row.addView(tile, lp);
            }
            LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(MATCH, WRAP);
            rl.bottomMargin = dp(12);
            settingsRows.addView(row, rl);
        }
    }

    private String money(double v) {
        return "R$ " + String.format(Locale.US, "%.2f", v).replace('.', ',');
    }

    private void askPrice() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        float cur = prefs.getFloat(K_PRICE, 0f);
        if (cur > 0) et.setText(String.format(Locale.US, "%.2f", cur).replace('.', ','));
        et.setHint("Ex.: 6,19");
        new AlertDialog.Builder(this).setTitle("Preço do litro (R$)").setView(et)
                .setPositiveButton("OK", (d, w) -> {
                    try {
                        float v = Float.parseFloat(et.getText().toString().trim().replace(',', '.'));
                        prefs.edit().putFloat(K_PRICE, v).apply();
                        updateCarDetail();
                        if (settingsPanel.getVisibility() == View.VISIBLE) fillSettings();
                    } catch (Exception e) {
                        toast("Valor inválido");
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void confirmResetTotals() {
        new AlertDialog.Builder(this).setTitle("Zerar total de gastos?")
                .setMessage("O total acumulado de litros, quilômetros e valor gasto volta a zero.")
                .setPositiveButton("Zerar", (d, w) -> {
                    totL = 0;
                    totKm = 0;
                    prefs.edit().putFloat(K_TOT_L, 0f).putFloat(K_TOT_KM, 0f).apply();
                    updateCarDetail();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void showPill(String text, int color, int ms) {
        if (topPill == null) return;
        final int tok = ++pillToken;
        topPill.setText(text);
        topPill.setBackground(shape(color, 100, 0x66FFFFFF));
        popIn(topPill);
        handler.postDelayed(() -> {
            if (tok == pillToken && topPill != null) popOut(topPill);
        }, ms);
    }

    private void setSportAuto(boolean on) {
        sportOn = on;
        showPill(on ? "MODO SPORT ATIVADO" : "MODO SPORT DESATIVADO", on ? 0xFFE5242B : 0xFF3A3F47, 4500);
        if (carViewRef != null) carViewRef.animateSport(on ? 1f : 0f, dur(700));
    }

    private void showLowFuel() {
        int cap = prefs.getInt(K_TANK, 50);
        double lit = obdFuel * cap / 100.0;
        double avg = tripL > 0.02 ? tripKm / tripL : -1;
        String msg = "Restam cerca de " + f1(lit) + " L (" + obdFuel + "%) no tanque.";
        if (avg > 0) msg += "\nAutonomia estimada: " + Math.round(lit * avg) + " km.";
        new AlertDialog.Builder(this).setTitle("Combustível baixo").setMessage(msg)
                .setPositiveButton("OK", null).show();
    }

    /** Alertas ligados aos dados do OBD: combustível baixo, Cold Start e Modo Sport. */
    private void carAlerts() {
        int pct = prefs.getInt(K_LOWFUEL_PCT, 15);
        if (obdFuel >= 0) {
            if (obdFuel > pct + 3) lowFuelShown = false;
            else if (prefs.getBoolean(K_LOWFUEL_ON, true) && obdFuel <= pct && !lowFuelShown && visible && !isFinishing()) {
                lowFuelShown = true;
                showLowFuel();
            }
        }
        if (prefs.getBoolean(K_COLD_ON, true) && coldCard != null && obdState == 2 && obdTemp > -900) {
            int end = prefs.getInt(K_COLD_END, 60);
            if (!coldActive) {
                if (!coldDone && obdTemp < 45) {
                    coldActive = true;
                    popIn(coldCard);
                } else if (!coldDone) {
                    coldDone = true;
                } else if (obdTemp < 40) {
                    coldDone = false;
                }
            }
            if (coldActive) {
                coldTemp.setText(Math.round(tempF ? obdTemp * 9f / 5f + 32f : obdTemp) + (tempF ? "°F" : "°C"));
                if (obdTemp >= end) {
                    coldTemp.setTextColor(WHITE);
                    coldIcon.setImageDrawable(new IconDrawable(I_TEMP, WHITE));
                    coldSub.setText("Motor aquecido");
                    coldActive = false;
                    coldDone = true;
                    handler.postDelayed(() -> {
                        if (coldCard != null && !coldActive) popOut(coldCard);
                    }, 4500);
                } else {
                    coldTemp.setTextColor(0xFF4DA3FF);
                    coldIcon.setImageDrawable(new IconDrawable(I_TEMP, 0xFF4DA3FF));
                    coldSub.setText("Aquecendo o motor... pegue leve até " + end + "°C");
                }
            }
        }
        if (prefs.getBoolean(K_SPORT_DET, true) && obdRpm > 0 && obdTemp >= 60 && obdSpeed >= 0 && obdSpeed < 2) {
            int thr = prefs.getInt(K_SPORT_RPM, 1000);
            long now = SystemClock.elapsedRealtime();
            if (obdRpm >= thr) {
                sportOffSince = 0;
                if (sportSince == 0) sportSince = now;
                if (!sportDet && now - sportSince >= 4000) {
                    sportDet = true;
                    setSportAuto(true);
                }
            } else if (obdRpm < thr - 80) {
                sportSince = 0;
                if (sportOffSince == 0) sportOffSince = now;
                if (sportDet && now - sportOffSince >= 4000) {
                    sportDet = false;
                    setSportAuto(false);
                }
            }
        }
    }

    private LinearLayout miniTile(int iconType, String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setBackground(bgCard(22));
        c.setClickable(true);
        c.setFocusable(true);
        pressable(c);
        LinearLayout.LayoutParams icLp = new LinearLayout.LayoutParams(dp(26), dp(26));
        icLp.gravity = Gravity.CENTER_HORIZONTAL;
        c.addView(icon(iconType, accent, 0), icLp);
        TextView t = text(title, 13, WHITE, true);
        t.setSingleLine(true);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        tLp.gravity = Gravity.CENTER_HORIZONTAL;
        tLp.topMargin = dp(2);
        c.addView(t, tLp);
        return c;
    }

    /** Cartão "Meu Carro": velocidade, combustível, temperatura (via OBD ELM327) e situação. */
    private View buildMyCar() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(bgCard(24));
        card.setPadding(dp(14), dp(10), dp(14), dp(10));
        card.setClickable(true);
        pressable(card);
        card.setOnClickListener(v -> {
            if (!prefs.getBoolean(K_OBD, false) || prefs.getString(K_OBD_ADDR, null) == null) {
                settingsTab = 2;
                showSettings();
            } else if (obdState != 2) {
                stopObd();
                obdState = 0;
                startObd();
                toast("Conectando ao OBD...");
                refreshCarCard();
            } else {
                showCarDetail();
            }
        });
        card.setOnLongClickListener(v -> {
            settingsTab = 2;
            showSettings();
            return true;
        });

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(icon(I_TUNE, accent, 0), new LinearLayout.LayoutParams(dp(20), dp(20)));
        TextView ht = text("Meu Carro", 16, WHITE, true);
        LinearLayout.LayoutParams htLp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        htLp.leftMargin = dp(8);
        head.addView(ht, htLp);
        head.addView(text(">", 16, MUTED, true));
        card.addView(head, new LinearLayout.LayoutParams(MATCH, WRAP));

        LinearLayout body = new LinearLayout(this);
        body.setGravity(Gravity.CENTER_VERTICAL);

        FrameLayout ringBox = new FrameLayout(this);
        ringRef = new RingView(this, accent);
        ringBox.addView(ringRef, new FrameLayout.LayoutParams(MATCH, MATCH));
        ringRef.setDrawText(true);
        ringRef.setSpeedText("--", mph ? "mph" : "km/h");
        body.addView(ringBox, new LinearLayout.LayoutParams(0, MATCH, 1f));

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.CENTER_VERTICAL);
        carFuelTv = text("--", 16, WHITE, true);
        right.addView(iconRow(I_FUEL, carFuelTv));
        LinearLayout bar = new LinearLayout(this);
        bar.setBackground(shape(0x33FFFFFF, 4, 0));
        fuelFill = new View(this);
        fuelFill.setBackground(shape(accent, 4, 0));
        fuelRest = new View(this);
        bar.addView(fuelFill, new LinearLayout.LayoutParams(0, MATCH, 0f));
        bar.addView(fuelRest, new LinearLayout.LayoutParams(0, MATCH, 100f));
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(MATCH, dp(5));
        barLp.topMargin = dp(3);
        barLp.bottomMargin = dp(8);
        right.addView(bar, barLp);
        carTempTv = text("--", 16, WHITE, true);
        right.addView(iconRow(I_TEMP, carTempTv));
        carConsTv = text("", 12, MUTED, false);
        carConsTv.setSingleLine(true);
        LinearLayout.LayoutParams ccLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        ccLp.topMargin = dp(6);
        right.addView(carConsTv, ccLp);
        LinearLayout.LayoutParams rLp = new LinearLayout.LayoutParams(0, MATCH, 1f);
        rLp.leftMargin = dp(8);
        body.addView(right, rLp);
        card.addView(body, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        LinearLayout foot = new LinearLayout(this);
        foot.setGravity(Gravity.CENTER);
        carCheck = text("✓", 11, onAccent(), true);
        carCheck.setGravity(Gravity.CENTER);
        carCheck.setBackground(shape(accent, 20, 0));
        foot.addView(carCheck, new LinearLayout.LayoutParams(dp(20), dp(20)));
        carStatusTv = text("", 14, WHITE, true);
        carStatusTv.setSingleLine(true);
        LinearLayout.LayoutParams csLp2 = new LinearLayout.LayoutParams(WRAP, WRAP);
        csLp2.leftMargin = dp(8);
        foot.addView(carStatusTv, csLp2);
        LinearLayout.LayoutParams fLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        fLp.topMargin = dp(4);
        card.addView(foot, fLp);
        refreshCarCard();
        return card;
    }

    private LinearLayout iconRow(int type, TextView tv) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(icon(type, accent, 0), new LinearLayout.LayoutParams(dp(20), dp(20)));
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(WRAP, WRAP);
        l.leftMargin = dp(8);
        r.addView(tv, l);
        return r;
    }

    private void refreshCarCard() {
        if (carStatusTv == null) return;
        boolean on = prefs.getBoolean(K_OBD, false);
        String status;
        int col = WHITE;
        boolean ok = true;
        if (!on) {
            status = "OBD desativado";
            col = MUTED;
            ok = false;
        } else if (obdState == 1) {
            status = "Conectando ao OBD...";
            col = MUTED;
            ok = false;
        } else if (obdState == 3 || obdState == 0) {
            status = obdState == 3 ? "OBD sem conexão (toque p/ tentar)" : "OBD indisponível";
            col = MUTED;
            ok = false;
        } else if (obdTemp > -900 && prefs.getInt(K_TEMP_WARN, 100) > 0 && obdTemp >= prefs.getInt(K_TEMP_WARN, 100)) {
            status = "Temperatura alta";
            col = 0xFFFFA62B;
            ok = false;
        } else if (obdFuel >= 0 && obdFuel <= 10) {
            status = "Combustível baixo";
            col = 0xFFFFA62B;
            ok = false;
        } else {
            status = "Tudo certo!";
        }
        carStatusTv.setText(status);
        carStatusTv.setTextColor(col);
        carCheck.setVisibility(ok ? View.VISIBLE : View.GONE);
        if (obdTemp > -900) {
            float tc = obdTemp;
            carTempTv.setText(Math.round(tempF ? tc * 9f / 5f + 32f : tc) + (tempF ? "°F" : "°C"));
            int tw = prefs.getInt(K_TEMP_WARN, 100);
            carTempTv.setTextColor(tw > 0 && obdTemp >= tw ? 0xFFFF4D4D : WHITE);
        } else {
            carTempTv.setText("--");
        }
        if (obdFuel >= 0) {
            carFuelTv.setText(prefs.getInt(K_FUEL_UNIT, 0) == 1
                    ? f1(obdFuel * prefs.getInt(K_TANK, 50) / 100.0) + " L" : obdFuel + "%");
            ((LinearLayout.LayoutParams) fuelFill.getLayoutParams()).weight = obdFuel;
            ((LinearLayout.LayoutParams) fuelRest.getLayoutParams()).weight = Math.max(0, 100 - obdFuel);
        } else {
            carFuelTv.setText("--");
            ((LinearLayout.LayoutParams) fuelFill.getLayoutParams()).weight = 0f;
            ((LinearLayout.LayoutParams) fuelRest.getLayoutParams()).weight = 100f;
        }
        fuelFill.requestLayout();
        fuelRest.requestLayout();
        if (carConsTv != null) {
            int hc = prefs.getInt(K_HOME_CONS, 0);
            String ct = "";
            if (hc == 0) {
                double av = tripL > 0.02 ? tripKm / tripL : -1;
                ct = av >= 0 ? "Média " + f1(av) + " km/l" : "Média --";
            } else if (hc == 1) {
                if (obdLph >= 0 && obdSpeed >= 5 && obdLph > 0.05) ct = "Agora " + f1(obdSpeed / obdLph) + " km/l";
                else if (obdLph >= 0) ct = "Agora " + f1(obdLph) + " L/h";
                else ct = "Agora --";
            }
            carConsTv.setText(ct);
            carConsTv.setVisibility(hc == 2 ? View.GONE : View.VISIBLE);
        }
        updateCarDetail();
    }

    private String f1(double v) {
        return String.format(Locale.US, "%.1f", v).replace('.', ',');
    }

    private void updateCarDetail() {
        TextView[] d = carDetail;
        if (d == null) return;
        int cap = prefs.getInt(K_TANK, 50);
        double km = obdSpeed;
        String inst = "--";
        if (obdLph >= 0) {
            if (km >= 5 && obdLph > 0.05) inst = f1(km / obdLph) + " km/l";
            else inst = f1(obdLph) + " L/h";
        }
        double avg = tripL > 0.02 ? tripKm / tripL : -1;
        double lit = obdFuel >= 0 ? obdFuel * cap / 100.0 : -1;
        d[0].setText(inst);
        d[1].setText(avg >= 0 ? f1(avg) + " km/l" : "--");
        d[2].setText(f1(tripKm) + " km");
        d[3].setText(lit >= 0 ? f1(lit) + " L" : "--");
        d[4].setText(lit >= 0 ? obdFuel + "% do tanque" : "Sem dado de combustível");
        d[9].setText(obdFuel < 0 ? "--" : (prefs.getInt(K_FUEL_UNIT, 0) == 1 ? f1(lit) + " L" : obdFuel + "%"));
        d[10].setText(lit >= 0 ? f1(cap - lit) + " L" : "--");
        d[11].setText(cap + " L");
        d[12].setText(f1(tripL) + " L");
        float price = prefs.getFloat(K_PRICE, 0f);
        d[13].setText(price > 0 ? money(price) : "Definir");
        d[17].setText("Toque para alterar");
        d[14].setText(price > 0 ? money(tripL * price) : "--");
        d[18].setText(f1(tripL) + " L · " + f1(tripKm) + " km");
        d[15].setText(price > 0 && avg > 0 ? money(price / avg) : "--");
        d[16].setText(price > 0 ? money(totL * price) : "--");
        d[19].setText(f1(totL) + " L · " + f1(totKm) + " km · toque para zerar");
        d[5].setText(lit >= 0 && avg > 0 ? Math.round(lit * avg) + " km" : "--");
        d[6].setText(obdRpm >= 0 ? String.valueOf(obdRpm) : "--");
        int tw = prefs.getInt(K_TEMP_WARN, 100);
        if (obdTemp > -900) {
            d[7].setText(Math.round(tempF ? obdTemp * 9f / 5f + 32f : obdTemp) + (tempF ? "°F" : "°C"));
            d[7].setTextColor(tw > 0 && obdTemp >= tw ? 0xFFFF4D4D : WHITE);
        } else {
            d[7].setText("--");
        }
        boolean useObd = obdState == 2 && obdSpeed >= 0;
        double sp = (useObd ? obdSpeed / 3.6 : speedMs) * (mph ? 2.23694 : 3.6);
        d[8].setText((useObd || hasFix) ? String.valueOf(Math.round(sp < 2 ? 0 : sp)) : "--");
        if (panelFuelFill != null && obdFuel >= 0) {
            ((LinearLayout.LayoutParams) panelFuelFill.getLayoutParams()).weight = obdFuel;
            ((LinearLayout.LayoutParams) panelFuelRest.getLayoutParams()).weight = Math.max(0, 100 - obdFuel);
            panelFuelFill.requestLayout();
            panelFuelRest.requestLayout();
        }
    }

    private LinearLayout statCard(int iconType, String label, int idx, TextView[] vals, int sizeSp, boolean bar) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setBackground(bgCard(24));
        c.setPadding(dp(20), dp(14), dp(20), dp(14));
        LinearLayout hd = new LinearLayout(this);
        hd.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout ibox = new FrameLayout(this);
        ibox.setBackground(shape((accent & 0x00FFFFFF) | 0x33000000, 12, 0));
        ibox.addView(icon(iconType, accent, 8), new FrameLayout.LayoutParams(MATCH, MATCH));
        hd.addView(ibox, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView l = text(label, 11, MUTED, true);
        l.setLetterSpacing(0.12f);
        l.setMaxLines(2);
        LinearLayout.LayoutParams ll0 = new LinearLayout.LayoutParams(0, WRAP, 1f);
        ll0.leftMargin = dp(10);
        hd.addView(l, ll0);
        c.addView(hd, new LinearLayout.LayoutParams(MATCH, WRAP));
        vals[idx] = text("--", sizeSp, WHITE, false);
        vals[idx].setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        vals[idx].setSingleLine(true);
        vals[idx].setIncludeFontPadding(false);
        LinearLayout.LayoutParams vl = new LinearLayout.LayoutParams(WRAP, WRAP);
        vl.topMargin = dp(14);
        c.addView(vals[idx], vl);
        if (bar) {
            LinearLayout b = new LinearLayout(this);
            b.setBackground(shape(0x33FFFFFF, 4, 0));
            panelFuelFill = new View(this);
            panelFuelFill.setBackground(shape(accent, 4, 0));
            panelFuelRest = new View(this);
            b.addView(panelFuelFill, new LinearLayout.LayoutParams(0, MATCH, 0f));
            b.addView(panelFuelRest, new LinearLayout.LayoutParams(0, MATCH, 100f));
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(MATCH, dp(7));
            bl.topMargin = dp(12);
            c.addView(b, bl);
            vals[4] = text("", 13, MUTED, false);
            vals[4].setSingleLine(true);
            LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(WRAP, WRAP);
            sl.topMargin = dp(8);
            c.addView(vals[4], sl);
        }
        return c;
    }

    /** Janela completa do Meu Carro, no mesmo visual da launcher. */
    private LinearLayout buildCarPanel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundColor(0xF2050608);
        p.setClickable(true);
        p.setPadding(dp(24), dp(16), dp(24), dp(20));
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(icon(I_TUNE, accent, 0), new LinearLayout.LayoutParams(dp(30), dp(30)));
        TextView ht = text("Meu Carro", 26, WHITE, true);
        carPanelTitle = ht;
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(0, WRAP, 1f);
        hl.leftMargin = dp(12);
        head.addView(ht, hl);
        TextView reset = text("Zerar viagem", 14, WHITE, true);
        reset.setPadding(dp(20), dp(12), dp(20), dp(12));
        reset.setBackground(states(glassLayer(100, true), glassLayer(100, false)));
        reset.setClickable(true);
        pressable(reset);
        reset.setOnClickListener(v -> {
            tripL = 0;
            tripKm = 0;
            updateCarDetail();
        });
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(WRAP, WRAP);
        rl.rightMargin = dp(12);
        head.addView(reset, rl);
        ImageView close = icon(I_CLOSE, WHITE, 12);
        close.setBackground(states(glassLayer(100, true), glassLayer(100, false)));
        pressable(close);
        close.setOnClickListener(v -> popOut(carPanel));
        head.addView(close, new LinearLayout.LayoutParams(dp(48), dp(48)));
        p.addView(head, new LinearLayout.LayoutParams(MATCH, WRAP));

        TextView[] v = new TextView[20];
        carPageViews.clear();
        carDots.clear();
        page0Cards.clear();
        // página 1: foto do carro + dados principais
        LinearLayout pg0 = new LinearLayout(this);
        panelCar = new CarView(this);
        if (!getFileStreamPath(F_CAR).exists()) {
            Bitmap sc = loadAsset("car_scene.jpg");
            if (sc != null) panelCar.setScene(sc, accent);
            else panelCar.set(loadCar(), accent, false);
        } else {
            panelCar.set(loadCar(), accent, false);
        }
        pg0.addView(panelCar, new LinearLayout.LayoutParams(0, MATCH, 1.35f));
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout g1 = new LinearLayout(this);
        LinearLayout g2 = new LinearLayout(this);
        LinearLayout[] gc = {statCard(I_SPEED, "VELOCIDADE", 8, v, 38, false), statCard(I_RPM, "ROTAÇÃO (RPM)", 6, v, 38, false),
                statCard(I_TEMP, "TEMPERATURA", 7, v, 38, false), statCard(I_FUEL, "COMBUSTÍVEL", 9, v, 38, false)};
        g1.addView(gc[0], new LinearLayout.LayoutParams(0, MATCH, 1f));
        LinearLayout.LayoutParams gl1 = new LinearLayout.LayoutParams(0, MATCH, 1f);
        gl1.leftMargin = dp(14);
        g1.addView(gc[1], gl1);
        g2.addView(gc[2], new LinearLayout.LayoutParams(0, MATCH, 1f));
        LinearLayout.LayoutParams gl2 = new LinearLayout.LayoutParams(0, MATCH, 1f);
        gl2.leftMargin = dp(14);
        g2.addView(gc[3], gl2);
        grid.addView(g1, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        LinearLayout.LayoutParams g2l = new LinearLayout.LayoutParams(MATCH, 0, 1f);
        g2l.topMargin = dp(14);
        grid.addView(g2, g2l);
        LinearLayout.LayoutParams gridLp = new LinearLayout.LayoutParams(0, MATCH, 1.65f);
        gridLp.leftMargin = dp(14);
        pg0.addView(grid, gridLp);
        for (View x : gc) page0Cards.add(x);
        page0Cards.add(panelCar);
        // página 2: consumo
        LinearLayout pg1 = new LinearLayout(this);
        View[] c1 = {statCard(I_FUEL, "CONSUMO AGORA", 0, v, 40, false), statCard(I_FUEL, "CONSUMO MÉDIO", 1, v, 40, false),
                statCard(I_NAV, "PERCURSO DESDE A PARTIDA", 2, v, 40, false), statCard(I_FUEL, "COMBUSTÍVEL USADO", 12, v, 40, false)};
        for (int k = 0; k < 4; k++) {
            LinearLayout.LayoutParams a1 = new LinearLayout.LayoutParams(0, MATCH, 1f);
            if (k > 0) a1.leftMargin = dp(14);
            pg1.addView(c1[k], a1);
        }
        // página 3: tanque
        LinearLayout pg2 = new LinearLayout(this);
        View[] c2 = {statCard(I_FUEL, "COMBUSTÍVEL NO TANQUE", 3, v, 40, true), statCard(I_FUEL, "FALTAM PARA COMPLETAR", 10, v, 40, false),
                statCard(I_NAV, "AUTONOMIA ESTIMADA", 5, v, 40, false), statCard(I_FUEL, "CAPACIDADE DO TANQUE", 11, v, 40, false)};
        for (int k = 0; k < 4; k++) {
            LinearLayout.LayoutParams a2 = new LinearLayout.LayoutParams(0, MATCH, k == 0 ? 1.3f : 1f);
            if (k > 0) a2.leftMargin = dp(14);
            pg2.addView(c2[k], a2);
        }
        // página 4: gastos
        LinearLayout pg3 = new LinearLayout(this);
        LinearLayout[] c3 = {statCard(I_COIN, "PREÇO DO COMBUSTÍVEL (R$/L)", 13, v, 36, false), statCard(I_COIN, "GASTO NA VIAGEM", 14, v, 36, false),
                statCard(I_COIN, "CUSTO POR KM", 15, v, 36, false), statCard(I_COIN, "TOTAL GASTO", 16, v, 36, false)};
        int[] subIdx = {17, 18, -1, 19};
        for (int k = 0; k < 4; k++) {
            if (subIdx[k] >= 0) {
                v[subIdx[k]] = text("", 12, MUTED, false);
                v[subIdx[k]].setSingleLine(true);
                LinearLayout.LayoutParams sl3 = new LinearLayout.LayoutParams(WRAP, WRAP);
                sl3.topMargin = dp(8);
                c3[k].addView(v[subIdx[k]], sl3);
            }
            LinearLayout.LayoutParams a3 = new LinearLayout.LayoutParams(0, MATCH, 1f);
            if (k > 0) a3.leftMargin = dp(14);
            pg3.addView(c3[k], a3);
        }
        c3[0].setClickable(true);
        c3[0].setOnClickListener(vw -> askPrice());
        c3[3].setClickable(true);
        c3[3].setOnClickListener(vw -> confirmResetTotals());
        carPagesHost = new FrameLayout(this);
        carPagesHost.setClickable(true);
        View[] pages = {pg0, pg1, pg2, pg3};
        for (View pgv : pages) {
            carPageViews.add(pgv);
            carPagesHost.addView(pgv, new FrameLayout.LayoutParams(MATCH, MATCH));
        }
        final GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (e1 == null || e2 == null) return false;
                float dx = e2.getX() - e1.getX();
                if (Math.abs(dx) > dp(70) && Math.abs(vx) > 300) {
                    goCarPage(carPage + (dx < 0 ? 1 : -1), true);
                    return true;
                }
                return false;
            }
        });
        carPagesHost.setOnTouchListener((vw, ev) -> {
            gd.onTouchEvent(ev);
            return true;
        });
        LinearLayout.LayoutParams hostLp = new LinearLayout.LayoutParams(MATCH, 0, 1f);
        hostLp.topMargin = dp(16);
        p.addView(carPagesHost, hostLp);
        // indicadores de página
        LinearLayout dots = new LinearLayout(this);
        dots.setGravity(Gravity.CENTER);
        for (int k = 0; k < 4; k++) {
            final int kk = k;
            View dt = new View(this);
            dt.setOnClickListener(vw -> goCarPage(kk, true));
            carDots.add(dt);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(22), dp(22));
            dots.addView(dt, dl);
        }
        LinearLayout.LayoutParams dotsLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        dotsLp.topMargin = dp(8);
        p.addView(dots, dotsLp);
        carDetail = v;
        updateCarDetail();
        return p;
    }

    private void goCarPage(int n, boolean anim) {
        n = Math.max(0, Math.min(carPageViews.size() - 1, n));
        carPage = n;
        if (carPanelTitle != null) carPanelTitle.setText("Meu Carro  ·  " + new String[]{"Visão geral", "Consumo", "Tanque", "Gastos"}[Math.min(3, n)]);
        float w = getResources().getDisplayMetrics().widthPixels;
        for (int i = 0; i < carPageViews.size(); i++) {
            View pv = carPageViews.get(i);
            float tx = (i - n) * w;
            float al = i == n ? 1f : 0f;
            pv.animate().cancel();
            if (anim) {
                pv.animate().setStartDelay(0).translationX(tx).alpha(al).setDuration(dur(380))
                        .setInterpolator(new DecelerateInterpolator(1.8f)).start();
            } else {
                pv.setTranslationX(tx);
                pv.setAlpha(al);
            }
        }
        for (int i = 0; i < carDots.size(); i++) {
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(i == n ? accent : 0x55FFFFFF);
            g.setStroke(dp(7), 0x00000000);
            carDots.get(i).setBackground(g);
        }
        if (anim && n > 0) {
            View pv = carPageViews.get(n);
            if (pv instanceof LinearLayout) {
                LinearLayout ll = (LinearLayout) pv;
                for (int i = 0; i < ll.getChildCount(); i++) {
                    View ch = ll.getChildAt(i);
                    ch.setAlpha(0f);
                    ch.setTranslationY(dp(24));
                    ch.animate().setStartDelay(dur(120 + i * 80)).alpha(1f).translationY(0f).setDuration(dur(450))
                            .setInterpolator(new DecelerateInterpolator(2f)).start();
                }
            }
        }
    }

    private void showCarDetail() {
        updateCarDetail();
        if (carPanel == null) return;
        goCarPage(0, false);
        for (int i = 0; i < page0Cards.size(); i++) {
            View ch = page0Cards.get(i);
            ch.animate().cancel();
            ch.setAlpha(0f);
            ch.setTranslationY(dp(26));
            ch.animate().setStartDelay(dur(150 + i * 90)).alpha(1f).translationY(0f).setDuration(dur(500))
                    .setInterpolator(new DecelerateInterpolator(2f)).start();
        }
        popIn(carPanel);
        if (panelCar != null) panelCar.startIntro(dur(2200));
    }

    // ------------------------------------------------------------------ OBD ELM327 (Bluetooth)

    private void startObd() {
        if (obdRun || !prefs.getBoolean(K_OBD, false)) return;
        final String addr = prefs.getString(K_OBD_ADDR, null);
        if (addr == null) {
            obdState = 0;
            return;
        }
        obdRun = true;
        totL = prefs.getFloat(K_TOT_L, 0f);
        totKm = prefs.getFloat(K_TOT_KM, 0f);
        final int gen = ++obdGen;
        obdThread = new Thread(() -> obdLoop(addr, gen));
        obdThread.start();
    }

    private void stopObd() {
        if (obdRun) saveTotals();
        obdRun = false;
        try {
            if (obdSock != null) obdSock.close();
        } catch (Exception ignored) {
        }
        obdSock = null;
        if (obdThread != null) obdThread.interrupt();
        obdThread = null;
    }

    private void obdUi(final int state) {
        obdState = state;
        runOnUiThread(this::refreshCarCard);
    }

    private String obdQuery(InputStream in, java.io.OutputStream out, String cmd, int timeoutMs) throws Exception {
        while (in.available() > 0) in.read();
        out.write((cmd + "\r").getBytes("US-ASCII"));
        out.flush();
        StringBuilder sb = new StringBuilder();
        long end = SystemClock.elapsedRealtime() + timeoutMs;
        while (SystemClock.elapsedRealtime() < end && obdRun) {
            if (in.available() > 0) {
                int ch = in.read();
                if (ch < 0) break;
                if (ch == '>') break;
                sb.append((char) ch);
            } else {
                Thread.sleep(25);
            }
        }
        return sb.toString().replace("\r", " ").replace("\n", " ").trim();
    }

    /** Extrai o primeiro byte de dados da resposta "41 PID XX". */
    private int obdByte(String resp, String pid) {
        if (resp == null) return -1;
        String r = resp.replace(" ", "").toUpperCase(Locale.US);
        int k = r.indexOf("41" + pid);
        if (k < 0 || r.length() < k + 6) return -1;
        try {
            return Integer.parseInt(r.substring(k + 4, k + 6), 16);
        } catch (Exception e) {
            return -1;
        }
    }

    private void obdLoop(String addr, int gen) {
        final java.util.UUID spp = java.util.UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
        while (obdRun && gen == obdGen) {
            android.bluetooth.BluetoothSocket sock = null;
            try {
                obdUi(1);
                BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
                if (ad == null || !ad.isEnabled()) throw new IllegalStateException("bt");
                ad.cancelDiscovery();
                BluetoothDevice dev = ad.getRemoteDevice(addr);
                Exception last = null;
                boolean okc = false;
                for (int attempt = 0; attempt < 3 && !okc && obdRun; attempt++) {
                    try {
                        if (attempt == 0) sock = dev.createRfcommSocketToServiceRecord(spp);
                        else if (attempt == 1) sock = dev.createInsecureRfcommSocketToServiceRecord(spp);
                        else sock = (android.bluetooth.BluetoothSocket) dev.getClass()
                                .getMethod("createRfcommSocket", int.class).invoke(dev, 1);
                        sock.connect();
                        okc = true;
                    } catch (Exception ex) {
                        last = ex;
                        try {
                            if (sock != null) sock.close();
                        } catch (Exception ignored) {
                        }
                        Thread.sleep(400);
                    }
                }
                if (!okc) throw last != null ? last : new Exception("sem conexão");
                obdSock = sock;
                InputStream in = sock.getInputStream();
                java.io.OutputStream out = sock.getOutputStream();
                obdQuery(in, out, "ATZ", 2500);
                String[] init = {"ATE0", "ATL0", "ATS0", "ATH0", "ATSP0"};
                for (String c : init) obdQuery(in, out, c, 1500);
                obdUi(2);
                int cycle = 0;
                int[] fl = new int[6];
                long lastT = SystemClock.elapsedRealtime();
                while (obdRun && gen == obdGen) {
                    String rt = obdQuery(in, out, "0105", 3000);
                    int t = obdByte(rt, "05");
                    if (t >= 0) obdTemp = t - 40;
                    else if (rt.toUpperCase(Locale.US).contains("UNABLE") || rt.contains("ERROR")) throw new Exception("obd");
                    if (fl[0] < 3) {
                        int sp = obdByte(obdQuery(in, out, "010D", 2500), "0D");
                        if (sp >= 0) {
                            obdSpeed = sp;
                            fl[0] = 0;
                        } else fl[0]++;
                    }
                    if (fl[1] < 3) {
                        int[] rr = obdBytes(obdQuery(in, out, "010C", 2500), "0C", 2);
                        if (rr != null) {
                            obdRpm = (rr[0] * 256 + rr[1]) / 4;
                            fl[1] = 0;
                        } else fl[1]++;
                    }
                    float lph = -1f;
                    if (fl[5] < 3) {
                        int[] rr = obdBytes(obdQuery(in, out, "015E", 2500), "5E", 2);
                        if (rr != null) {
                            lph = (rr[0] * 256 + rr[1]) / 20f;
                            fl[5] = 0;
                        } else fl[5]++;
                    }
                    if (lph < 0 && fl[2] < 3) {
                        int[] rr = obdBytes(obdQuery(in, out, "0110", 2500), "10", 2);
                        if (rr != null) {
                            lph = mafToLph((rr[0] * 256 + rr[1]) / 100.0);
                            fl[2] = 0;
                        } else fl[2]++;
                    }
                    if (lph < 0 && fl[3] < 3 && fl[4] < 3) {
                        int map = obdByte(obdQuery(in, out, "010B", 2500), "0B");
                        int iat = obdByte(obdQuery(in, out, "010F", 2500), "0F");
                        if (map >= 0 && iat >= 0) {
                            if (obdRpm <= 0) lph = 0f;
                            else {
                                double dispL = prefs.getInt(K_DISP, 20) / 10.0;
                                double tk = iat - 40 + 273.15;
                                double gs = (map * 1000.0 * (dispL / 1000.0) * 0.85 * obdRpm / 120.0) / (287.0 * tk) * 1000.0;
                                lph = mafToLph(gs);
                            }
                            fl[3] = 0;
                            fl[4] = 0;
                        } else {
                            if (map < 0) fl[3]++;
                            if (iat < 0) fl[4]++;
                        }
                    }
                    obdLph = lph;
                    long now = SystemClock.elapsedRealtime();
                    double dt = (now - lastT) / 1000.0;
                    lastT = now;
                    if (dt < 10) {
                        if (lph >= 0) {
                            tripL += lph * dt / 3600.0;
                            totL += lph * dt / 3600.0;
                        }
                        if (obdSpeed >= 0) {
                            tripKm += obdSpeed * dt / 3600.0;
                            totKm += obdSpeed * dt / 3600.0;
                        }
                    }
                    if (cycle % 40 == 0) saveTotals();
                    if (cycle % 6 == 0 && fl[0] < 100) {
                        int f = obdByte(obdQuery(in, out, "012F", 3000), "2F");
                        if (f >= 0) obdFuel = Math.round(f * 100f / 255f);
                    }
                    cycle++;
                    runOnUiThread(() -> {
                        refreshSpeed();
                        refreshCarCard();
                        carAlerts();
                    });
                    Thread.sleep(400);
                }
            } catch (Exception e) {
                if (!obdRun || gen != obdGen) break;
                obdErr = String.valueOf(e.getMessage());
                obdUi(3);
                try {
                    Thread.sleep(7000);
                } catch (InterruptedException ie) {
                    break;
                }
            } finally {
                try {
                    if (sock != null) sock.close();
                } catch (Exception ignored) {
                }
                obdSock = null;
            }
        }
    }

    private int[] obdBytes(String resp, String pid, int n) {
        if (resp == null) return null;
        String r = resp.replace(" ", "").toUpperCase(Locale.US);
        int k = r.indexOf("41" + pid);
        if (k < 0 || r.length() < k + 4 + 2 * n) return null;
        try {
            int[] o = new int[n];
            for (int i = 0; i < n; i++) o[i] = Integer.parseInt(r.substring(k + 4 + 2 * i, k + 6 + 2 * i), 16);
            return o;
        } catch (Exception e) {
            return null;
        }
    }

    private void saveTotals() {
        prefs.edit().putFloat(K_TOT_L, (float) totL).putFloat(K_TOT_KM, (float) totKm).apply();
    }

    private float mafToLph(double gs) {
        boolean eth = prefs.getInt(K_FUELT, 0) == 1;
        double afr = eth ? 9.0 : 14.0, dens = eth ? 789.0 : 750.0;
        return (float) (gs * 3600.0 / (afr * dens));
    }

    private void chooseObdDevice() {
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            if (ad == null || !ad.isEnabled()) {
                toast("Ative o Bluetooth e pareie o adaptador OBD primeiro");
                return;
            }
            final List<BluetoothDevice> list = new ArrayList<>(ad.getBondedDevices());
            if (list.isEmpty()) {
                toast("Nenhum aparelho pareado. Pareie o ELM327 (senha 1234 ou 0000) nos ajustes do Bluetooth");
                return;
            }
            String[] names = new String[list.size()];
            for (int k = 0; k < names.length; k++) {
                names[k] = (list.get(k).getName() != null ? list.get(k).getName() : "?") + "  " + list.get(k).getAddress();
            }
            choose("Adaptador OBD (ELM327)", names, -1, i -> {
                BluetoothDevice d = list.get(i);
                prefs.edit().putBoolean(K_OBD, true).putString(K_OBD_ADDR, d.getAddress())
                        .putString(K_OBD_NAME, d.getName() != null ? d.getName() : d.getAddress()).apply();
                stopObd();
                startObd();
                rebuild(true);
            });
        } catch (Throwable t) {
            toast("Não foi possível listar os aparelhos Bluetooth");
        }
    }

    // ------------------------------------------------------------------ alerta de velocidade

    private void playAlertSound(int idx) {
        idx = Math.max(0, Math.min(SA_FILES.length - 1, idx));
        try {
            File f = new File(getCacheDir(), SA_FILES[idx]);
            if (!f.exists()) {
                InputStream in = getAssets().open(SA_FILES[idx]);
                FileOutputStream out = new FileOutputStream(f);
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.close();
                in.close();
            }
            if (alertPlayer != null) {
                try {
                    alertPlayer.release();
                } catch (Exception ignored) {
                }
                alertPlayer = null;
            }
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
            final MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            mp.setDataSource(f.getAbsolutePath());
            mp.setOnPreparedListener(m -> {
                try {
                    m.start();
                } catch (Exception ignored) {
                }
            });
            mp.setOnCompletionListener(m -> {
                if (alertPlayer == m) alertPlayer = null;
                try {
                    m.release();
                } catch (Exception ignored) {
                }
                abandonFocus();
            });
            mp.setOnErrorListener((m, w, e) -> {
                if (alertPlayer == m) alertPlayer = null;
                try {
                    m.release();
                } catch (Exception ignored) {
                }
                abandonFocus();
                return true;
            });
            alertPlayer = mp;
            mp.prepareAsync();
        } catch (Exception ignored) {
        }
    }

    private boolean checkSpeedAlert(double v) {
        if (!prefs.getBoolean(K_SA_ON, false)) {
            saOver = false;
            return false;
        }
        int lim = prefs.getInt(K_SA_LIM, 80);
        long now = SystemClock.elapsedRealtime();
        if (v > lim) {
            int rep = prefs.getInt(K_SA_REP, 1);
            if (!saOver) {
                saOver = true;
                saLast = now;
                playAlertSound(prefs.getInt(K_SA_SND, 0));
            } else if (rep > 0 && now - saLast >= (rep == 1 ? 10000L : 30000L)) {
                saLast = now;
                playAlertSound(prefs.getInt(K_SA_SND, 0));
            }
        } else if (v < lim - 3) {
            saOver = false;
        }
        return saOver;
    }

    /** Barra inferior do tema Sport: atalhos reais para apps e ajustes. */
    private View buildSportNav() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(glassLayer(100, false));
        bar.setPadding(dp(10), dp(4), dp(10), dp(4));
        final int[] ic = {I_NAV, I_MUSIC, I_PHONE, I_APPS, I_GEAR};
        final String[] nm = {"Navegação", "Mídia", "Telefone", "Apps", "Ajustes"};
        for (int k = 0; k < ic.length; k++) {
            final int kk = k;
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER);
            it.setClickable(true);
            pressable(it);
            it.addView(icon(ic[k], k == 0 ? accent : WHITE, 0), new LinearLayout.LayoutParams(dp(26), dp(26)));
            TextView tv = text(nm[k], 11, k == 0 ? accent : MUTED, true);
            it.addView(tv);
            it.setOnClickListener(v -> {
                switch (kk) {
                    case 0: openPreferred(KEY_NAV, navIntent()); break;
                    case 1: openPreferred(KEY_MUSIC, musicIntent()); break;
                    case 2: openPreferred(KEY_PHONE, new Intent(Intent.ACTION_DIAL)); break;
                    case 3: showDrawer(); break;
                    default: showSettings(); break;
                }
            });
            bar.addView(it, new LinearLayout.LayoutParams(0, MATCH, 1f));
        }
        return bar;
    }

    /** Modo papel de parede: só uma barra de vidro com música, clima e velocidade. */
    private View buildWallpaperBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(glassLayer(34, false));
        bar.setPadding(dp(18), dp(14), dp(18), dp(14));

        // música
        MusicViews mv = newMusic(88, 18, 13);
        LinearLayout music = new LinearLayout(this);
        music.setGravity(Gravity.CENTER_VERTICAL);
        music.setClickable(true);
        swipeable(music);
        music.addView(mv.cover, new LinearLayout.LayoutParams(dp(88), dp(88)));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setClickable(true);
        info.setOnClickListener(v -> onMusicInfoClick());
        info.addView(mv.title, new LinearLayout.LayoutParams(MATCH, WRAP));
        LinearLayout.LayoutParams artLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        artLp.topMargin = dp(2);
        info.addView(mv.artist, artLp);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        infoLp.leftMargin = dp(14);
        music.addView(info, infoLp);
        music.addView(controls(mv, 50, 58));
        bar.addView(music, new LinearLayout.LayoutParams(0, WRAP, 1.9f));

        bar.addView(divider());

        // clima
        LinearLayout w = new LinearLayout(this);
        w.setGravity(Gravity.CENTER);
        w.addView(weatherBlock(40, 28, 12, true));
        bar.addView(w, new LinearLayout.LayoutParams(0, WRAP, 1.1f));

        bar.addView(divider());

        // velocidade
        LinearLayout sp = new LinearLayout(this);
        sp.setGravity(Gravity.CENTER);
        TextView num = text("--", 44, WHITE, false);
        num.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        num.setIncludeFontPadding(false);
        speedNums.add(num);
        sp.addView(num);
        TextView unit = text(mph ? "mph" : "km/h", 13, MUTED, false);
        LinearLayout.LayoutParams uLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        uLp.leftMargin = dp(6);
        uLp.topMargin = dp(18);
        sp.addView(unit, uLp);
        bar.addView(sp, new LinearLayout.LayoutParams(0, WRAP, 0.8f));
        enterViews.add(bar);
        return bar;
    }

    private View divider() {
        View d = new View(this);
        d.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(1), dp(56));
        lp.setMargins(dp(12), 0, dp(12), 0);
        d.setLayoutParams(lp);
        return d;
    }

    private LinearLayout card(int padDp) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(bgCard(28));
        c.setClickable(true);
        c.setFocusable(true);
        c.setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp));
        pressable(c);
        return c;
    }

    private LinearLayout smallCard(int iconType, String title) {
        LinearLayout c = new LinearLayout(this);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setBackground(bgCard(28));
        c.setClickable(true);
        c.setFocusable(true);
        c.setPadding(dp(18), dp(10), dp(18), dp(10));
        c.addView(icon(iconType, accent, 0), new LinearLayout.LayoutParams(dp(30), dp(30)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        colLp.leftMargin = dp(14);
        col.addView(text(title, 18, WHITE, true));
        TextView sub = text("", 12, MUTED, false);
        sub.setSingleLine(true);
        col.addView(sub);
        c.addView(col, colLp);
        c.setTag(sub);
        pressable(c);
        return c;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private ImageView icon(int type, int color, int padDp) {
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(new IconDrawable(type, color));
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp));
        return iv;
    }

    private ImageButton button(int type, int color, int padDp) {
        ImageButton ib = new ImageButton(this);
        ib.setImageDrawable(new IconDrawable(type, color));
        ib.setScaleType(ImageView.ScaleType.FIT_CENTER);
        ib.setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp));
        pressable(ib);
        return ib;
    }

    private void startCarEdit() {
        if (carViewRef == null || carEditBar == null) {
            toast("Disponível na tela inicial em modo Painel");
            return;
        }
        if (settingsPanel.getVisibility() == View.VISIBLE) hideSettings();
        carEditBar.setVisibility(View.VISIBLE);
        carViewRef.setEditing(true, null);
    }

    private void stopCarEdit() {
        if (carViewRef == null) return;
        carViewRef.setEditing(false, null);
        if (carEditBar != null) carEditBar.setVisibility(View.GONE);
        prefs.edit().putFloat(K_CAR_SC, carViewRef.getScaleV()).putFloat(K_CAR_DX, carViewRef.getDx())
                .putFloat(K_CAR_DY, carViewRef.getDy()).apply();
    }

    private void styleSportBtn(View pill) {
        GradientDrawable dot = new GradientDrawable();
        dot.setShape(GradientDrawable.OVAL);
        dot.setColor(sportOn ? 0xFF2ECC71 : 0xFFFF3B47);
        if (sportDot != null) sportDot.setBackground(dot);
        pill.setBackground(states(glassLayer(100, true), glassLayer(100, false)));
    }

    private MusicViews newMusic(int coverDp, float titleSp, float artistSp) {
        MusicViews mv = new MusicViews();
        ImageView cv = new ImageView(this);
        cv.setBackground(shape(0x33FFFFFF, 18, 0));
        cv.setClipToOutline(true);
        final int rad = dp(18);
        cv.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), rad);
            }
        });
        mv.cover = cv;
        mv.title = text(curTitle, titleSp, WHITE, true);
        mv.title.setMaxLines(2);
        mv.title.setEllipsize(TextUtils.TruncateAt.END);
        mv.title.setShadowLayer(dp(4), 0, dp(1), 0x66000000);
        mv.artist = text(curArtist, artistSp, MUTED, false);
        mv.artist.setSingleLine(true);
        mv.artist.setEllipsize(TextUtils.TruncateAt.END);
        musics.add(mv);
        applyMusic(mv);
        return mv;
    }

    private LinearLayout controls(MusicViews mv, int btnDp, int playDp) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        int pad = btnDp / 4;
        mv.prev = button(I_PREV, WHITE, pad);
        mv.prev.setBackground(bgItem());
        mv.prev.setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS));
        row.addView(mv.prev, new LinearLayout.LayoutParams(dp(btnDp), dp(btnDp)));

        mv.play = button(curPlaying ? I_PAUSE : I_PLAY, WHITE, playDp / 4);
        mv.play.setBackground(bgPlay());
        mv.play.setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(dp(playDp), dp(playDp));
        pl.leftMargin = dp(8);
        pl.rightMargin = dp(8);
        row.addView(mv.play, pl);

        mv.next = button(I_NEXT, WHITE, pad);
        mv.next.setBackground(bgItem());
        mv.next.setOnClickListener(v -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT));
        row.addView(mv.next, new LinearLayout.LayoutParams(dp(btnDp), dp(btnDp)));
        return row;
    }

    private LinearLayout weatherBlock(int iconDp, float tempSp, float descSp, boolean withRange) {
        WeatherViews w = new WeatherViews();
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        w.icon = new ImageView(this);
        w.icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        row.addView(w.icon, new LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(WRAP, WRAP);
        cl.leftMargin = dp(10);
        row.addView(col, cl);
        w.temp = text("--°", tempSp, WHITE, true);
        w.temp.setIncludeFontPadding(false);
        col.addView(w.temp);
        w.desc = text("", descSp, MUTED, false);
        w.desc.setSingleLine(true);
        w.desc.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(w.desc);
        if (withRange) {
            w.range = text("", descSp, MUTED, false);
            w.range.setSingleLine(true);
            col.addView(w.range);
        }
        weathers.add(w);
        applyWeather(w);
        return row;
    }

    private void rebuild(boolean reopenSettings) {
        final int keepY = settingsScroll != null ? settingsScroll.getScrollY() : 0;
        setContentView(buildUi());
        refreshSubtitles();
        refreshDock();
        refreshSpeed();
        applySystemUi();
        updateStatus();
        if (reopenSettings) {
            showSettingsNoAnim();
            settingsScroll.post(() -> settingsScroll.scrollTo(0, keepY));
        } else {
            playEnter();
        }
    }

    private void onMusicInfoClick() {
        if (!mediaAccess && legacyTitle == null) {
            openNotificationAccess();
        } else {
            openPreferred(KEY_MUSIC, musicIntent());
        }
    }

    // ------------------------------------------------------------------ foto do carro e papel de parede

    private Bitmap loadWallpaper() {
        java.io.File f = getFileStreamPath(F_WALL);
        int preset = Math.max(0, Math.min(WALL_FILES.length - 1, prefs.getInt(K_WALLPRE, 0)));
        String key = f.exists() ? "file" + f.lastModified() : "asset" + preset;
        if (wallBmp != null && key.equals(wallKey)) return wallBmp;
        Bitmap b = null;
        try {
            if (f.exists()) b = BitmapFactory.decodeFile(f.getPath());
            if (b == null) {
                InputStream in = getAssets().open(WALL_FILES[preset]);
                b = BitmapFactory.decodeStream(in);
                in.close();
                key = "asset" + preset;
            }
        } catch (Exception ignored) {
        }
        wallBmp = b;
        wallKey = key;
        return b;
    }

    private Bitmap assetThumb(String name) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 4;
            InputStream in = getAssets().open(name);
            Bitmap b = BitmapFactory.decodeStream(in, null, o);
            in.close();
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    /** Escolha de papel de parede com miniaturas (incluídos no launcher + galeria). */
    private void showWallpaperPicker() {
        final boolean custom = getFileStreamPath(F_WALL).exists();
        final int cur = prefs.getInt(K_WALLPRE, 0);
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12), dp(8), dp(12), dp(8));
        sv.addView(col, new ScrollView.LayoutParams(MATCH, WRAP));
        final AlertDialog[] dlg = new AlertDialog[1];
        int total = WALL_NAMES.length + 1;
        LinearLayout row = null;
        for (int i = 0; i < total; i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                col.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));
            }
            final int idx = i;
            final boolean gallery = i == WALL_NAMES.length;
            boolean selected = gallery ? custom : (!custom && cur == i);
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER_HORIZONTAL);
            FrameLayout frame = new FrameLayout(this);
            frame.setPadding(dp(3), dp(3), dp(3), dp(3));
            frame.setBackground(shape(0x00000000, 16, selected ? accent : 0x22FFFFFF));
            final int rad = dp(13);
            View thumb;
            if (gallery) {
                ImageView gi = icon(I_IMAGE, WHITE, 26);
                gi.setBackground(shape(0x26FFFFFF, 13, 0));
                thumb = gi;
            } else {
                ImageView iv = new ImageView(this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setImageBitmap(assetThumb(WALL_FILES[i]));
                iv.setOutlineProvider(new ViewOutlineProvider() {
                    @Override
                    public void getOutline(View view, Outline outline) {
                        outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), rad);
                    }
                });
                iv.setClipToOutline(true);
                thumb = iv;
            }
            frame.addView(thumb, new FrameLayout.LayoutParams(MATCH, dp(88)));
            tile.addView(frame, new LinearLayout.LayoutParams(MATCH, WRAP));
            TextView lb = text(gallery ? "Da galeria" : WALL_NAMES[i], 12, selected ? WHITE : MUTED, selected);
            lb.setSingleLine(true);
            lb.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lbLp = new LinearLayout.LayoutParams(MATCH, WRAP);
            lbLp.topMargin = dp(4);
            tile.addView(lb, lbLp);
            tile.setClickable(true);
            tile.setOnClickListener(v -> {
                if (dlg[0] != null) dlg[0].dismiss();
                if (gallery) {
                    pickImage(REQ_WALL);
                } else {
                    prefs.edit().putInt(K_WALLPRE, idx).apply();
                    deleteFile(F_WALL);
                    wallBmp = null;
                    rebuild(true);
                }
            });
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, WRAP, 1f);
            tl.setMargins(dp(5), dp(5), dp(5), dp(9));
            row.addView(tile, tl);
        }
        // completa a última linha para as miniaturas manterem o mesmo tamanho
        int rest = (3 - total % 3) % 3;
        for (int k = 0; k < rest; k++) {
            row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        }
        dlg[0] = new AlertDialog.Builder(this)
                .setTitle("Papel de parede")
                .setView(sv)
                .setNegativeButton("Fechar", null)
                .show();
    }

    private Bitmap loadCar() {
        try {
            java.io.File f = getFileStreamPath(F_CAR);
            if (f.exists()) {
                Bitmap b = BitmapFactory.decodeFile(f.getPath());
                if (b != null) return b;
            }
            InputStream in = getAssets().open("car_hero.png");
            Bitmap b = BitmapFactory.decodeStream(in);
            in.close();
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    private void pickImage(int req) {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, req);
        } catch (Exception e) {
            toast("Nenhum app de galeria ou arquivos encontrado");
        }
    }

    private void imageMenu(String title, final int req, final String file) {
        choose(title, new String[]{"Escolher da galeria", "Usar a imagem padrão"}, -1, i -> {
            if (i == 0) {
                pickImage(req);
            } else {
                deleteFile(file);
                wallBmp = null;
                rebuild(settingsPanel.getVisibility() == View.VISIBLE);
            }
        });
    }

    private Bitmap decodeUri(Uri u, int maxPx) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = getContentResolver().openInputStream(u);
            if (in == null) return null;
            BitmapFactory.decodeStream(in, null, o);
            in.close();
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= maxPx) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            in = getContentResolver().openInputStream(u);
            if (in == null) return null;
            Bitmap b = BitmapFactory.decodeStream(in, null, o2);
            in.close();
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    private void saveImage(final Uri uri, final String file, final int maxPx, final boolean png) {
        toast("Carregando imagem...");
        new Thread(() -> {
            boolean ok = false;
            Bitmap b = decodeUri(uri, maxPx);
            if (b != null) {
                try {
                    FileOutputStream out = openFileOutput(file, MODE_PRIVATE);
                    b.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, 90, out);
                    out.close();
                    ok = true;
                } catch (Exception ignored) {
                }
            }
            final boolean done = ok;
            runOnUiThread(() -> {
                if (done) {
                    wallBmp = null;
                    rebuild(true);
                } else {
                    toast("Não foi possível usar essa imagem");
                }
            });
        }).start();
    }

    /** Foto do carro com brilho da cor de destaque e reflexo opcional no chão. */
    private static class CarView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private Bitmap car, cache;
        private int accentColor;
        private boolean reflect;
        private float sport = 0f;
        private float carScale = 1f, carDx = 0f, carDy = 0f;
        private boolean editing = false;
        private float lastX, lastY;
        private final ScaleGestureDetector sgd;
        private Runnable onDone;
        private Bitmap scene;
        private float intro = 1f;
        private float hueDeg = 0f, satBase = 1f, lightBase = 1f;

        void setScene(Bitmap b, int accent) {
            scene = b;
            car = null;
            cache = null;
            accentColor = accent;
            float[] hsv = new float[3];
            Color.colorToHSV(accent, hsv);
            hueDeg = hsv[0] - 358f;
            if (hsv[1] < 0.25f) {
                satBase = 0.05f;
                lightBase = 1.18f;
            } else {
                satBase = 1f;
                lightBase = 1f;
            }
            invalidate();
        }

        void startIntro(int ms) {
            if (scene == null) return;
            ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
            a.setDuration(ms);
            a.setInterpolator(new DecelerateInterpolator(1.4f));
            a.addUpdateListener(an -> {
                intro = (Float) an.getAnimatedValue();
                invalidate();
            });
            intro = 0f;
            invalidate();
            a.start();
        }

        private ColorMatrix sceneMatrix(float sat, float light) {
            ColorMatrix cm = new ColorMatrix();
            cm.setSaturation(sat);
            double r = Math.toRadians(hueDeg);
            float cs = (float) Math.cos(r), sn = (float) Math.sin(r);
            float lr = 0.213f, lg = 0.715f, lb = 0.072f;
            ColorMatrix hm = new ColorMatrix(new float[]{
                    lr + cs * (1 - lr) + sn * (-lr), lg + cs * (-lg) + sn * (-lg), lb + cs * (-lb) + sn * (1 - lb), 0, 0,
                    lr + cs * (-lr) + sn * 0.143f, lg + cs * (1 - lg) + sn * 0.140f, lb + cs * (-lb) + sn * (-0.283f), 0, 0,
                    lr + cs * (-lr) + sn * (-(1 - lr)), lg + cs * (-lg) + sn * lg, lb + cs * (1 - lb) + sn * lb, 0, 0,
                    0, 0, 0, 1, 0});
            cm.postConcat(hm);
            ColorMatrix sm = new ColorMatrix(new float[]{
                    light, 0, 0, 0, 0, 0, light, 0, 0, 0, 0, 0, light, 0, 0, 0, 0, 0, 1, 0});
            cm.postConcat(sm);
            return cm;
        }

        private void drawScene(Canvas c, int w, int h) {
            float d = getResources().getDisplayMetrics().density;
            float rad = 28f * d;
            RectF full = new RectF(0, 0, w, h);
            Path clip = new Path();
            clip.addRoundRect(full, rad, rad, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            p.setShader(null);
            p.setColor(0xFF030304);
            c.drawRect(full, p);
            float ease = intro * intro * (3 - 2 * intro);
            float s = (w / (float) scene.getWidth()) * 1.22f * Math.max(0.4f, carScale) * (1f + 0.18f * (1f - ease));
            float dw = scene.getWidth() * s, dh = scene.getHeight() * s;
            float left = (w - dw) / 2f + carDx * w - (1f - ease) * w * 0.05f;
            float top = h * 0.52f - dh / 2f + carDy * h;
            float sat = satBase * (0.25f + 0.75f * ease) * (1f + 0.3f * sport);
            float light = lightBase * (0.3f + 0.7f * ease) * (1f + 0.12f * sport);
            Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            bp.setColorFilter(new ColorMatrixColorFilter(sceneMatrix(sat, light)));
            int layer = c.saveLayer(0, 0, w, h, null);
            c.drawBitmap(scene, null, new RectF(left, top, left + dw, top + dh), bp);
            Paint m = new Paint();
            m.setShader(new LinearGradient(0, top, 0, top + dh,
                    new int[]{0x00000000, 0xFF000000, 0xFF000000, 0x00000000},
                    new float[]{0f, 0.2f, 0.82f, 1f}, Shader.TileMode.CLAMP));
            m.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            c.drawRect(0, 0, w, h, m);
            c.restoreToCount(layer);
            if (intro < 1f) {
                float cx = -w * 0.3f + w * 1.6f * ease;
                int base = accentColor & 0x00FFFFFF;
                int a = (int) (0x70 * Math.sin(Math.PI * Math.min(1f, intro)));
                Paint sw = new Paint();
                sw.setShader(new LinearGradient(cx - w * 0.25f, 0, cx + w * 0.25f, h * 0.3f,
                        new int[]{base, (a << 24) | 0x00FFFFFF, base}, null, Shader.TileMode.CLAMP));
                c.drawRect(0, 0, w, h, sw);
            }
            c.restore();
            Paint st = new Paint(Paint.ANTI_ALIAS_FLAG);
            st.setStyle(Paint.Style.STROKE);
            st.setStrokeWidth(Math.max(1f, d));
            st.setColor(0x44FFFFFF);
            c.drawRoundRect(new RectF(0.5f, 0.5f, w - 0.5f, h - 0.5f), rad, rad, st);
        }

        CarView(Context c) {
            super(c);
            sgd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector d) {
                    carScale = Math.max(0.4f, Math.min(2.6f, carScale * d.getScaleFactor()));
                    invalidate();
                    return true;
                }
            });
        }

        void setTransform(float sc, float dx, float dy) {
            carScale = sc;
            carDx = dx;
            carDy = dy;
            cache = null;
            invalidate();
        }

        float getScaleV() {
            return carScale;
        }

        float getDx() {
            return carDx;
        }

        float getDy() {
            return carDy;
        }

        void setEditing(boolean e, Runnable done) {
            editing = e;
            onDone = done;
            cache = null;
            invalidate();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (!editing) return super.onTouchEvent(e);
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            sgd.onTouchEvent(e);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = e.getX();
                    lastY = e.getY();
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (!sgd.isInProgress() && e.getPointerCount() == 1) {
                        carDx += (e.getX() - lastX) / Math.max(1, getWidth());
                        carDy += (e.getY() - lastY) / Math.max(1, getHeight());
                        invalidate();
                    }
                    lastX = e.getX();
                    lastY = e.getY();
                    break;
                case MotionEvent.ACTION_POINTER_UP: {
                    int idx = e.getActionIndex() == 0 ? 1 : 0;
                    lastX = e.getX(idx);
                    lastY = e.getY(idx);
                    break;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (onDone != null) onDone.run();
                    break;
                default:
                    break;
            }
            return true;
        }

        void setSportNow(float v) {
            sport = v;
            invalidate();
        }

        void animateSport(float to, int ms) {
            ValueAnimator a = ValueAnimator.ofFloat(sport, to);
            a.setDuration(ms);
            a.addUpdateListener(an -> {
                sport = (Float) an.getAnimatedValue();
                invalidate();
            });
            a.start();
        }

        void set(Bitmap b, int accentColor, boolean reflect) {
            this.car = b;
            this.scene = null;
            this.accentColor = accentColor;
            this.reflect = reflect;
            this.cache = null;
            invalidate();
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            cache = null;
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            if (scene != null) {
                drawScene(c, w, h);
                return;
            }
            int base = accentColor & 0x00FFFFFF;
            int ga = (int) (0x4D + 0x66 * sport);
            p.setShader(new RadialGradient(w / 2f, h * 0.55f, Math.max(w, h) * (0.55f + 0.15f * sport),
                    (ga << 24) | base, base, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            if (car == null) return;
            if (editing) {
                renderTo(c, w, h);
                return;
            }
            if (cache == null) cache = render(w, h);
            c.drawBitmap(cache, 0, 0, null);
        }

        private Bitmap render(int w, int h) {
            Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            renderTo(new Canvas(out), w, h);
            return out;
        }

        private void renderTo(Canvas c, int w, int h) {
            float maxW = w * 0.98f;
            float maxH = h * (reflect ? 0.66f : 0.94f);
            float s = Math.min(maxW / car.getWidth(), maxH / car.getHeight());
            float cw0 = car.getWidth() * s, ch0 = car.getHeight() * s;
            float cx = w / 2f;
            float cy = (reflect ? h * 0.04f : (h - ch0) / 2f) + ch0 / 2f;
            float cw = cw0 * carScale, ch = ch0 * carScale;
            float left = cx - cw / 2f + carDx * w;
            float top = cy - ch / 2f + carDy * h;
            float base = top + ch;
            RectF dst = new RectF(left, top, left + cw, base);
            Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            float r = getResources().getDisplayMetrics().density * 28f;
            Path clip = new Path();
            clip.addRoundRect(dst, r, r, Path.Direction.CW);
            boolean opaque = !car.hasAlpha();

            if (reflect) {
                float refH = Math.min(ch * 0.45f, h - base);
                if (refH > 2) {
                    int sc = c.saveLayer(0, base, w, base + refH, null);
                    c.save();
                    c.clipRect(left, base, left + cw, base + refH);
                    c.scale(1f, -1f, 0f, base);
                    c.drawBitmap(car, null, dst, bp);
                    c.restore();
                    Paint m = new Paint();
                    m.setShader(new LinearGradient(0, base, 0, base + refH, 0x59FFFFFF, 0x00FFFFFF,
                            Shader.TileMode.CLAMP));
                    m.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
                    c.drawRect(0, base, w, base + refH, m);
                    c.restoreToCount(sc);
                }
            }
            if (opaque) {
                c.save();
                c.clipPath(clip);
            }
            c.drawBitmap(car, null, dst, bp);
            if (opaque) c.restore();
        }
    }

    // ------------------------------------------------------------------ ícones desenhados em código

    /** Ícones desenhados em grade 24x24, sem arquivos de imagem. */
    private static class IconDrawable extends Drawable {
        private final int type;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        private final boolean multi;

        IconDrawable(int type, int color) {
            this(type, color, false);
        }

        IconDrawable(int type, int color, boolean multi) {
            this.type = type;
            this.multi = multi;
            p.setColor(color);
        }

        private void col(int c) {
            if (multi) p.setColor(c);
        }

        private void cloud(Canvas c, float dx, float dy) {
            c.drawCircle(8.5f + dx, 15f + dy, 4f, p);
            c.drawCircle(13.5f + dx, 12f + dy, 5f, p);
            c.drawCircle(18f + dx, 15.5f + dy, 3.5f, p);
            c.drawRect(8.5f + dx, 15f + dy, 18f + dx, 19f + dy, p);
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            float s = Math.min(b.width(), b.height()) / 24f;
            if (s <= 0) return;
            c.save();
            c.translate(b.left + (b.width() - 24 * s) / 2f, b.top + (b.height() - 24 * s) / 2f);
            c.scale(s, s);
            p.setStyle(Paint.Style.FILL);
            path.reset();
            switch (type) {
                case I_APPS:
                    for (int r = 0; r < 3; r++) {
                        for (int k = 0; k < 3; k++) {
                            c.drawRect(4 + k * 6, 4 + r * 6, 8 + k * 6, 8 + r * 6, p);
                        }
                    }
                    break;
                case I_NAV:
                    path.moveTo(12, 2);
                    path.lineTo(4.5f, 20.3f);
                    path.lineTo(12, 17f);
                    path.lineTo(19.5f, 20.3f);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case I_MUSIC:
                    c.drawCircle(9, 18, 3.6f, p);
                    c.drawRect(11.6f, 4, 14, 18, p);
                    path.moveTo(14, 4);
                    path.lineTo(20, 6.5f);
                    path.lineTo(20, 10);
                    path.lineTo(14, 7.5f);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case I_PHONE:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.6f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    path.moveTo(6, 6);
                    path.quadTo(6, 18, 18, 18);
                    c.drawPath(path, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(6, 6, 3.2f, p);
                    c.drawCircle(18, 18, 3.2f, p);
                    break;
                case I_TUNE: {
                    float[] ys = {6, 12, 18};
                    float[] ks = {15, 8, 16};
                    for (int i = 0; i < 3; i++) {
                        c.drawRect(3, ys[i] - 1, 21, ys[i] + 1, p);
                        c.drawCircle(ks[i], ys[i], 3, p);
                    }
                    break;
                }
                case I_PLAY:
                    path.moveTo(8, 5);
                    path.lineTo(8, 19);
                    path.lineTo(19, 12);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case I_PAUSE:
                    c.drawRect(6, 5, 10, 19, p);
                    c.drawRect(14, 5, 18, 19, p);
                    break;
                case I_PREV:
                    c.drawRect(6, 6, 8, 18, p);
                    path.moveTo(18, 6);
                    path.lineTo(18, 18);
                    path.lineTo(9.5f, 12);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case I_NEXT:
                    c.drawRect(16, 6, 18, 18, p);
                    path.moveTo(6, 6);
                    path.lineTo(6, 18);
                    path.lineTo(14.5f, 12);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case I_CLOSE:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.4f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    c.drawLine(6, 6, 18, 18, p);
                    c.drawLine(18, 6, 6, 18, p);
                    break;
                case I_GEAR:
                    for (int k = 0; k < 8; k++) {
                        c.save();
                        c.rotate(k * 45f, 12, 12);
                        c.drawRect(10.6f, 1.6f, 13.4f, 6f, p);
                        c.restore();
                    }
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(3f);
                    c.drawCircle(12, 12, 5.6f, p);
                    break;
                case I_IMAGE:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2f);
                    c.drawRoundRect(new RectF(3.5f, 5, 20.5f, 19), 3, 3, p);
                    p.setStyle(Paint.Style.FILL);
                    path.moveTo(5.5f, 17f);
                    path.lineTo(10f, 11.5f);
                    path.lineTo(13f, 15f);
                    path.lineTo(15f, 12.8f);
                    path.lineTo(18.5f, 17f);
                    path.close();
                    c.drawPath(path, p);
                    c.drawCircle(16.2f, 9f, 1.6f, p);
                    break;
                case I_SUN:
                    col(0xFFFFC233);
                    sun(c, 12, 12, 4.6f, true);
                    break;
                case I_PARTLY:
                    col(0xFFFFC233);
                    sun(c, 8f, 8f, 3.2f, false);
                    col(0xFFF1F5FB);
                    cloud(c, 1.5f, 1.5f);
                    break;
                case I_CLOUD:
                    col(0xFFE6ECF5);
                    cloud(c, 0, 0);
                    break;
                case I_RAIN:
                    col(0xFFC3CEDF);
                    cloud(c, 0, -3f);
                    col(0xFF4DA3FF);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(1.8f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    c.drawLine(9, 18, 8, 21.5f, p);
                    c.drawLine(13.5f, 18, 12.5f, 21.5f, p);
                    c.drawLine(18, 18, 17, 21.5f, p);
                    break;
                case I_STORM:
                    col(0xFFA9B6CC);
                    cloud(c, 0, -3f);
                    col(0xFFFFD43B);
                    path.moveTo(13.6f, 15.6f);
                    path.lineTo(10f, 20.8f);
                    path.lineTo(12.6f, 20.8f);
                    path.lineTo(11.4f, 24f);
                    path.lineTo(16.2f, 18.6f);
                    path.lineTo(13.4f, 18.6f);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case I_WIFI:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.2f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    c.drawArc(new RectF(12 - 4, 19 - 4, 12 + 4, 19 + 4), 225, 90, false, p);
                    c.drawArc(new RectF(12 - 8, 19 - 8, 12 + 8, 19 + 8), 225, 90, false, p);
                    c.drawArc(new RectF(12 - 12, 19 - 12, 12 + 12, 19 + 12), 225, 90, false, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(12, 19, 1.7f, p);
                    break;
                case I_BT:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.2f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setStrokeJoin(Paint.Join.ROUND);
                    path.moveTo(7, 7.5f);
                    path.lineTo(17, 16.5f);
                    path.lineTo(12, 21.5f);
                    path.lineTo(12, 2.5f);
                    path.lineTo(17, 7.5f);
                    path.lineTo(7, 16.5f);
                    c.drawPath(path, p);
                    break;
                case I_GPS:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.2f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    c.drawCircle(12, 12, 6f, p);
                    c.drawLine(12, 2, 12, 5.5f, p);
                    c.drawLine(12, 18.5f, 12, 22, p);
                    c.drawLine(2, 12, 5.5f, 12, p);
                    c.drawLine(18.5f, 12, 22, 12, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(12, 12, 2.4f, p);
                    break;
                case I_SPEED:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.1f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    c.drawArc(new RectF(3f, 3.5f, 21f, 21.5f), 150, 240, false, p);
                    c.drawLine(12f, 12.5f, 16.5f, 8f, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(12f, 12.5f, 1.8f, p);
                    break;
                case I_RPM:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.1f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    c.drawCircle(12f, 12f, 9f, p);
                    c.drawLine(12f, 4.5f, 12f, 6.5f, p);
                    c.drawLine(5f, 12f, 7f, 12f, p);
                    c.drawLine(19f, 12f, 17f, 12f, p);
                    c.drawLine(12f, 12f, 8.6f, 8.6f, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(12f, 12f, 1.6f, p);
                    break;
                case I_COIN:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.0f);
                    c.drawCircle(12f, 12f, 9f, p);
                    p.setStyle(Paint.Style.FILL);
                    p.setTextAlign(Paint.Align.CENTER);
                    p.setTextSize(12.5f);
                    p.setFakeBoldText(true);
                    c.drawText("$", 12f, 16.4f, p);
                    p.setTextAlign(Paint.Align.LEFT);
                    p.setFakeBoldText(false);
                    break;
                case I_FUEL:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.1f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setStrokeJoin(Paint.Join.ROUND);
                    c.drawRoundRect(new RectF(4.5f, 3.5f, 14.5f, 20.5f), 1.8f, 1.8f, p);
                    c.drawLine(4.5f, 10f, 14.5f, 10f, p);
                    c.drawLine(3f, 20.5f, 16f, 20.5f, p);
                    path.moveTo(14.5f, 8f);
                    path.lineTo(17.5f, 8f);
                    path.lineTo(19.5f, 10f);
                    path.lineTo(19.5f, 16.5f);
                    c.drawPath(path, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(19.5f, 17.5f, 1.4f, p);
                    break;
                case I_TEMP:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.1f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    c.drawRoundRect(new RectF(9.5f, 2.8f, 14.5f, 15.5f), 2.5f, 2.5f, p);
                    c.drawLine(12f, 8f, 12f, 16f, p);
                    c.drawLine(16.8f, 6f, 19.5f, 6f, p);
                    c.drawLine(16.8f, 9.5f, 19.5f, 9.5f, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(12f, 17.8f, 3.6f, p);
                    break;
                case I_RESTART:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.4f);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    c.drawArc(new RectF(5, 5, 19, 19), -60, 300, false, p);
                    p.setStyle(Paint.Style.FILL);
                    path.moveTo(11.6f, 3.6f);
                    path.lineTo(7.0f, 3.2f);
                    path.lineTo(9.6f, 8.2f);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case I_CARPLAY:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.1f);
                    c.drawRoundRect(new RectF(3, 3, 21, 21), 4.5f, 4.5f, p);
                    p.setStyle(Paint.Style.FILL);
                    path.moveTo(8.3f, 12.6f);
                    path.lineTo(10f, 9.3f);
                    path.lineTo(14f, 9.3f);
                    path.lineTo(15.7f, 12.6f);
                    path.close();
                    c.drawPath(path, p);
                    c.drawRoundRect(new RectF(6.8f, 12.2f, 17.2f, 15.6f), 1.2f, 1.2f, p);
                    c.drawCircle(9.4f, 16f, 1.5f, p);
                    c.drawCircle(14.6f, 16f, 1.5f, p);
                    break;
                default:
                    break;
            }
            c.restore();
        }

        private void sun(Canvas c, float cx, float cy, float r, boolean rays) {
            c.drawCircle(cx, cy, r, p);
            if (!rays) return;
            Paint.Style old = p.getStyle();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.9f);
            p.setStrokeCap(Paint.Cap.ROUND);
            for (int k = 0; k < 8; k++) {
                c.save();
                c.rotate(k * 45f, cx, cy);
                c.drawLine(cx, cy - r - 2.4f, cx, cy - r - 4.6f, p);
                c.restore();
            }
            p.setStyle(old);
        }

        @Override
        public void setAlpha(int alpha) {
            p.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(ColorFilter colorFilter) {
            p.setColorFilter(colorFilter);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }

    // ------------------------------------------------------------------ apps

    private void loadApps() {
        new Thread(() -> {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
            final List<AppItem> out = new ArrayList<>();
            for (ResolveInfo ri : list) {
                if (ri.activityInfo.packageName.equals(getPackageName())) continue;
                AppItem a = new AppItem();
                a.pkg = ri.activityInfo.packageName;
                a.cn = new ComponentName(a.pkg, ri.activityInfo.name);
                a.label = String.valueOf(ri.loadLabel(pm));
                out.add(a);
            }
            Collections.sort(out, (x, y) -> x.label.compareToIgnoreCase(y.label));
            runOnUiThread(() -> {
                apps.clear();
                apps.addAll(out);
                adapter.notifyDataSetChanged();
                ensureDefaultDock();
                refreshDock();
                refreshSubtitles();
            });
        }).start();
    }

    private AppItem findApp(String pkg) {
        for (AppItem a : apps) {
            if (a.pkg.equals(pkg)) return a;
        }
        return null;
    }

    private Drawable getIcon(AppItem a) {
        String key = a.cn.flattenToString();
        Drawable d = iconCache.get(key);
        if (d == null) {
            try {
                d = pm.getActivityIcon(a.cn);
            } catch (PackageManager.NameNotFoundException e) {
                d = pm.getDefaultActivityIcon();
            }
            iconCache.put(key, d);
        }
        return d;
    }

    private void launch(AppItem a) {
        Intent i = new Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(a.cn)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        startSafe(i);
    }

    private boolean launchPkg(String pkg) {
        Intent i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) return false;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void startSafe(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("Não foi possível abrir");
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ cartões

    private Intent navIntent() {
        return Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MAPS);
    }

    private Intent musicIntent() {
        return Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC);
    }

    private void openPreferred(String key, Intent fallback) {
        String pkg = prefs.getString(key, null);
        if (pkg != null && launchPkg(pkg)) return;
        try {
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(fallback);
        } catch (Exception e) {
            toast("Nenhum app encontrado. Segure o cartão para escolher um.");
        }
    }

    private String subtitle(String key) {
        String pkg = prefs.getString(key, null);
        if (pkg == null) return DEFAULT_LABEL;
        AppItem a = findApp(pkg);
        return a != null ? a.label : DEFAULT_LABEL;
    }

    private void refreshCarplayIcon() {
        if (cpIcon == null) return;
        Drawable d = null;
        int mode = prefs.getInt(K_CPICON, 0);
        if (mode == 2) {
            File f = getFileStreamPath(F_CPICON);
            if (f.exists()) {
                Bitmap b = BitmapFactory.decodeFile(f.getPath());
                if (b != null) d = new BitmapDrawable(getResources(), b);
            }
        }
        if (d == null && mode != 1) {
            String pkg = prefs.getString(KEY_CARPLAY, null);
            AppItem a = pkg != null ? findApp(pkg) : findCarplayApp();
            if (a != null) d = getIcon(a);
        }
        if (d != null) {
            cpIcon.setClipToOutline(true);
            cpIcon.setImageDrawable(d);
        } else {
            cpIcon.setClipToOutline(false);
            cpIcon.setImageDrawable(new IconDrawable(I_CARPLAY, accent));
        }
    }

    private void refreshSubtitles() {
        refreshCarplayIcon();
        if (navSub != null) navSub.setText(subtitle(KEY_NAV));
        if (phoneSub != null) phoneSub.setText(subtitle(KEY_PHONE));
        lastPhoneSub = null;
        refreshPhoneSub();
        if (settingsSub != null) settingsSub.setText(subtitle(KEY_SETTINGS));
    }

    private void showAppPicker(final String key, String title) {
        final List<AppItem> snapshot = new ArrayList<>(apps);
        CharSequence[] names = new CharSequence[snapshot.size() + 1];
        names[0] = DEFAULT_LABEL;
        for (int i = 0; i < snapshot.size(); i++) names[i + 1] = snapshot.get(i).label;
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(names, (d, which) -> {
                    if (which == 0) {
                        prefs.edit().remove(key).apply();
                    } else {
                        prefs.edit().putString(key, snapshot.get(which - 1).pkg).apply();
                    }
                    refreshSubtitles();
                })
                .show();
    }

    private void showAppMenu(final AppItem a) {
        final boolean pinned = getDock().contains(a.pkg);
        final String[] items = {
                pinned ? "Remover do dock" : "Fixar no dock",
                "Usar como Navegação",
                "Usar como Música",
                "Usar como Telefone",
                "Usar como Ajustes",
                "Informações do app",
                "Desinstalar"
        };
        new AlertDialog.Builder(this)
                .setTitle(a.label)
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0:
                            togglePin(a.pkg);
                            break;
                        case 1:
                            setPref(KEY_NAV, a.pkg);
                            break;
                        case 2:
                            setPref(KEY_MUSIC, a.pkg);
                            break;
                        case 3:
                            setPref(KEY_PHONE, a.pkg);
                            break;
                        case 4:
                            setPref(KEY_SETTINGS, a.pkg);
                            break;
                        case 5:
                            startSafe(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:" + a.pkg)));
                            break;
                        case 6:
                            startSafe(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)));
                            break;
                        default:
                            break;
                    }
                })
                .show();
    }

    private void setPref(String key, String pkg) {
        prefs.edit().putString(key, pkg).apply();
        refreshSubtitles();
    }

    // ------------------------------------------------------------------ dock

    private List<String> getDock() {
        String s = prefs.getString(KEY_DOCK, "");
        List<String> out = new ArrayList<>();
        if (s != null && s.length() > 0) {
            for (String p : s.split(",")) {
                if (p.length() > 0) out.add(p);
            }
        }
        return out;
    }

    private void saveDock(List<String> list) {
        prefs.edit().putString(KEY_DOCK, TextUtils.join(",", list)).apply();
        refreshDock();
    }

    private void togglePin(String pkg) {
        List<String> dock = getDock();
        if (dock.contains(pkg)) {
            dock.remove(pkg);
        } else {
            if (dock.size() >= MAX_DOCK) {
                toast("Dock cheia (máximo " + MAX_DOCK + ")");
                return;
            }
            dock.add(pkg);
        }
        saveDock(dock);
    }

    private void ensureDefaultDock() {
        if (prefs.contains(KEY_DOCK)) return;
        String[] candidates = {
                "com.waze",
                "com.google.android.apps.maps",
                "com.spotify.music",
                "com.google.android.apps.youtube.music",
                "com.google.android.youtube",
                "com.android.chrome"
        };
        List<String> d = new ArrayList<>();
        for (String c : candidates) {
            if (d.size() < MAX_DOCK && findApp(c) != null) d.add(c);
        }
        prefs.edit().putString(KEY_DOCK, TextUtils.join(",", d)).apply();
    }

    private void refreshDock() {
        if (dockApps == null) return;
        dockApps.removeAllViews();
        for (String pkg : getDock()) {
            final AppItem a = findApp(pkg);
            if (a == null) continue;
            ImageView iv = new ImageView(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(58), dp(58));
            lp.setMargins(0, dp(4), 0, dp(4));
            iv.setLayoutParams(lp);
            iv.setPadding(dp(7), dp(7), dp(7), dp(7));
            iv.setBackground(bgItem());
            iv.setImageDrawable(getIcon(a));
            iv.setContentDescription(a.label);
            pressable(iv);
            iv.setOnClickListener(v -> launch(a));
            iv.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this)
                        .setTitle(a.label)
                        .setItems(new String[]{"Remover do dock"}, (d, which) -> togglePin(a.pkg))
                        .show();
                return true;
            });
            dockApps.addView(iv);
        }
    }

    // ------------------------------------------------------------------ gaveta de apps

    private void showDrawer() {
        popIn(drawer);
    }

    private void hideDrawer() {
        popOut(drawer);
    }

    private void popIn(View v) {
        v.animate().cancel();
        v.setAlpha(0f);
        v.setScaleX(0.93f);
        v.setScaleY(0.93f);
        v.setTranslationY(dp(32));
        v.setVisibility(View.VISIBLE);
        v.animate().setStartDelay(0).alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(dur(420)).setInterpolator(new DecelerateInterpolator(2.2f)).start();
    }

    private void popOut(final View v) {
        if (v.getVisibility() != View.VISIBLE) return;
        v.animate().cancel();
        v.animate().setStartDelay(0).alpha(0f).scaleX(0.96f).scaleY(0.96f).translationY(dp(18))
                .setDuration(dur(240)).setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> v.setVisibility(View.GONE)).start();
    }

    private class AppAdapter extends BaseAdapter {
        private final int size;

        AppAdapter(int size) {
            this.size = size;
        }

        @Override
        public int getCount() {
            return apps.size();
        }

        @Override
        public Object getItem(int position) {
            return apps.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Holder h;
            if (convertView == null) {
                LinearLayout row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setGravity(Gravity.CENTER_HORIZONTAL);
                row.setPadding(dp(4), dp(10), dp(4), dp(10));
                row.setBackground(bgItem());
                pressable(row);

                ImageView iv = new ImageView(MainActivity.this);
                row.addView(iv, new LinearLayout.LayoutParams(dp(ICON_DP[size]), dp(ICON_DP[size])));

                TextView tv = text("", LABEL_SP[size], 0xFFE6EDF5, false);
                tv.setSingleLine(true);
                tv.setEllipsize(TextUtils.TruncateAt.END);
                tv.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(MATCH, WRAP);
                tlp.topMargin = dp(6);
                row.addView(tv, tlp);

                h = new Holder();
                h.icon = iv;
                h.label = tv;
                row.setTag(h);
                convertView = row;
            } else {
                h = (Holder) convertView.getTag();
            }
            AppItem a = apps.get(position);
            h.icon.setImageDrawable(getIcon(a));
            h.label.setText(a.label);
            return convertView;
        }
    }

    private static class Holder {
        ImageView icon;
        TextView label;
    }

    // ------------------------------------------------------------------ ajustes do launcher

    private interface RowAction {
        void run();
    }

    private void showSettings() {
        fillSettings();
        popIn(settingsPanel);
    }

    private void showSettingsNoAnim() {
        fillSettings();
        settingsPanel.animate().cancel();
        settingsPanel.setAlpha(1f);
        settingsPanel.setScaleX(1f);
        settingsPanel.setScaleY(1f);
        settingsPanel.setTranslationY(0f);
        settingsPanel.setVisibility(View.VISIBLE);
    }

    private void hideSettings() {
        popOut(settingsPanel);
    }

    private LinearLayout newGroup(String label) {
        if (label != null && catOf(label) != settingsTab) return new LinearLayout(this);
        if (label != null) {
            TextView t = text(label.toUpperCase(), 12, MUTED, true);
            t.setLetterSpacing(0.14f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.setMargins(dp(8), dp(settingsRows.getChildCount() == 0 ? 6 : 22), 0, dp(8));
            settingsRows.addView(t, lp);
        }
        LinearLayout g = new LinearLayout(this);
        g.setOrientation(LinearLayout.VERTICAL);
        g.setBackground(shape(0x14FFFFFF, 22, 0x1FFFFFFF));
        settingsRows.addView(g, new LinearLayout.LayoutParams(MATCH, WRAP));
        return g;
    }

    private View makeSwitch(boolean on) {
        FrameLayout sw = new FrameLayout(this);
        sw.setBackground(shape(on ? accent : 0x40FFFFFF, 100, 0));
        View knob = new View(this);
        GradientDrawable kd = new GradientDrawable();
        kd.setShape(GradientDrawable.OVAL);
        kd.setColor(on ? onAccent() : 0xFFFFFFFF);
        knob.setBackground(kd);
        FrameLayout.LayoutParams kl = new FrameLayout.LayoutParams(dp(24), dp(24),
                Gravity.CENTER_VERTICAL | (on ? Gravity.RIGHT : Gravity.LEFT));
        kl.setMargins(dp(3), 0, dp(3), 0);
        sw.addView(knob, kl);
        sw.setLayoutParams(new LinearLayout.LayoutParams(dp(52), dp(30)));
        return sw;
    }

    private View valueTrailing(String value, boolean chevron, int color, int dotColor) {
        LinearLayout t = new LinearLayout(this);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (dotColor != 0) {
            View dot = new View(this);
            GradientDrawable dd = new GradientDrawable();
            dd.setShape(GradientDrawable.OVAL);
            dd.setColor(dotColor);
            dot.setBackground(dd);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(14), dp(14));
            dl.rightMargin = dp(8);
            t.addView(dot, dl);
        }
        TextView v = text(value, 15, color, true);
        v.setSingleLine(true);
        v.setEllipsize(TextUtils.TruncateAt.END);
        v.setMaxWidth(dp(260));
        t.addView(v);
        if (chevron) {
            TextView ch = text("›", 26, MUTED, false);
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(WRAP, WRAP);
            cl.leftMargin = dp(8);
            t.addView(ch, cl);
        }
        return t;
    }

    private void addItem(LinearLayout g, int ic, int tint, String title, String sub, View trailing,
                         final RowAction action) {
        if (g.getChildCount() > 0) {
            View d = new View(this);
            d.setBackgroundColor(0x14FFFFFF);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(MATCH, dp(1));
            dl.leftMargin = dp(68);
            g.addView(d, dl);
        }
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(dp(62));
        row.setPadding(dp(14), dp(8), dp(16), dp(8));
        if (action != null) {
            row.setClickable(true);
            row.setBackground(states(shape(0x26FFFFFF, 18, 0), shape(0x00000000, 18, 0)));
            row.setOnClickListener(x -> action.run());
        }
        FrameLayout badge = new FrameLayout(this);
        badge.setBackground(shape((tint & 0x00FFFFFF) | 0x2E000000, 11, 0));
        badge.addView(icon(ic, tint, 8), new FrameLayout.LayoutParams(MATCH, MATCH));
        row.addView(badge, new LinearLayout.LayoutParams(dp(38), dp(38)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(title, 17, tint == 0xFFFF5A5F ? tint : WHITE, false));
        if (sub != null && sub.length() > 0) {
            TextView st = text(sub, 12, MUTED, false);
            col.addView(st);
        }
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, WRAP, 1f);
        cl.leftMargin = dp(14);
        cl.rightMargin = dp(10);
        row.addView(col, cl);
        if (trailing != null) row.addView(trailing);
        g.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));
    }

    private void rowChoice(LinearLayout g, int ic, String title, String value, RowAction a) {
        addItem(g, ic, accent, title, null, valueTrailing(value, true, accent, 0), a);
    }

    private void rowToggle(LinearLayout g, int ic, String title, String sub, boolean on, RowAction a) {
        addItem(g, ic, accent, title, sub, makeSwitch(on), a);
    }

    private void rowInfo(LinearLayout g, int ic, String title, String sub, String value) {
        addItem(g, ic, accent, title, sub, valueTrailing(value, false, MUTED, 0), null);
    }

    private void choose(String title, String[] opts, int cur, final IntCb cb) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(opts, cur, (d, which) -> {
                    d.dismiss();
                    cb.run(which);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void putInt(String key, int v) {
        prefs.edit().putInt(key, v).apply();
        rebuild(true);
    }

    private void putBool(String key, boolean v) {
        prefs.edit().putBoolean(key, v).apply();
        rebuild(true);
    }

    private void fillSettings() {
        settingsRows.removeAllViews();
        settingsSide.removeAllViews();

        // categorias (barra lateral)
        for (int t = -1; t < TAB_NAMES.length; t++) {
            final int ti = t;
            boolean sel = t == settingsTab;
            LinearLayout it = new LinearLayout(this);
            it.setGravity(Gravity.CENTER_VERTICAL);
            it.setPadding(dp(14), dp(13), dp(12), dp(13));
            it.setBackground(sel ? shape((accent & 0x00FFFFFF) | 0x38000000, 18, 0)
                    : states(shape(0x1FFFFFFF, 18, 0), shape(0x00000000, 18, 0)));
            it.addView(icon(t < 0 ? I_APPS : TAB_ICONS[t], sel ? accent : 0xCCFFFFFF, 0), new LinearLayout.LayoutParams(dp(22), dp(22)));
            TextView tv = text(t < 0 ? "Início" : TAB_NAMES[t], 16, sel ? WHITE : 0xCCFFFFFF, sel);
            tv.setSingleLine(true);
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(WRAP, WRAP);
            tl.leftMargin = dp(12);
            it.addView(tv, tl);
            it.setClickable(true);
            it.setOnClickListener(v -> {
                settingsTab = ti;
                fillSettings();
                settingsScroll.scrollTo(0, 0);
            });
            LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(MATCH, WRAP);
            il.bottomMargin = dp(6);
            settingsSide.addView(it, il);
        }

        final int ai = Math.max(0, Math.min(ACCENTS.length - 1, prefs.getInt(K_ACCENT, 0)));
        final int mi = prefs.getInt(K_MODE, 0);
        final int si = prefs.getInt(K_STYLE, 0);
        final int bi = Math.max(0, Math.min(BG_NAMES.length - 1, prefs.getInt(K_BG, 2)));
        final boolean c24 = prefs.getBoolean(K_CLOCK24, true);
        final int zi = Math.max(0, Math.min(2, prefs.getInt(K_ICON, 1)));
        final boolean refl = prefs.getBoolean(K_REFLECT, false);
        final String carName = prefs.getString(K_CAR_NAME, "SANDERO RS");
        final String ownerName = prefs.getString(K_OWNER, "Erick Viana");
        final boolean splashOn = prefs.getBoolean(K_SPLASH, true);
        final boolean animOff = prefs.getInt(K_ANIM, 0) == 1;
        final boolean sysHide = prefs.getBoolean(K_SYSBAR, true);
        final boolean sportBtnOn = prefs.getBoolean(K_SPORT_BTN, true);
        final int sbi = Math.max(0, Math.min(STANDBY_MS.length - 1, prefs.getInt(K_STANDBY, 1)));

        LinearLayout g;
        if (settingsTab == -1) {
            buildSettingsHome();
            return;
        }
        {
                g = newGroup("Cores e estilo");
                rowChoice(g, I_CARPLAY, "Tema", prefs.getInt(K_THEME, 0) == 1 ? "Sport" : "Padrão", () ->
                        choose("Tema", new String[]{"Padrão", "Sport (preto e vermelho)"}, prefs.getInt(K_THEME, 0),
                                i -> putInt(K_THEME, i)));
                addItem(g, I_TUNE, accent, "Cor de destaque", null,
                        valueTrailing(ACCENT_NAMES[ai], true, WHITE, accent), () ->
                                choose("Cor de destaque", ACCENT_NAMES, ai, i -> putInt(K_ACCENT, i)));
                rowChoice(g, I_APPS, "Estilo dos cartões", si == 0 ? "Vidro" : "Sólido", () ->
                        choose("Estilo dos cartões", new String[]{"Vidro (translúcido)", "Sólido"}, si, i -> putInt(K_STYLE, i)));
                g = newGroup("Fundo");
                rowChoice(g, I_IMAGE, "Fundo do painel", BG_NAMES[bi], () ->
                        choose("Fundo do painel", BG_NAMES, bi, i -> {
                            if (i == 5) pickImage(REQ_PANELBG); else putInt(K_BG, i);
                        }));
                rowToggle(g, I_TUNE, "Feixes de luz no fundo", "Linhas diagonais como no carro", prefs.getBoolean(K_BEAMS, true),
                        () -> putBool(K_BEAMS, !prefs.getBoolean(K_BEAMS, true)));
                rowChoice(g, I_TUNE, "Cor dos feixes", BEAM_NAMES[Math.max(0, Math.min(7, prefs.getInt(K_BEAM_COL, 0)))],
                        () -> chooseBeamColor());
                rowChoice(g, I_TUNE, "Intensidade dos feixes", BEAM_INT_NAMES[Math.max(0, Math.min(2, prefs.getInt(K_BEAM_INT, 1)))],
                        () -> choose("Intensidade", BEAM_INT_NAMES, prefs.getInt(K_BEAM_INT, 1), i -> putInt(K_BEAM_INT, i)));
                rowChoice(g, I_TUNE, "Preto profundo", new String[]{"Desligado", "Sempre ligado", "Automático (à noite)"}[Math.max(0, Math.min(2, prefs.getInt(K_DEEP_MODE, 0)))], () ->
                        choose("Preto profundo (tela IPS)", new String[]{"Desligado", "Sempre ligado", "Automático: ativa à noite (sensor de luz ou horário)"},
                                prefs.getInt(K_DEEP_MODE, 0), i -> {
                                    putInt(K_DEEP_MODE, i);
                                    startNightWatch();
                                }));
                rowChoice(g, I_IMAGE, "Papel de parede",
                        getFileStreamPath(F_WALL).exists() ? "Personalizado"
                                : WALL_NAMES[Math.max(0, Math.min(WALL_NAMES.length - 1, prefs.getInt(K_WALLPRE, 0)))],
                        () -> showWallpaperPicker());
                g = newGroup("Ícones e carro");
                rowChoice(g, I_APPS, "Tamanho dos ícones (apps)", new String[]{"Pequeno", "Médio", "Grande"}[zi], () ->
                        choose("Tamanho dos ícones", new String[]{"Pequeno", "Médio", "Grande"}, zi, i -> putInt(K_ICON, i)));
                rowToggle(g, I_IMAGE, "Reflexo sob o carro", "Efeito de chão espelhado", refl, () -> putBool(K_REFLECT, !refl));

                g = newGroup("Tela inicial");
                rowChoice(g, I_APPS, "Estilo da tela", mi == 1 ? "Papel de parede" : "Painel", () ->
                        choose("Tela inicial", new String[]{"Painel", "Papel de parede"}, mi, i -> putInt(K_MODE, i)));
                rowToggle(g, I_TUNE, "Botão modo esporte", "Mostra o botão no cartão do carro", sportBtnOn,
                        () -> putBool(K_SPORT_BTN, !sportBtnOn));
                g = newGroup("Carro");
                rowChoice(g, I_TUNE, "Nome do carro", carName, () -> {
                    final EditText et = new EditText(this);
                    et.setSingleLine(true);
                    et.setText(carName);
                    et.setSelection(et.getText().length());
                    new AlertDialog.Builder(this)
                            .setTitle("Nome do carro")
                            .setView(et)
                            .setPositiveButton("OK", (d, w) -> {
                                prefs.edit().putString(K_CAR_NAME, et.getText().toString().trim()).apply();
                                rebuild(true);
                            })
                            .setNegativeButton("Cancelar", null)
                            .show();
                });
                rowChoice(g, I_IMAGE, "Foto do carro", getFileStreamPath(F_CAR).exists() ? "Personalizada" : "Padrão", () ->
                        imageMenu("Foto do carro", REQ_CAR, F_CAR));
                rowChoice(g, I_TUNE, "Mover e redimensionar o carro", "Ajustar", () -> startCarEdit());
                g = newGroup("Luzes do carro (LED)");
                rowChoice(g, I_TUNE, "Controlar fitas de LED", "Painel e zona pé (Bluetooth)", () -> showLedDialog());
                g = newGroup("Conexão OBD (ELM327)");
                final boolean myOn = prefs.getBoolean(K_MYCAR, true);
                final boolean obdOn = prefs.getBoolean(K_OBD, false);
                rowToggle(g, I_BT, "Ler dados do carro (OBD)", "Adaptador ELM327 Bluetooth pareado", obdOn, () -> {
                    prefs.edit().putBoolean(K_OBD, !obdOn).apply();
                    if (obdOn) {
                        stopObd();
                        obdState = 0;
                    } else {
                        startObd();
                    }
                    rebuild(true);
                });
                rowChoice(g, I_BT, "Adaptador OBD", prefs.getString(K_OBD_NAME, "Escolher"), () -> chooseObdDevice());
                rowChoice(g, I_BT, "Pesquisar novos dispositivos", "Buscar", () -> scanObdDevices());
                rowChoice(g, I_BT, "Conectar agora", obdState == 2 ? "Conectado" : "Conectar", () -> {
                    prefs.edit().putBoolean(K_OBD, true).apply();
                    stopObd();
                    obdState = 0;
                    startObd();
                    toast(prefs.getString(K_OBD_ADDR, null) == null ? "Escolha um adaptador primeiro" : "Conectando ao OBD...");
                    rebuild(true);
                });
                rowInfo(g, I_GPS, "Estado do OBD", obdOn ? (obdState == 3 && obdErr.length() > 0 ? "Erro: " + obdErr : "Combustível só aparece se o carro enviar esse dado") : "Desligado",
                        !obdOn ? "" : (obdState == 2 ? "Conectado" : obdState == 1 ? "Conectando" : "Sem conexão"));
                g = newGroup("Cartão Meu Carro");
                rowToggle(g, I_TUNE, "Cartão Meu Carro", "Velocidade, combustível, temperatura e situação", myOn,
                        () -> putBool(K_MYCAR, !myOn));
                final int twv = prefs.getInt(K_TEMP_WARN, 100);
                rowChoice(g, I_SUN, "Alerta de temperatura (vermelho)", twv > 0 ? twv + "°C" : "Desligado", () -> {
                    final String[] ts = new String[9];
                    ts[0] = "Desligado";
                    for (int k = 1; k < 9; k++) ts[k] = (90 + (k - 1) * 5) + "°C";
                    choose("Temperatura que fica vermelha", ts, twv == 0 ? 0 : (twv - 90) / 5 + 1,
                            i -> putInt(K_TEMP_WARN, i == 0 ? 0 : 90 + (i - 1) * 5));
                });
                rowChoice(g, I_TUNE, "Combustível no cartão", prefs.getInt(K_FUEL_UNIT, 0) == 1 ? "Litros" : "Porcentagem", () ->
                        choose("Mostrar combustível em", new String[]{"Porcentagem", "Litros"}, prefs.getInt(K_FUEL_UNIT, 0),
                                i -> putInt(K_FUEL_UNIT, i)));
                rowChoice(g, I_TUNE, "Consumo no cartão", new String[]{"Médio", "Atual", "Oculto"}[Math.max(0, Math.min(2, prefs.getInt(K_HOME_CONS, 0)))], () ->
                        choose("Consumo no cartão", new String[]{"Consumo médio", "Consumo atual", "Não mostrar"}, prefs.getInt(K_HOME_CONS, 0),
                                i -> putInt(K_HOME_CONS, i)));
                final int tank = prefs.getInt(K_TANK, 50);
                rowChoice(g, I_GPS, "Capacidade do tanque", tank + " L", () -> {
                    final String[] ts = new String[11];
                    for (int k = 0; k < 11; k++) ts[k] = (30 + k * 5) + " L";
                    choose("Capacidade do tanque", ts, Math.max(0, Math.min(10, (tank - 30) / 5)), i -> putInt(K_TANK, 30 + i * 5));
                });
                final String[] disps = {"1.0", "1.2", "1.4", "1.6", "1.8", "2.0", "2.2", "2.5"};
                final int[] dispV = {10, 12, 14, 16, 18, 20, 22, 25};
                int dcur = 5;
                for (int k = 0; k < dispV.length; k++) if (dispV[k] == prefs.getInt(K_DISP, 20)) dcur = k;
                final int dcurF = dcur;
                rowChoice(g, I_TUNE, "Motor (para estimar consumo)", disps[dcur] + " L", () ->
                        choose("Cilindrada do motor", disps, dcurF, i -> putInt(K_DISP, dispV[i])));
                rowChoice(g, I_TUNE, "Combustível", prefs.getInt(K_FUELT, 0) == 1 ? "Etanol" : "Gasolina", () ->
                        choose("Combustível usado", new String[]{"Gasolina", "Etanol"}, prefs.getInt(K_FUELT, 0), i -> putInt(K_FUELT, i)));
                g = newGroup("Alerta de velocidade");
                final boolean saOn = prefs.getBoolean(K_SA_ON, false);
                final int saLim = prefs.getInt(K_SA_LIM, 80);
                final int saSnd = Math.max(0, Math.min(SA_NAMES.length - 1, prefs.getInt(K_SA_SND, 0)));
                final int saRep = Math.max(0, Math.min(2, prefs.getInt(K_SA_REP, 1)));
                rowToggle(g, I_GPS, "Alerta de velocidade", "Toca um som ao passar do limite", saOn, () -> {
                    prefs.edit().putBoolean(K_SA_ON, !saOn).apply();
                    saOver = false;
                    rebuild(true);
                });
                rowChoice(g, I_GPS, "Limite", saLim + (mph ? " mph" : " km/h"), () -> {
                    final String[] ls = new String[13];
                    int cur = 0;
                    for (int k = 0; k < ls.length; k++) {
                        ls[k] = (40 + k * 10) + (mph ? " mph" : " km/h");
                        if (40 + k * 10 == saLim) cur = k;
                    }
                    choose("Limite de velocidade", ls, cur, i -> putInt(K_SA_LIM, 40 + i * 10));
                });
                rowChoice(g, I_MUSIC, "Som do alerta", SA_NAMES[saSnd], () ->
                        choose("Som do alerta (toca ao escolher)", SA_NAMES, saSnd, i -> {
                            playAlertSound(i);
                            putInt(K_SA_SND, i);
                        }));
                rowChoice(g, I_PLAY, "Repetir", SA_REP_NAMES[saRep], () ->
                        choose("Repetir alerta", SA_REP_NAMES, saRep, i -> putInt(K_SA_REP, i)));
                rowChoice(g, I_PLAY, "Testar alerta", "Tocar", () -> playAlertSound(saSnd));
                g = newGroup("Alertas do carro");
                rowToggle(g, I_FUEL, "Alerta de combustível baixo", "Janela com OK quando o tanque estiver baixo",
                        prefs.getBoolean(K_LOWFUEL_ON, true), () -> putBool(K_LOWFUEL_ON, !prefs.getBoolean(K_LOWFUEL_ON, true)));
                rowChoice(g, I_FUEL, "Avisar com tanque em", prefs.getInt(K_LOWFUEL_PCT, 15) + "%", () -> {
                    final int[] pv = {10, 15, 20, 25, 30};
                    final String[] pn = {"10%", "15%", "20%", "25%", "30%"};
                    choose("Combustível baixo", pn, 1, i -> putInt(K_LOWFUEL_PCT, pv[i]));
                });
                rowToggle(g, I_TEMP, "Janela Cold Start", "Mostra o aquecimento do motor frio",
                        prefs.getBoolean(K_COLD_ON, true), () -> putBool(K_COLD_ON, !prefs.getBoolean(K_COLD_ON, true)));
                rowChoice(g, I_TEMP, "Cold Start termina em", prefs.getInt(K_COLD_END, 60) + "°C", () -> {
                    final int[] pv = {50, 60, 70, 80};
                    final String[] pn = {"50°C", "60°C", "70°C", "80°C"};
                    choose("Fim do Cold Start", pn, 1, i -> putInt(K_COLD_END, pv[i]));
                });
                rowToggle(g, I_TUNE, "Detectar Modo Sport do carro", "Pela rotação alta em marcha lenta (motor quente)",
                        prefs.getBoolean(K_SPORT_DET, true), () -> putBool(K_SPORT_DET, !prefs.getBoolean(K_SPORT_DET, true)));
                rowChoice(g, I_TUNE, "Rotação do Modo Sport", prefs.getInt(K_SPORT_RPM, 1000) + " rpm", () -> {
                    final int[] pv = {900, 950, 1000, 1050, 1100, 1200};
                    final String[] pn = {"900 rpm", "950 rpm", "1000 rpm", "1050 rpm", "1100 rpm", "1200 rpm"};
                    choose("Marcha lenta em Modo Sport a partir de", pn, 2, i -> putInt(K_SPORT_RPM, pv[i]));
                });
                g = newGroup("Combustível e gastos");
                rowChoice(g, I_FUEL, "Preço do combustível", prefs.getFloat(K_PRICE, 0f) > 0 ? money(prefs.getFloat(K_PRICE, 0f)) + "/L" : "Definir", () -> askPrice());
                rowChoice(g, I_RESTART, "Zerar total de gastos", "Zerar", () -> confirmResetTotals());
                g = newGroup("Unidades");
                rowChoice(g, I_SUN, "Formato da hora", c24 ? "24 horas" : "12 horas", () -> putBool(K_CLOCK24, !c24));
                rowChoice(g, I_SUN, "Temperatura", tempF ? "°F" : "°C", () -> putBool(K_TEMP_F, !tempF));
                rowChoice(g, I_GPS, "Velocidade", mph ? "mph" : "km/h", () -> putBool(K_MPH, !mph));

                g = newGroup("Música");
                final String legacyInfo = legacyTitle != null ? "Via transmissão do player" : null;
                String st = mediaAccess ? "Ativa" : (legacyInfo != null ? "Parcial" : "Toque para ativar");
                String sub = mediaAccess ? "Lendo faixa e capa do player"
                        : (legacyInfo != null ? legacyInfo + " — ative o acesso para a capa completa"
                        : "Permite mostrar título e capa da música");
                if (mediaError.length() > 0) sub += "  (" + mediaError + ")";
                RowAction accessAction = null;
                if (!mediaAccess) accessAction = () -> openNotificationAccess();
                addItem(g, I_MUSIC, accent, "Leitura da música", sub,
                        valueTrailing(st, !mediaAccess, mediaAccess ? accent : WHITE, 0),
                        accessAction);
                g = newGroup("Apps dos cartões");
                rowChoice(g, I_MUSIC, "App de música", "Escolher", () -> showAppPicker(KEY_MUSIC, "App de música"));
                rowChoice(g, I_NAV, "App de navegação", "Escolher", () -> showAppPicker(KEY_NAV, "App de navegação"));
                rowChoice(g, I_PHONE, "App de telefone", "Escolher", () -> showAppPicker(KEY_PHONE, "App de telefone"));
                rowChoice(g, I_CARPLAY, "App do CarPlay", prefs.getString(KEY_CARPLAY, null) == null ? "Automático" : "Escolhido",
                        () -> showAppPicker(KEY_CARPLAY, "App do CarPlay"));
                final int cpMode = Math.max(0, Math.min(2, prefs.getInt(K_CPICON, 0)));
                rowChoice(g, I_CARPLAY, "Ícone do botão CarPlay", CP_ICON_NAMES[cpMode], () ->
                        choose("Ícone do botão CarPlay", CP_ICON_NAMES, cpMode, i -> {
                            if (i == 2) pickImage(REQ_CPICON);
                            else putInt(K_CPICON, i);
                        }));
                rowChoice(g, I_GEAR, "App de ajustes", "Escolher", () -> showAppPicker(KEY_SETTINGS, "App de ajustes"));

                g = newGroup("Boas-vindas");
                rowChoice(g, I_PLAY, "Nome do proprietário", ownerName.length() > 0 ? ownerName : "(vazio)", () -> {
                    final EditText et2 = new EditText(this);
                    et2.setSingleLine(true);
                    et2.setText(ownerName);
                    et2.setSelection(et2.getText().length());
                    new AlertDialog.Builder(this)
                            .setTitle("Nome do proprietário")
                            .setView(et2)
                            .setPositiveButton("OK", (d, w) -> {
                                prefs.edit().putString(K_OWNER, et2.getText().toString().trim()).apply();
                                rebuild(true);
                            })
                            .setNegativeButton("Cancelar", null)
                            .show();
                });
                rowChoice(g, I_PLAY, "Foto do avatar", getFileStreamPath(F_AVATAR).exists() ? "Personalizada" : "Inicial do nome",
                        () -> avatarMenu());
                rowToggle(g, I_PLAY, "Animação de abertura", "Logo Renault Sport + saudação", splashOn,
                        () -> putBool(K_SPLASH, !splashOn));
                rowChoice(g, I_PLAY, "Rever animação", "Tocar", () -> {
                    settingsPanel.setVisibility(View.GONE);
                    playSplash(0);
                });
                g = newGroup("Som de boas-vindas");
                rowToggle(g, I_MUSIC, "Tocar som na abertura", "Toca junto com a animação", prefs.getBoolean(K_SOUND, true),
                        () -> putBool(K_SOUND, !prefs.getBoolean(K_SOUND, true)));
                rowChoice(g, I_MUSIC, "Som escolhido", getFileStreamPath(F_SOUND).exists() ? "Personalizado" : "Padrão", () ->
                        choose("Som de boas-vindas", new String[]{"Escolher arquivo de áudio", "Usar o som padrão"}, -1, i -> {
                            if (i == 0) {
                                pickSound();
                            } else {
                                deleteFile(F_SOUND);
                                rebuild(true);
                            }
                        }));
                rowChoice(g, I_PLAY, "Testar som", "Tocar", () -> playWelcomeSound());
                g = newGroup("Ao ligar o carro (standby)");
                final int bli = Math.max(0, Math.min(BLACK_MS.length - 1, prefs.getInt(K_BLACK, 1)));
                rowChoice(g, I_PLAY, "Tela preta antes da abertura", BLACK_NAMES[bli], () ->
                        choose("Tela preta antes da abertura", BLACK_NAMES, bli, i -> putInt(K_BLACK, i)));
                rowToggle(g, I_APPS, "Abrir a launcher ao ligar", "Traz a launcher para a frente ao sair do standby",
                        prefs.getBoolean(K_FRONT, true), () -> putBool(K_FRONT, !prefs.getBoolean(K_FRONT, true)));
                rowChoice(g, I_GPS, "Tempo mínimo em standby", STANDBY_NAMES[sbi], () ->
                        choose("Mostrar abertura após standby de pelo menos", STANDBY_NAMES, sbi, i -> putInt(K_STANDBY, i)));
                rowInfo(g, I_SUN, "Última detecção", "Quando o launcher percebeu o carro ligando",
                        prefs.getString(K_WAKE_REASON, "nenhuma ainda"));
                g = newGroup("Animações");
                rowToggle(g, I_TUNE, "Animações do launcher", "Transições estilo iOS", !animOff,
                        () -> putInt(K_ANIM, animOff ? 0 : 1));

                g = newGroup("Sistema");
                rowToggle(g, I_GEAR, "Esconder barra do Android", "O launcher desenha a própria barra", sysHide, () -> {
                    prefs.edit().putBoolean(K_SYSBAR, !sysHide).apply();
                    applySystemUi();
                    rebuild(true);
                });
                rowChoice(g, I_APPS, "Launcher padrão atual", defaultHomeLabel(), () -> chooseDefaultHome());
                rowChoice(g, I_RESTART, "Reiniciar launcher", "Reiniciar", () -> confirmRestart());
                g = newGroup("Restaurar");
                addItem(g, I_CLOSE, 0xFFFF5A5F, "Restaurar padrões", "Cores, fundo, fotos e opções. Seus apps do dock são mantidos.",
                        null, () ->
                                new AlertDialog.Builder(this)
                                        .setTitle("Restaurar padrões?")
                                        .setMessage("Cores, fundo, fotos e opções voltam ao original. Seus apps do dock são mantidos.")
                                        .setPositiveButton("Restaurar", (d, w) -> {
                                            prefs.edit().remove(K_ACCENT).remove(K_BG).remove(K_STYLE).remove(K_CAR_NAME)
                                                    .remove(K_CLOCK24).remove(K_ICON).remove(K_REFLECT).remove(K_MODE)
                                                    .remove(K_TEMP_F).remove(K_MPH).remove(K_SPORT_BTN).remove(K_STANDBY).remove(K_SOUND).remove(K_WALLPRE).remove(K_BLACK).remove(K_LOWFUEL_ON).remove(K_LOWFUEL_PCT).remove(K_COLD_ON).remove(K_COLD_END).remove(K_SPORT_DET).remove(K_SPORT_RPM).remove(K_FUEL_UNIT).remove(K_HOME_CONS).remove(K_TEMP_WARN).remove(K_TANK).remove(K_DISP).remove(K_FUELT).remove(K_BEAMS).remove(K_BEAM_COL).remove(K_BEAM_CUSTOM).remove(K_BEAM_INT).remove(K_MYCAR).remove(K_SA_ON).remove(K_SA_LIM).remove(K_SA_SND).remove(K_SA_REP).remove(K_DEEP).remove(K_DEEP_MODE).remove(K_THEME).remove(K_FRONT).remove(K_CPICON).remove(K_CAR_SC).remove(K_CAR_DX).remove(K_CAR_DY)
                                                    .apply();
                                            deleteFile(F_CAR);
                                            deleteFile(F_WALL);
                                            deleteFile(F_PANELBG);
                                            deleteFile(F_SOUND);
                                            deleteFile(F_CPICON);
                                            deleteFile(F_AVATAR);
                                            avatarBmp = null;
                                            wallBmp = null;
                                            rebuild(true);
                                        })
                                        .setNegativeButton("Cancelar", null)
                                        .show());
        }
    }

    // ------------------------------------------------------------------ mídia

    private void mediaKey(int code) {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
    }

    private void applyMusic(MusicViews mv) {
        if (!curTitle.contentEquals(mv.title.getText())) mv.title.setText(curTitle);
        if (!curArtist.contentEquals(mv.artist.getText())) mv.artist.setText(curArtist);
        if (curCover != null && !curCover.isRecycled()) {
            mv.cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
            mv.cover.setPadding(0, 0, 0, 0);
            mv.cover.setImageBitmap(curCover);
        } else {
            mv.cover.setScaleType(ImageView.ScaleType.FIT_CENTER);
            int pd = dp(mv.phPad);
            mv.cover.setPadding(pd, pd, pd, pd);
            mv.cover.setImageDrawable(new IconDrawable(I_MUSIC, accent));
        }
        if (mv.play != null) {
            mv.play.setImageDrawable(new IconDrawable(curPlaying ? I_PAUSE : I_PLAY, WHITE));
        }
    }

    private void refreshMusicViews() {
        for (MusicViews mv : musics) applyMusic(mv);
    }

    /** Aparece suavemente (fade + leve subida). */
    private void fadeIn(View v, int ms, int shiftDp) {
        v.animate().cancel();
        v.setAlpha(0f);
        v.setTranslationY(dp(shiftDp));
        v.animate().setStartDelay(0).alpha(1f).translationY(0f).setDuration(dur(ms))
                .setInterpolator(new DecelerateInterpolator(1.8f)).start();
    }

    private void setMusic(String title, String artist, boolean playing) {
        boolean textChanged = !title.equals(curTitle) || !artist.equals(curArtist);
        boolean playChanged = playing != curPlaying;
        curTitle = title;
        curArtist = artist;
        curPlaying = playing;
        if (textChanged || playChanged) refreshMusicViews();
        if (textChanged && visible) {
            for (MusicViews mv : musics) {
                fadeIn(mv.title, 480, 8);
                fadeIn(mv.artist, 600, 8);
            }
        }
    }

    private void setCover(Bitmap bmp, String key) {
        boolean valid = curCover != null && !curCover.isRecycled();
        if (key.equals(lastCoverKey) && (valid || curCover == null)) return;
        lastCoverKey = key;
        curCover = bmp;
        refreshMusicViews();
        if (visible) for (MusicViews mv : musics) fadeIn(mv.cover, 600, 0);
    }

    private static int bitmapSig(Bitmap b) {
        try {
            int h = 17;
            for (int i = 1; i <= 3; i++) {
                for (int j = 1; j <= 3; j++) {
                    h = h * 31 + b.getPixel(b.getWidth() * i / 4, b.getHeight() * j / 4);
                }
            }
            return h;
        } catch (Exception e) {
            return 0;
        }
    }

    /** Cópia própria da capa (o player pode reciclar o bitmap original). */
    private static Bitmap copyBitmap(Bitmap src) {
        try {
            int w = src.getWidth(), h = src.getHeight();
            int max = Math.max(w, h);
            if (max > 900) {
                float f = 900f / max;
                return Bitmap.createScaledBitmap(src, Math.round(w * f), Math.round(h * f), true);
            }
            return src.copy(Bitmap.Config.ARGB_8888, false);
        } catch (Exception e) {
            return null;
        }
    }

    private void loadCoverAsync(final String uriStr, final String key) {
        new Thread(() -> {
            Bitmap b = null;
            try {
                Uri u = Uri.parse(uriStr);
                String sch = u.getScheme();
                if ("content".equals(sch) || "file".equals(sch) || "android.resource".equals(sch)) {
                    b = decodeUri(u, 600);
                }
            } catch (Exception ignored) {
            }
            final Bitmap res = b;
            runOnUiThread(() -> {
                if (key.equals(lastCoverKey)) {
                    curCover = res;
                    if (res == null) coverFailAt = SystemClock.elapsedRealtime();
                    refreshMusicViews();
                    if (res != null && visible) for (MusicViews mv : musics) fadeIn(mv.cover, 600, 0);
                }
            });
        }).start();
    }

    private boolean musicActive() {
        try {
            return ((AudioManager) getSystemService(Context.AUDIO_SERVICE)).isMusicActive();
        } catch (Exception e) {
            return false;
        }
    }

    private void idleMusic() {
        boolean act = musicActive();
        setMusic(act ? "Reproduzindo" : "Nenhuma música tocando", "Toque para abrir o player", act);
        setCover(null, "none");
    }

    /** Usa os dados vindos das transmissões antigas dos players, se existirem. */
    private boolean applyLegacy() {
        if (legacyTitle == null) return false;
        if (!legacyPlaying && SystemClock.elapsedRealtime() - legacyReal > 6 * 3600 * 1000L) return false;
        setMusic(legacyTitle, legacyArtist, legacyPlaying);
        ensureLookup(legacyKey, legacyId, legacyTitle, legacyArtist, legacyAlbum);
        if (legacyKey.equals(lookupKey) && lookupCover != null) setCover(lookupCover, legacyKey + "|ok");
        else setCover(null, "none");
        return true;
    }

    /** Procura a capa nos arquivos de música do aparelho (MediaStore / imagem embutida no arquivo). */
    private void ensureLookup(final String key, final long id, final String title, final String artist,
                              final String album) {
        long nowR = SystemClock.elapsedRealtime();
        if (key.equals(lookupKey)) {
            boolean retry = lookupDone && lookupCover == null && lookupTries < 3 && nowR - lookupAt > 20000L;
            if (!retry) return;
            lookupTries++;
        } else {
            lookupTries = 0;
        }
        lookupKey = key;
        lookupCover = null;
        lookupDone = false;
        lookupAt = nowR;
        new Thread(() -> {
            Bitmap b = null;
            try {
                long albumId = -1;
                String data = null;
                Uri base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                String[] cols = {MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DATA};
                Cursor c = null;
                try {
                    if (id > 0) {
                        c = getContentResolver().query(base, cols, MediaStore.Audio.Media._ID + "=?",
                                new String[]{String.valueOf(id)}, null);
                    }
                    if ((c == null || !c.moveToFirst()) && title != null) {
                        if (c != null) c.close();
                        c = getContentResolver().query(base, cols, MediaStore.Audio.Media.TITLE + "=?",
                                new String[]{title}, null);
                    }
                    if (c != null && c.moveToFirst()) {
                        albumId = c.getLong(0);
                        data = c.getString(1);
                    }
                } finally {
                    if (c != null) c.close();
                }
                if (albumId > 0) {
                    Uri art = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId);
                    b = decodeUri(art, 700);
                }
                if (b == null && data != null) {
                    MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                    try {
                        mmr.setDataSource(data);
                        byte[] pic = mmr.getEmbeddedPicture();
                        if (pic != null) {
                            BitmapFactory.Options o = new BitmapFactory.Options();
                            o.inJustDecodeBounds = true;
                            BitmapFactory.decodeByteArray(pic, 0, pic.length, o);
                            int sample = 1;
                            while (o.outWidth / sample > 1400) sample *= 2;
                            BitmapFactory.Options o2 = new BitmapFactory.Options();
                            o2.inSampleSize = sample;
                            b = BitmapFactory.decodeByteArray(pic, 0, pic.length, o2);
                        }
                    } finally {
                        mmr.release();
                    }
                }
            } catch (Throwable ignored) {
            }
            final Bitmap res = b;
            runOnUiThread(() -> {
                if (key.equals(lookupKey)) {
                    lookupCover = res;
                    lookupDone = true;
                    updateMedia();
                }
            });
        }).start();
    }

    private void updateMedia() {
        try {
            MediaSessionManager msm = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
            List<MediaController> list = msm.getActiveSessions(new ComponentName(this, MediaListener.class));
            mediaAccess = true;
            mediaError = "";

            MediaController pick = null;
            for (MediaController c : list) {
                PlaybackState s = c.getPlaybackState();
                if (s != null && s.getState() == PlaybackState.STATE_PLAYING) {
                    pick = c;
                    break;
                }
            }
            if (pick == null && !list.isEmpty()) pick = list.get(0);

            if (pick == null) {
                if (!applyLegacy()) idleMusic();
                return;
            }

            MediaMetadata md = pick.getMetadata();
            String title = md != null ? md.getString(MediaMetadata.METADATA_KEY_TITLE) : null;
            String artist = md != null ? md.getString(MediaMetadata.METADATA_KEY_ARTIST) : null;
            if (artist == null && md != null) artist = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
            String album = md != null ? md.getString(MediaMetadata.METADATA_KEY_ALBUM) : null;
            PlaybackState s = pick.getPlaybackState();
            boolean playing = s != null && s.getState() == PlaybackState.STATE_PLAYING;
            setMusic(title != null ? title : "Música", artist != null ? artist : "", playing);

            // capa do álbum
            Bitmap art = null;
            String artUri = null;
            if (md != null) {
                art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                if (art == null) art = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                if (art == null) art = md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
                if (art == null) {
                    artUri = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI);
                    if (artUri == null) artUri = md.getString(MediaMetadata.METADATA_KEY_ART_URI);
                    if (artUri == null) artUri = md.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI);
                }
            }
            if (art != null) {
                String bk = "b|" + title + "|" + artist + "|" + art.getWidth() + "x" + art.getHeight() + "|" + bitmapSig(art);
                boolean valid = curCover != null && !curCover.isRecycled();
                if (!bk.equals(lastCoverKey) || !valid) {
                    Bitmap own = copyBitmap(art);
                    if (own != null) setCover(own, bk);
                }
            } else if (artUri != null) {
                String uk = artUri + "|" + title;
                if (!uk.equals(lastCoverKey)) {
                    lastCoverKey = uk;
                    coverRetries = 0;
                    coverFailAt = 0;
                    loadCoverAsync(artUri, uk);
                } else if ((curCover == null || curCover.isRecycled()) && coverFailAt != 0
                        && coverRetries < 4 && SystemClock.elapsedRealtime() - coverFailAt > 6000L) {
                    coverRetries++;
                    coverFailAt = 0;
                    loadCoverAsync(artUri, uk);
                }
            } else if (title != null) {
                String qk = "Q|" + title + "|" + artist;
                ensureLookup(qk, -1, title, artist, album);
                if (qk.equals(lookupKey) && lookupCover != null) setCover(lookupCover, qk + "|ok");
                else setCover(null, "none");
            } else {
                setCover(null, "none");
            }
        } catch (SecurityException e) {
            mediaAccess = false;
            mediaError = "sem permissão";
            if (!applyLegacy()) {
                setMusic("Ativar leitura de música", "Toque aqui e permita o acesso", musicActive());
                setCover(null, "none");
            }
        } catch (Exception e) {
            mediaAccess = false;
            mediaError = e.getClass().getSimpleName();
            if (!applyLegacy()) idleMusic();
        }
    }

    /** Tenta liberar (ou abrir a tela para liberar) o acesso de leitura da música em reprodução. */
    private void openNotificationAccess() {
        try {
            String me = new ComponentName(this, MediaListener.class).flattenToString();
            String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
            if (flat == null || !flat.contains(me)) {
                String nv = (flat == null || flat.isEmpty()) ? me : flat + ":" + me;
                if (Settings.Secure.putString(getContentResolver(), "enabled_notification_listeners", nv)) {
                    Toast.makeText(this, "Acesso liberado", Toast.LENGTH_SHORT).show();
                    handler.postDelayed(this::updateMedia, 1000);
                    return;
                }
            }
        } catch (Exception ignored) {
        }
        Intent[] tries = {
                new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"),
                new Intent().setComponent(new ComponentName("com.android.settings",
                        "com.android.settings.Settings$NotificationAccessSettingsActivity")),
                new Intent(Settings.ACTION_SETTINGS)};
        for (Intent in : tries) {
            try {
                in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(in);
                Toast.makeText(this, "Ative o \"Sandero Launcher\" na lista", Toast.LENGTH_LONG).show();
                return;
            } catch (Exception ignored) {
            }
        }
        Toast.makeText(this, "Este aparelho não tem a tela de acesso a notificações", Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------------ som de boas-vindas

    private File soundFile() {
        File custom = getFileStreamPath(F_SOUND);
        if (custom.exists() && custom.length() > 0) return custom;
        File cached = new File(getCacheDir(), "welcome.mp3");
        if (!cached.exists() || cached.length() == 0) {
            try {
                InputStream in = getAssets().open("welcome.mp3");
                FileOutputStream out = new FileOutputStream(cached);
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.close();
                in.close();
            } catch (Exception e) {
                return null;
            }
        }
        return cached;
    }

    private void stopWelcomeSound() {
        MediaPlayer mp = soundPlayer;
        soundPlayer = null;
        if (mp == null) return;
        try {
            mp.stop();
        } catch (Exception ignored) {
        }
        try {
            mp.release();
        } catch (Exception ignored) {
        }
        abandonFocus();
    }

    private void abandonFocus() {
        try {
            ((AudioManager) getSystemService(Context.AUDIO_SERVICE)).abandonAudioFocus(null);
        } catch (Exception ignored) {
        }
    }

    private void playWelcomeSound() {
        if (!prefs.getBoolean(K_SOUND, true)) return;
        stopWelcomeSound();
        File f = soundFile();
        if (f == null) return;
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
            final MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            mp.setDataSource(f.getAbsolutePath());
            mp.setOnPreparedListener(m -> {
                try {
                    m.start();
                } catch (Exception ignored) {
                }
            });
            mp.setOnCompletionListener(m -> {
                if (soundPlayer == m) soundPlayer = null;
                try {
                    m.release();
                } catch (Exception ignored) {
                }
                abandonFocus();
            });
            mp.setOnErrorListener((m, w, e) -> {
                if (soundPlayer == m) soundPlayer = null;
                try {
                    m.release();
                } catch (Exception ignored) {
                }
                abandonFocus();
                return true;
            });
            soundPlayer = mp;
            mp.prepareAsync();
        } catch (Exception e) {
            soundPlayer = null;
            abandonFocus();
        }
    }

    private void pickSound() {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("audio/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, REQ_SOUND);
        } catch (Exception e) {
            toast("Nenhum app de arquivos encontrado");
        }
    }

    private void saveSound(final Uri uri) {
        new Thread(() -> {
            boolean ok = false;
            try {
                InputStream in = getContentResolver().openInputStream(uri);
                if (in != null) {
                    File tmp = new File(getCacheDir(), "snd.tmp");
                    FileOutputStream out = new FileOutputStream(tmp);
                    byte[] buf = new byte[16384];
                    long total = 0;
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        total += n;
                        if (total > 15L * 1024 * 1024) throw new Exception("grande");
                        out.write(buf, 0, n);
                    }
                    out.close();
                    in.close();
                    File dst = getFileStreamPath(F_SOUND);
                    ok = total > 0 && (!dst.exists() || dst.delete()) && tmp.renameTo(dst);
                }
            } catch (Exception ignored) {
            }
            final boolean res = ok;
            runOnUiThread(() -> {
                toast(res ? "Som de boas-vindas definido" : "Não foi possível usar esse arquivo (máx. 15 MB)");
                if (res) {
                    rebuild(true);
                    playWelcomeSound();
                }
            });
        }).start();
    }

    // ------------------------------------------------------------------ reiniciar launcher

    /** Quem o Android abre ao apertar "Início": este launcher, outro, ou ninguém (pergunta sempre). */
    private String defaultHomeLabel() {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            ResolveInfo ri = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
            if (ri == null || ri.activityInfo == null) return "Desconhecido";
            String pkg = ri.activityInfo.packageName;
            if (getPackageName().equals(pkg)) return "Este launcher ✓";
            if ("android".equals(pkg)) return "Nenhum (o sistema pergunta)";
            try {
                return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
            } catch (Exception e) {
                return pkg;
            }
        } catch (Exception e) {
            return "Desconhecido";
        }
    }

    private void chooseDefaultHome() {
        try {
            Intent i = new Intent(Settings.ACTION_HOME_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            return;
        } catch (Exception ignored) {
        }
        // Sem tela de launcher padrão: dispara o "Início"; se não houver padrão, o Android pergunta qual usar.
        try {
            Intent h = new Intent(Intent.ACTION_MAIN);
            h.addCategory(Intent.CATEGORY_HOME);
            h.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(h);
            toast("Se aparecer a lista, escolha Sandero Launcher e toque em \"Sempre\"");
        } catch (Exception e) {
            toast("Abra Ajustes do Android → Apps e limpe o padrão do launcher antigo");
        }
    }

    private void confirmRestart() {
        new AlertDialog.Builder(this)
                .setTitle("Reiniciar a launcher?")
                .setMessage("A tela inicial fecha e abre de novo em instantes.")
                .setPositiveButton("Reiniciar", (d, w) -> restartLauncher())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void restartLauncher() {
        prefs.edit().putBoolean(K_SKIP_SPLASH, true).commit();
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.setAction(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            PendingIntent pi = PendingIntent.getActivity(this, 77, i, PendingIntent.FLAG_CANCEL_CURRENT);
            ((AlarmManager) getSystemService(Context.ALARM_SERVICE))
                    .set(AlarmManager.RTC, System.currentTimeMillis() + 500, pi);
        } catch (Exception ignored) {
        }
        stopWelcomeSound();
        finishAffinity();
        handler.postDelayed(() -> Process.killProcess(Process.myPid()), 200);
    }

    // ------------------------------------------------------------------ CarPlay

    private AppItem findCarplayApp() {
        String[] keys = {"carplay", "zlink", "carlink", "autokit", "carbit", "wireless"};
        for (AppItem a : apps) {
            String n = (a.label + " " + a.pkg).toLowerCase();
            for (String k : keys) if (n.contains(k)) return a;
        }
        return null;
    }

    private void openCarplay() {
        String pkg = prefs.getString(KEY_CARPLAY, null);
        if (pkg != null && launchPkg(pkg)) return;
        AppItem f = findCarplayApp();
        if (f != null) {
            prefs.edit().putString(KEY_CARPLAY, f.pkg).apply();
            launch(f);
            return;
        }
        toast("Escolha o app de CarPlay da sua multimídia");
        showAppPicker(KEY_CARPLAY, "App do CarPlay");
    }

    // ------------------------------------------------------------------ chamada

    private void registerPhone() {
        if (phoneListening) return;
        try {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
                    != PackageManager.PERMISSION_GRANTED) return;
            TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return;
            tm.listen(phoneListener, PhoneStateListener.LISTEN_CALL_STATE);
            phoneListening = true;
        } catch (Exception ignored) {
        }
    }

    private final PhoneStateListener phoneListener = new PhoneStateListener() {
        @Override
        public void onCallStateChanged(int state, String number) {
            telState = state;
            if (number != null && number.length() > 0) callNumber = number;
            if (state == TelephonyManager.CALL_STATE_IDLE) callNumber = null;
            updateCall();
        }
    };

    private String contactName(String number) {
        if (number == null || number.length() == 0) return null;
        if (number.equals(nameCacheNum)) return nameCacheVal;
        String res = null;
        Cursor c = null;
        try {
            Uri u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number));
            c = getContentResolver().query(u, new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) res = c.getString(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        nameCacheNum = number;
        nameCacheVal = res;
        return res;
    }

    private void updateCall() {
        if (callBanner == null) return;
        int mode = AudioManager.MODE_NORMAL;
        try {
            mode = ((AudioManager) getSystemService(Context.AUDIO_SERVICE)).getMode();
        } catch (Exception ignored) {
        }
        boolean ringing = telState == TelephonyManager.CALL_STATE_RINGING || mode == AudioManager.MODE_RINGTONE;
        boolean active = telState == TelephonyManager.CALL_STATE_OFFHOOK
                || mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION;
        if (!ringing && !active) {
            if (callBanner.getVisibility() == View.VISIBLE) {
                if (callBlink != null) callBlink.cancel();
                callBanner.setAlpha(1f);
                callBanner.setVisibility(View.GONE);
            }
            return;
        }
        String who = MediaListener.callTitle();
        if (who == null) who = contactName(callNumber);
        if (who == null && callNumber != null) who = callNumber;
        String label = ringing ? "Chamada recebida" : "Em chamada";
        String txt = who != null ? label + " · " + who : label;
        if (!txt.contentEquals(callText.getText())) callText.setText(txt);
        if (callBanner.getVisibility() != View.VISIBLE) {
            callBanner.setVisibility(View.VISIBLE);
            callBlink = ValueAnimator.ofFloat(1f, 0.45f);
            callBlink.setDuration(750);
            callBlink.setRepeatCount(ValueAnimator.INFINITE);
            callBlink.setRepeatMode(ValueAnimator.REVERSE);
            callBlink.addUpdateListener(an -> callBanner.setAlpha((Float) an.getAnimatedValue()));
            callBlink.start();
        }
    }

    // ------------------------------------------------------------------ GPS (velocidade) e clima

    private boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < 23) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private final LocationListener locListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location l) {
            if (LocationManager.GPS_PROVIDER.equals(l.getProvider())) {
                hasFix = true;
                lastGpsTime = System.currentTimeMillis();
                speedMs = l.hasSpeed() ? l.getSpeed() : 0f;
                refreshSpeed();
            }
            maybeFetchWeather(l);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }
    };

    private void startLocation() {
        if (locManager == null || !hasLocationPermission()) return;
        try {
            if (locManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, locListener);
            }
            if (locManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 60000, 100, locListener);
            }
            Location last = locManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null) last = locManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (last != null) maybeFetchWeather(last);
        } catch (SecurityException | IllegalArgumentException e) {
            // sem permissão ou sem provedor: segue sem GPS
        }
    }

    private void stopLocation() {
        try {
            if (locManager != null) locManager.removeUpdates(locListener);
        } catch (SecurityException ignored) {
        }
    }

    private void refreshSpeed() {
        String t = "--";
        boolean useObd = obdState == 2 && obdSpeed >= 0;
        double curMs = useObd ? obdSpeed / 3.6 : speedMs;
        boolean have = useObd || hasFix;
        if (have) {
            double v = curMs * (mph ? 2.23694 : 3.6);
            t = String.valueOf(Math.round(v < 2 ? 0 : v));
        }
        for (TextView tv : speedNums) {
            if (!t.contentEquals(tv.getText())) tv.setText(t);
        }
        double rv = have ? curMs * (mph ? 2.23694 : 3.6) : 0;
        boolean over = checkSpeedAlert(rv);
        if (ringRef != null) {
            ringRef.setSpeedText(t, mph ? "mph" : "km/h");
            ringRef.setRpm(obdState == 2 ? obdRpm : -1);
            ringRef.setValue((float) (rv / (mph ? 125.0 : 200.0)));
            ringRef.setAlert(over);
        }
        for (TextView tv : speedNums) tv.setTextColor(over ? 0xFFFF4D4D : WHITE);
    }

    // clima (Open-Meteo, sem chave)
    private boolean wHas = false;
    private float wTemp, wMax, wMin;
    private int wCode;

    private void wFromPrefs() {
        wHas = prefs.getBoolean(K_W_HAS, false);
        wTemp = prefs.getFloat(K_W_TEMP, 0f);
        wMax = prefs.getFloat(K_W_MAX, 0f);
        wMin = prefs.getFloat(K_W_MIN, 0f);
        wCode = prefs.getInt(K_W_CODE, 0);
        wCity = prefs.getString(K_W_CITY, "");
    }

    private void maybeFetchWeather(Location l) {
        long now = System.currentTimeMillis();
        if (weatherBusy || (wHas && now - lastWeatherFetch < WEATHER_EVERY_MS)
                || (!wHas && now - lastWeatherFetch < 60000)) return;
        weatherBusy = true;
        lastWeatherFetch = now;
        final double lat = l.getLatitude();
        final double lon = l.getLongitude();
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL u = new URL(String.format(Locale.US,
                        "https://api.open-meteo.com/v1/forecast?latitude=%.3f&longitude=%.3f"
                                + "&current=temperature_2m,weather_code"
                                + "&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1",
                        lat, lon));
                conn = (HttpURLConnection) u.openConnection();
                conn.setConnectTimeout(8000);
                conn.setReadTimeout(8000);
                InputStream in = conn.getInputStream();
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[2048];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                in.close();
                JSONObject j = new JSONObject(bos.toString("UTF-8"));
                JSONObject cur = j.getJSONObject("current");
                JSONObject daily = j.getJSONObject("daily");
                final float t = (float) cur.getDouble("temperature_2m");
                final int code = cur.getInt("weather_code");
                final float mx = (float) daily.getJSONArray("temperature_2m_max").getDouble(0);
                final float mn = (float) daily.getJSONArray("temperature_2m_min").getDouble(0);
                prefs.edit().putBoolean(K_W_HAS, true).putFloat(K_W_TEMP, t).putInt(K_W_CODE, code)
                        .putFloat(K_W_MAX, mx).putFloat(K_W_MIN, mn).apply();
                final String city = reverseCity(lat, lon);
                if (city != null) prefs.edit().putString(K_W_CITY, city).apply();
                runOnUiThread(() -> {
                    if (city != null) wCity = city;
                    wHas = true;
                    wTemp = t;
                    wCode = code;
                    wMax = mx;
                    wMin = mn;
                    refreshWeather();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    weatherStatus = wHas ? "" : "Sem internet no momento";
                    refreshWeather();
                });
            } finally {
                if (conn != null) conn.disconnect();
                weatherBusy = false;
            }
        }).start();
    }

    private String reverseCity(double lat, double lon) {
        HttpURLConnection conn = null;
        try {
            URL u = new URL(String.format(Locale.US,
                    "https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=%.4f&longitude=%.4f&localityLanguage=pt",
                    lat, lon));
            conn = (HttpURLConnection) u.openConnection();
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(6000);
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[2048];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            in.close();
            JSONObject j = new JSONObject(bos.toString("UTF-8"));
            String c = j.optString("city", "");
            if (c.length() == 0) c = j.optString("locality", "");
            return c.length() > 0 ? c : null;
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private String fmtTemp(float c) {
        float v = tempF ? c * 9f / 5f + 32f : c;
        return Math.round(v) + "°";
    }

    private String weatherDesc(int code) {
        if (code == 0) return "Céu limpo";
        if (code == 1) return "Predomínio de sol";
        if (code == 2) return "Parcialmente nublado";
        if (code == 3) return "Nublado";
        if (code == 45 || code == 48) return "Neblina";
        if (code >= 51 && code <= 57) return "Garoa";
        if (code >= 61 && code <= 65) return "Chuva";
        if (code == 66 || code == 67) return "Chuva gelada";
        if (code >= 71 && code <= 77) return "Neve";
        if (code >= 80 && code <= 82) return "Pancadas de chuva";
        if (code == 85 || code == 86) return "Neve";
        if (code >= 95) return "Tempestade";
        return "Tempo instável";
    }

    private int weatherIcon(int code) {
        if (code <= 1) return I_SUN;
        if (code == 2) return I_PARTLY;
        if (code == 3 || code == 45 || code == 48 || (code >= 71 && code <= 77) || code == 85 || code == 86) {
            return I_CLOUD;
        }
        if (code >= 95) return I_STORM;
        return I_RAIN;
    }

    private void applyWeather(WeatherViews w) {
        if (wHas) {
            w.icon.setImageDrawable(new IconDrawable(weatherIcon(wCode), accent, true));
            w.temp.setText(fmtTemp(wTemp));
            w.desc.setText(wCity.length() > 0 ? wCity + " · " + weatherDesc(wCode) : weatherDesc(wCode));
            if (w.range != null) w.range.setText("Máx " + fmtTemp(wMax) + "  Mín " + fmtTemp(wMin));
        } else {
            w.icon.setImageDrawable(new IconDrawable(I_CLOUD, MUTED));
            w.temp.setText("--°");
            w.desc.setText(weatherStatus);
            if (w.range != null) w.range.setText("");
        }
    }

    private void refreshWeather() {
        for (WeatherViews w : weathers) applyWeather(w);
    }

    // ------------------------------------------------------------------ saudação, status e animações

    private String greetWord() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return (h >= 5 && h < 12) ? "Bom dia" : (h >= 12 && h < 18) ? "Boa tarde" : "Boa noite";
    }

    private String greetingText() {
        String g = greetWord();
        String name = prefs.getString(K_OWNER, "Erick Viana");
        return name != null && name.length() > 0 ? g + ", " + name : g;
    }

    private void setStatusIcon(ImageView iv, int type, boolean on) {
        if (iv == null) return;
        Object t = iv.getTag();
        if (t instanceof Boolean && ((Boolean) t) == on) return;
        iv.setTag(on);
        iv.setImageDrawable(new IconDrawable(type, on ? WHITE : 0x55FFFFFF));
    }

    private String btDeviceName() {
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            if (ad == null || !ad.isEnabled()) return null;
            List<String> names = new ArrayList<>();
            for (BluetoothDevice d : ad.getBondedDevices()) {
                boolean conn = false;
                try {
                    conn = (Boolean) d.getClass().getMethod("isConnected").invoke(d);
                } catch (Throwable ignored) {
                }
                if (conn) names.add(d.getName() != null ? d.getName() : d.getAddress());
            }
            if (names.isEmpty()) return null;
            return names.size() == 1 ? names.get(0) : names.get(0) + " +" + (names.size() - 1);
        } catch (Throwable t) {
            return null;
        }
    }

    private void refreshPhoneSub() {
        if (phoneSub == null) return;
        String bt = btDeviceName();
        String key = bt != null ? "bt:" + bt : "app:" + subtitle(KEY_PHONE);
        if (key.equals(lastPhoneSub)) return;
        lastPhoneSub = key;
        if (bt != null) {
            SpannableString sp = new SpannableString("● " + bt);
            sp.setSpan(new ForegroundColorSpan(0xFF2ECC71), 0, 1, 0);
            phoneSub.setText(sp);
            phoneSub.setTextColor(WHITE);
        } else {
            phoneSub.setText(subtitle(KEY_PHONE));
            phoneSub.setTextColor(MUTED);
        }
    }

    private final BroadcastReceiver btReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            handler.postDelayed(() -> {
                refreshPhoneSub();
                updateStatus();
            }, 700);
        }
    };

    private void updateStatus() {
        if (statusGreeting == null) return;
        refreshPhoneSub();
        String g = greetingText();
        if (!g.contentEquals(statusGreeting.getText())) statusGreeting.setText(g);
        boolean net = false;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getActiveNetworkInfo();
            net = ni != null && ni.isConnected();
        } catch (Exception ignored) {
        }
        boolean bt = false;
        try {
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            bt = ad != null && ad.isEnabled();
        } catch (Exception ignored) {
        }
        setStatusIcon(stWifi, I_WIFI, net);
        setStatusIcon(stBt, I_BT, bt);
        setStatusIcon(stGps, I_GPS, hasFix);
    }

    private int dur(int ms) {
        return prefs.getInt(K_ANIM, 0) == 0 ? ms : 0;
    }

    /** Efeito iOS: o item "afunda" ao tocar e volta com um leve ricochete. */
    private void pressable(View v) {
        v.setOnTouchListener((view, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                view.animate().cancel();
                view.animate().setStartDelay(0).scaleX(0.95f).scaleY(0.95f).setDuration(dur(110))
                        .setInterpolator(new DecelerateInterpolator()).start();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                view.animate().cancel();
                view.animate().setStartDelay(0).scaleX(1f).scaleY(1f).setDuration(dur(340))
                        .setInterpolator(new OvershootInterpolator(2.4f)).start();
            }
            return false;
        });
    }

    /** Como "pressable", mas deslizar o dedo para os lados troca de música (esquerda = próxima). */
    private void swipeable(final View v) {
        final float[] st = new float[2];
        v.setOnTouchListener((view, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                st[0] = e.getX();
                st[1] = e.getY();
                view.animate().cancel();
                view.animate().setStartDelay(0).scaleX(0.97f).scaleY(0.97f).setDuration(dur(110))
                        .setInterpolator(new DecelerateInterpolator()).start();
            } else if (a == MotionEvent.ACTION_MOVE) {
                if (Math.abs(e.getX() - st[0]) > dp(18)) view.cancelLongPress();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                view.animate().cancel();
                view.animate().setStartDelay(0).scaleX(1f).scaleY(1f).setDuration(dur(340))
                        .setInterpolator(new OvershootInterpolator(2.4f)).start();
                if (a == MotionEvent.ACTION_UP) {
                    float dx = e.getX() - st[0], dy = e.getY() - st[1];
                    if (Math.abs(dx) > dp(70) && Math.abs(dx) > Math.abs(dy) * 1.6f) {
                        mediaKey(dx < 0 ? KeyEvent.KEYCODE_MEDIA_NEXT : KeyEvent.KEYCODE_MEDIA_PREVIOUS);
                        final float dir = dx < 0 ? -1f : 1f;
                        for (MusicViews mv : musics) {
                            final ImageView cv = mv.cover;
                            cv.animate().cancel();
                            cv.animate().setStartDelay(0).translationX(dir * dp(36)).alpha(0.35f)
                                    .setDuration(dur(140)).withEndAction(() ->
                                            cv.animate().translationX(0f).alpha(1f).setDuration(dur(380))
                                                    .setInterpolator(new OvershootInterpolator(1.6f)).start())
                                    .start();
                        }
                        view.setPressed(false);
                        return true;
                    }
                }
            }
            return false;
        });
    }

    private Bitmap loadAsset(String name) {
        try {
            InputStream in = getAssets().open(name);
            Bitmap b = BitmapFactory.decodeStream(in);
            in.close();
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    /** Entrada em cascata dos cartões (sobe suavemente, um depois do outro). */
    private void playEnter() {
        if (splashRunning) return;
        int i = 0;
        for (View v : enterViews) {
            v.animate().cancel();
            v.setAlpha(0f);
            v.setTranslationY(dp(26));
            v.setScaleX(0.96f);
            v.setScaleY(0.96f);
            v.animate().setStartDelay(dur(i * 70)).alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                    .setDuration(dur(560)).setInterpolator(new DecelerateInterpolator(2.2f)).start();
            i++;
        }
        if (carViewRef != null) {
            final CarView cvr = carViewRef;
            handler.postDelayed(() -> cvr.startIntro(dur(2000)), dur(120));
        }
    }

    /** Abertura: logo Renault Sport, depois "Bom dia / Boa tarde / Boa noite" com o nome. */
    private int blackMs() {
        return BLACK_MS[Math.max(0, Math.min(BLACK_MS.length - 1, prefs.getInt(K_BLACK, 1)))];
    }

    private void playSplash() {
        playSplash(blackMs());
    }

    private void playSplash(final int pre) {
        if (splash == null) return;
        splashShown = true;
        splashRunning = true;
        if (greetToast != null) {
            greetToast.animate().cancel();
            greetToast.setAlpha(0f);
            greetToast.setVisibility(View.INVISIBLE);
        }
        lastSplashReal = SystemClock.elapsedRealtime();
        final int tok = ++splashToken;
        String owner = prefs.getString(K_OWNER, "Erick Viana");
        owner = owner == null ? "" : owner.trim();
        splashHi.setText(owner.length() > 0 ? "Olá," : "Olá");
        splashName.setText(owner.toUpperCase());
        splashName.setVisibility(owner.length() > 0 ? View.VISIBLE : View.GONE);
        toastName.setText(owner);
        toastHi.setVisibility(owner.length() > 0 ? View.VISIBLE : View.GONE);

        splash.animate().cancel();
        splash.setAlpha(1f);
        splash.setScaleX(1f);
        splash.setScaleY(1f);
        splash.setVisibility(View.VISIBLE);
        for (View v : enterViews) {
            v.animate().cancel();
            v.setAlpha(0f);
        }
        splashLogo.animate().cancel();
        splashLogo.setAlpha(0f);
        splashLogo.setScaleX(0.9f);
        splashLogo.setScaleY(0.9f);
        splashLines.stop();
        View[] gv = {splashAvatar, splashHi, splashName};
        for (View g : gv) {
            g.animate().cancel();
            g.setAlpha(0f);
            g.setTranslationX(0f);
            g.setTranslationY(dp(14));
            g.setScaleX(1f);
            g.setScaleY(1f);
        }
        splashAvatar.setTranslationY(0f);
        splashAvatar.setScaleX(0.6f);
        splashAvatar.setScaleY(0.6f);
        splash.setOnClickListener(v -> {
            stopWelcomeSound();
            endSplash(tok);
        });
        if (pre > 0) {
            handler.postDelayed(() -> {
                if (tok == splashToken && splashRunning) playWelcomeSound();
            }, pre);
        } else {
            playWelcomeSound();
        }
        handler.postDelayed(() -> {
            if (tok == splashToken && splashRunning) splashLines.start();
        }, pre);

        // 1) feixes vermelhos + logo
        splashLogo.animate().setStartDelay(pre + 250).alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(dur(1000)).setInterpolator(new DecelerateInterpolator(1.8f)).start();
        // 2) logo sai, avatar + saudação surgem no centro
        handler.postDelayed(() -> {
            if (tok != splashToken || !splashRunning) return;
            splashLogo.animate().setStartDelay(0).alpha(0f).scaleX(1.06f).scaleY(1.06f)
                    .setDuration(dur(450)).start();
            splashAvatar.animate().setStartDelay(dur(250)).alpha(1f).scaleX(1f).scaleY(1f)
                    .setDuration(dur(750)).setInterpolator(new OvershootInterpolator(1.5f)).start();
            splashHi.animate().setStartDelay(dur(450)).alpha(1f).translationY(0f)
                    .setDuration(dur(650)).setInterpolator(new DecelerateInterpolator(1.8f)).start();
            splashName.animate().setStartDelay(dur(650)).alpha(1f).translationY(0f)
                    .setDuration(dur(650)).setInterpolator(new DecelerateInterpolator(1.8f)).start();
        }, 2500 + pre);
        // 3) avatar voa para o canto superior esquerdo
        handler.postDelayed(() -> flyAvatar(tok), 4700 + pre);
        handler.postDelayed(() -> endSplash(tok), 5900 + pre);
    }

    private void flyAvatar(final int tok) {
        if (tok != splashToken || !splashRunning) return;
        splashLines.fadeOut(600);
        try {
            int[] a = new int[2];
            int[] t = new int[2];
            splashAvatar.getLocationOnScreen(a);
            toastAvatar.getLocationOnScreen(t);
            if (toastAvatar.getWidth() <= 0) throw new IllegalStateException();
            float scx = a[0] + splashAvatar.getWidth() / 2f, scy = a[1] + splashAvatar.getHeight() / 2f;
            float tcx = t[0] + toastAvatar.getWidth() / 2f, tcy = t[1] + toastAvatar.getHeight() / 2f;
            float sc = toastAvatar.getWidth() / (float) splashAvatar.getWidth();
            splashAvatar.animate().setStartDelay(0).translationX(tcx - scx).translationY(tcy - scy)
                    .scaleX(sc).scaleY(sc).setDuration(dur(1000))
                    .setInterpolator(new AccelerateDecelerateInterpolator()).start();
            float fx = (tcx - scx) * 0.6f, fy = (tcy - scy) * 0.6f;
            splashHi.animate().setStartDelay(0).alpha(0f).translationX(fx).translationY(fy)
                    .setDuration(dur(700)).start();
            splashName.animate().setStartDelay(0).alpha(0f).translationX(fx).translationY(fy)
                    .setDuration(dur(700)).start();
            // a "janela de notificação" surge quando o avatar chega
            greetToast.animate().cancel();
            greetToast.setVisibility(View.VISIBLE);
            greetToast.setAlpha(0f);
            greetToast.setTranslationX(-dp(24));
            greetToast.setTranslationY(0f);
            greetToast.animate().setStartDelay(dur(750)).alpha(1f).translationX(0f).setDuration(dur(450))
                    .setInterpolator(new DecelerateInterpolator(1.6f)).start();
            splashAvatar.animate().setStartDelay(dur(1000)).alpha(0f).setDuration(dur(150)).start();
            // permanece um pouco e sai
            handler.postDelayed(() -> {
                if (tok != splashToken) return;
                greetToast.animate().cancel();
                greetToast.animate().setStartDelay(0).alpha(0f).translationX(-dp(30)).translationY(-dp(16))
                        .setDuration(dur(500)).setInterpolator(new AccelerateInterpolator())
                        .withEndAction(() -> greetToast.setVisibility(View.INVISIBLE)).start();
            }, dur(750 + 450 + 3000));
        } catch (Exception e) {
            splashAvatar.animate().alpha(0f).setDuration(dur(400)).start();
            splashHi.animate().alpha(0f).setDuration(dur(400)).start();
            splashName.animate().alpha(0f).setDuration(dur(400)).start();
        }
    }

    private void endSplash(int tok) {
        if (tok != splashToken || !splashRunning) return;
        splashRunning = false;
        splashLines.fadeOut(400);
        splash.animate().cancel();
        splash.animate().setStartDelay(0).alpha(0f).scaleX(1.05f).scaleY(1.05f)
                .setDuration(dur(600)).setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    splash.setVisibility(View.GONE);
                    splash.setScaleX(1f);
                    splash.setScaleY(1f);
                    splashLines.stop();
                }).start();
        playEnter();
    }

    // ------------------------------------------------------------------ avatar

    private Bitmap loadAvatar() {
        File f = getFileStreamPath(F_AVATAR);
        if (!f.exists()) {
            avatarBmp = null;
            avatarStamp = -1;
            return null;
        }
        if (avatarBmp != null && avatarStamp == f.lastModified()) return avatarBmp;
        avatarBmp = BitmapFactory.decodeFile(f.getPath());
        avatarStamp = f.lastModified();
        return avatarBmp;
    }

    /** Círculo com a foto do avatar (ou a inicial do nome, se não houver foto). */
    private FrameLayout makeAvatar(int sizeDp) {
        FrameLayout f = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor((accent & 0x00FFFFFF) | 0x40000000);
        int stroke = Math.max(1, dp(sizeDp > 60 ? 3 : 2));
        bg.setStroke(stroke, accent);
        f.setBackground(bg);
        Bitmap ab = loadAvatar();
        if (ab != null) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(ab);
            iv.setOutlineProvider(new ViewOutlineProvider() {
                @Override
                public void getOutline(View view, Outline outline) {
                    outline.setOval(0, 0, view.getWidth(), view.getHeight());
                }
            });
            iv.setClipToOutline(true);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(MATCH, MATCH);
            lp.setMargins(stroke, stroke, stroke, stroke);
            f.addView(iv, lp);
        } else {
            String owner = prefs.getString(K_OWNER, "Erick Viana");
            String ini = owner != null && owner.trim().length() > 0
                    ? owner.trim().substring(0, 1).toUpperCase() : "•";
            TextView t = text(ini, sizeDp * 0.42f, WHITE, true);
            t.setGravity(Gravity.CENTER);
            t.setIncludeFontPadding(false);
            f.addView(t, new FrameLayout.LayoutParams(MATCH, MATCH));
        }
        return f;
    }

    private void avatarMenu() {
        choose("Foto do avatar", new String[]{"Escolher da galeria", "Remover foto"}, -1, i -> {
            if (i == 0) {
                pickImage(REQ_AVATAR);
            } else {
                deleteFile(F_AVATAR);
                avatarBmp = null;
                rebuild(settingsPanel.getVisibility() == View.VISIBLE);
            }
        });
    }

    /** Feixes de luz vermelhos cruzando a tela (efeito esportivo da abertura). */
    private static class SpeedLines extends View {
        private static final int N = 16;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float[] y = new float[N], sp = new float[N], len = new float[N], ph = new float[N], th = new float[N];
        private ValueAnimator anim;
        private long t0;
        private float fade = 1f;

        SpeedLines(Context c) {
            super(c);
            java.util.Random r = new java.util.Random(7);
            for (int i = 0; i < N; i++) {
                y[i] = r.nextFloat();
                sp[i] = 0.7f + r.nextFloat() * 1.3f;
                len[i] = 0.16f + r.nextFloat() * 0.34f;
                ph[i] = r.nextFloat();
                th[i] = 1.2f + r.nextFloat() * 2.6f;
            }
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStyle(Paint.Style.STROKE);
        }

        void start() {
            stop();
            fade = 1f;
            t0 = SystemClock.uptimeMillis();
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(1000);
            anim.setRepeatCount(ValueAnimator.INFINITE);
            anim.addUpdateListener(a -> invalidate());
            anim.start();
        }

        void stop() {
            if (anim != null) anim.cancel();
            anim = null;
            invalidate();
        }

        void fadeOut(int ms) {
            if (anim == null) return;
            ValueAnimator f = ValueAnimator.ofFloat(fade, 0f);
            f.setDuration(ms);
            f.addUpdateListener(a -> fade = (Float) a.getAnimatedValue());
            f.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            if (anim == null || fade <= 0.01f) return;
            int w = getWidth(), h = getHeight();
            float d = getResources().getDisplayMetrics().density;
            float ms = SystemClock.uptimeMillis() - t0;
            double ang = -0.30;
            float dx = (float) Math.cos(ang), dy = (float) Math.sin(ang);
            for (int i = 0; i < N; i++) {
                float L = len[i] * w;
                float prog = ((ms / (1700f / sp[i])) + ph[i]) % 1f;
                float hx = -L + prog * (w + 2 * L);
                float hy = y[i] * h + (hx - w / 2f) * (dy / dx) + h * 0.12f;
                float tx = hx - L * dx, ty = hy - L * dy;
                p.setShader(new LinearGradient(tx, ty, hx, hy,
                        new int[]{0x00FF2D3A, 0xCCFF2D3A, 0xFFFFE3E6}, new float[]{0f, 0.78f, 1f}, Shader.TileMode.CLAMP));
                p.setStrokeWidth(th[i] * 3.2f * d);
                p.setAlpha((int) (70 * fade));
                c.drawLine(tx, ty, hx, hy, p);
                p.setStrokeWidth(th[i] * d);
                p.setAlpha((int) (255 * fade));
                c.drawLine(tx, ty, hx, hy, p);
            }
            p.setShader(null);
        }
    }

    // ------------------------------------------------------------------ util

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
