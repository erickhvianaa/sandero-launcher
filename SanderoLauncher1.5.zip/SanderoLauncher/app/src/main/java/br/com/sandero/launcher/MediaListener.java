package br.com.sandero.launcher;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/**
 * Existe para o usuário poder conceder o "Acesso a notificações" (necessário para ler a mídia
 * em reprodução) e, com isso, também ler o nome de quem está ligando na notificação de chamada.
 */
public class MediaListener extends NotificationListenerService {
    private static volatile MediaListener inst;

    @Override
    public void onListenerConnected() {
        inst = this;
    }

    @Override
    public void onListenerDisconnected() {
        if (inst == this) inst = null;
    }

    /** Título da notificação de chamada (normalmente o nome do contato), ou null. */
    static String callTitle() {
        MediaListener l = inst;
        if (l == null) return null;
        try {
            for (StatusBarNotification sb : l.getActiveNotifications()) {
                Notification n = sb.getNotification();
                String pkg = sb.getPackageName() == null ? "" : sb.getPackageName().toLowerCase();
                boolean call = Notification.CATEGORY_CALL.equals(n.category)
                        || pkg.contains("dialer") || pkg.contains("incall") || pkg.contains("telecom");
                if (!call) continue;
                Bundle e = n.extras;
                if (e == null) continue;
                CharSequence t = e.getCharSequence(Notification.EXTRA_TITLE);
                if (t != null && t.length() > 0) return t.toString();
            }
        } catch (Exception ignored) {
        }
        return null;
    }
}
