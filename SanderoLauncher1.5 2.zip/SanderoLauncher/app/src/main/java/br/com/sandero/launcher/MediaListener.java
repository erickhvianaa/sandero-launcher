package br.com.sandero.launcher;

import android.service.notification.NotificationListenerService;

/**
 * Serviço vazio. Existe apenas para o usuário poder conceder o "Acesso a notificações",
 * que é o que o Android exige para um app ler a mídia que está tocando.
 */
public class MediaListener extends NotificationListenerService {
}
