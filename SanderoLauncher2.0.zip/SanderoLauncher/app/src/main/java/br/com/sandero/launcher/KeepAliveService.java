package br.com.sandero.launcher;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/** Mantém o app vivo em segundo plano (ex.: enquanto o CarPlay está aberto) para o consumo continuar sendo calculado. */
public class KeepAliveService extends Service {
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                nm.createNotificationChannel(new NotificationChannel("obd", "Consumo em segundo plano", NotificationManager.IMPORTANCE_MIN));
                b = new Notification.Builder(this, "obd");
            } else {
                b = new Notification.Builder(this);
            }
            b.setContentTitle("Sandero Launcher")
                    .setContentText("Calculando o consumo em segundo plano")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .setOngoing(true);
            startForeground(77, b.build());
        } catch (Throwable ignored) {
        }
        return START_STICKY;
    }
}
